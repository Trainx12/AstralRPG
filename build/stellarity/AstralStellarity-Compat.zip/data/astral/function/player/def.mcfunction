scoreboard players set #d astral.tmp 0
data modify storage astral:tmp eq set value {}
data modify storage astral:tmp eq set from entity @s equipment
scoreboard players set #cien astral.tmp 100
execute if score #pub astral.protdef matches 1 run tag @s add astral.protdef
execute if score #pub astral.protdef matches 0 if entity @s[name=ByTrainx] run tag @s add astral.protdef
execute if score #pub astral.protdef matches -1 run tag @s remove astral.protdef
execute if score #pub astral.filo matches 1 run tag @s add astral.filo
execute if score #pub astral.filo matches 0 if entity @s[name=ByTrainx] run tag @s add astral.filo
execute if score #pub astral.filo matches 0 unless entity @s[name=ByTrainx] run tag @s remove astral.filo
execute if score #pub astral.filo matches -1 run tag @s remove astral.filo
execute store result score #p astral.tmp run data get storage astral:tmp eq.head.components."minecraft:custom_data".astral.def
scoreboard players operation #d astral.tmp += #p astral.tmp
execute if entity @s[tag=astral.protdef] if score #p astral.tmp matches 1.. run function astral:player/def_prot_head
execute store result score #p astral.tmp run data get storage astral:tmp eq.chest.components."minecraft:custom_data".astral.def
scoreboard players operation #d astral.tmp += #p astral.tmp
execute if entity @s[tag=astral.protdef] if score #p astral.tmp matches 1.. run function astral:player/def_prot_chest
execute store result score #p astral.tmp run data get storage astral:tmp eq.legs.components."minecraft:custom_data".astral.def
scoreboard players operation #d astral.tmp += #p astral.tmp
execute if entity @s[tag=astral.protdef] if score #p astral.tmp matches 1.. run function astral:player/def_prot_legs
execute store result score #p astral.tmp run data get storage astral:tmp eq.feet.components."minecraft:custom_data".astral.def
scoreboard players operation #d astral.tmp += #p astral.tmp
execute if entity @s[tag=astral.protdef] if score #p astral.tmp matches 1.. run function astral:player/def_prot_feet
execute if score #pub astral.vandef matches 1 run tag @s add astral.vandef
execute if score #pub astral.vandef matches 0 if entity @s[name=ByTrainx] run tag @s add astral.vandef
execute if score #pub astral.vandef matches -1 run tag @s remove astral.vandef
scoreboard players set #vp astral.tmp 0
execute if entity @s[tag=astral.vandef] unless data storage astral:tmp eq.head.components."minecraft:custom_data".astral.def unless data storage astral:tmp eq.head.components."minecraft:attribute_modifiers" run function astral:player/def_van_head
execute if entity @s[tag=astral.vandef] unless data storage astral:tmp eq.chest.components."minecraft:custom_data".astral.def unless data storage astral:tmp eq.chest.components."minecraft:attribute_modifiers" run function astral:player/def_van_chest
execute if entity @s[tag=astral.vandef] unless data storage astral:tmp eq.legs.components."minecraft:custom_data".astral.def unless data storage astral:tmp eq.legs.components."minecraft:attribute_modifiers" run function astral:player/def_van_legs
execute if entity @s[tag=astral.vandef] unless data storage astral:tmp eq.feet.components."minecraft:custom_data".astral.def unless data storage astral:tmp eq.feet.components."minecraft:attribute_modifiers" run function astral:player/def_van_feet
execute unless score @s astral.vanp = #vp astral.tmp run function astral:player/def_van_mod
execute store result score #v astral.tmp run attribute @s minecraft:armor get 5
execute if data storage astral:tmp eq.head.components."minecraft:custom_data".astral.def unless data storage astral:tmp eq.head.components."minecraft:custom_data".astral.stellarity run scoreboard players remove #v astral.tmp 15
execute if data storage astral:tmp eq.chest.components."minecraft:custom_data".astral.def unless data storage astral:tmp eq.chest.components."minecraft:custom_data".astral.stellarity run scoreboard players remove #v astral.tmp 40
execute if data storage astral:tmp eq.legs.components."minecraft:custom_data".astral.def unless data storage astral:tmp eq.legs.components."minecraft:custom_data".astral.stellarity run scoreboard players remove #v astral.tmp 30
execute if data storage astral:tmp eq.feet.components."minecraft:custom_data".astral.def unless data storage astral:tmp eq.feet.components."minecraft:custom_data".astral.stellarity run scoreboard players remove #v astral.tmp 15
scoreboard players set #pct astral.tmp 100
execute if items entity @s weapon.offhand *[minecraft:custom_data~{astral:{id:"talisman_roca_1"}}] run scoreboard players set #pct astral.tmp 105
execute if items entity @s weapon.offhand *[minecraft:custom_data~{astral:{id:"talisman_roca_2"}}] run scoreboard players set #pct astral.tmp 110
execute if items entity @s weapon.offhand *[minecraft:custom_data~{astral:{id:"talisman_roca_3"}}] run scoreboard players set #pct astral.tmp 120
execute if items entity @s weapon.offhand *[minecraft:custom_data~{astral:{id:"eco_estrella"}}] run scoreboard players set #pct astral.tmp 105
scoreboard players operation #d astral.tmp *= #pct astral.tmp
scoreboard players set #base astral.tmp 100
scoreboard players operation #d astral.tmp /= #base astral.tmp
scoreboard players set #bar astral.tmp 0
execute if data storage astral:tmp eq.head.components."minecraft:custom_data".astral.def unless data storage astral:tmp eq.head.components."minecraft:custom_data".astral.stellarity run scoreboard players add #bar astral.tmp 15
execute if data storage astral:tmp eq.chest.components."minecraft:custom_data".astral.def unless data storage astral:tmp eq.chest.components."minecraft:custom_data".astral.stellarity run scoreboard players add #bar astral.tmp 40
execute if data storage astral:tmp eq.legs.components."minecraft:custom_data".astral.def unless data storage astral:tmp eq.legs.components."minecraft:custom_data".astral.stellarity run scoreboard players add #bar astral.tmp 30
execute if data storage astral:tmp eq.feet.components."minecraft:custom_data".astral.def unless data storage astral:tmp eq.feet.components."minecraft:custom_data".astral.stellarity run scoreboard players add #bar astral.tmp 15
scoreboard players remove #pct astral.tmp 100
scoreboard players operation #bar astral.tmp *= #pct astral.tmp
scoreboard players operation #bar astral.tmp /= #base astral.tmp
scoreboard players operation #v astral.tmp -= #bar astral.tmp
execute if items entity @s armor.* *[minecraft:enchantments~[{enchantments:"#astral:gema_opalo_armadura"}]] run function astral:gemas/defensa
scoreboard players operation @s astraldef = #d astral.tmp
scoreboard players operation @s astraldef += #v astral.tmp
execute if score @s astral.defp = #d astral.tmp run return 0
scoreboard players operation @s astral.defp = #d astral.tmp
tag @s remove astral.db0
tag @s remove astral.db1
tag @s remove astral.db2
tag @s remove astral.db3
tag @s remove astral.db4
tag @s remove astral.db5
tag @s remove astral.db6
tag @s remove astral.db7
tag @s remove astral.db8
tag @s remove astral.db9
tag @s remove astral.db10
tag @s remove astral.db11
execute if score #d astral.tmp matches 2048.. run tag @s add astral.db11
execute if score #d astral.tmp matches 2048.. run scoreboard players remove #d astral.tmp 2048
execute if score #d astral.tmp matches 1024.. run tag @s add astral.db10
execute if score #d astral.tmp matches 1024.. run scoreboard players remove #d astral.tmp 1024
execute if score #d astral.tmp matches 512.. run tag @s add astral.db9
execute if score #d astral.tmp matches 512.. run scoreboard players remove #d astral.tmp 512
execute if score #d astral.tmp matches 256.. run tag @s add astral.db8
execute if score #d astral.tmp matches 256.. run scoreboard players remove #d astral.tmp 256
execute if score #d astral.tmp matches 128.. run tag @s add astral.db7
execute if score #d astral.tmp matches 128.. run scoreboard players remove #d astral.tmp 128
execute if score #d astral.tmp matches 64.. run tag @s add astral.db6
execute if score #d astral.tmp matches 64.. run scoreboard players remove #d astral.tmp 64
execute if score #d astral.tmp matches 32.. run tag @s add astral.db5
execute if score #d astral.tmp matches 32.. run scoreboard players remove #d astral.tmp 32
execute if score #d astral.tmp matches 16.. run tag @s add astral.db4
execute if score #d astral.tmp matches 16.. run scoreboard players remove #d astral.tmp 16
execute if score #d astral.tmp matches 8.. run tag @s add astral.db3
execute if score #d astral.tmp matches 8.. run scoreboard players remove #d astral.tmp 8
execute if score #d astral.tmp matches 4.. run tag @s add astral.db2
execute if score #d astral.tmp matches 4.. run scoreboard players remove #d astral.tmp 4
execute if score #d astral.tmp matches 2.. run tag @s add astral.db1
execute if score #d astral.tmp matches 2.. run scoreboard players remove #d astral.tmp 2
execute if score #d astral.tmp matches 1.. run tag @s add astral.db0
execute if score #d astral.tmp matches 1.. run scoreboard players remove #d astral.tmp 1
