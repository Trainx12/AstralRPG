scoreboard players remove #b astral.tmp 1
function astral:tool/mine
function astral:tool/chain
