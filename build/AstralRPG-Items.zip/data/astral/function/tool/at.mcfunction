$execute positioned $(x) $(y) $(z) if block ~ ~ ~ #astral:ray_pass run function astral:tool/do
