execute if items entity @s weapon.mainhand minecraft:netherite_pickaxe[minecraft:custom_data~{astral:{tool:"drill"}}] run return run function astral:tool/drill
execute if score @s astral.tok matches 2 if items entity @s weapon.mainhand minecraft:netherite_axe[minecraft:custom_data~{astral:{tool:"saw"}}] run function astral:tool/saw
