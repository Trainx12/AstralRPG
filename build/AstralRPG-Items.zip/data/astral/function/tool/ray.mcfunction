execute unless block ~ ~ ~ #astral:ray_pass run return run function astral:tool/hit
scoreboard players remove #r astral.tmp 1
execute if score #r astral.tmp matches 1.. positioned ^ ^ ^0.1 run function astral:tool/ray
