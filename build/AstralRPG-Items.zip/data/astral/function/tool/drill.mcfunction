execute store result score #a astral.tmp run data get entity @s SelectedItem.components."minecraft:custom_data".astral.area
execute if score #a astral.tmp matches ..1 run return 0
# si el bloque esta a la altura de tus pies, el area crece hacia arriba
execute store result score #py astral.tmp run data get entity @s Pos[1]
scoreboard players set #up astral.tmp 0
execute if score @s astral.ty <= #py astral.tmp run scoreboard players set #up astral.tmp 1
scoreboard players set #v astral.tmp 0
execute if entity @s[x_rotation=50..90] run scoreboard players set #v astral.tmp 1
execute if entity @s[x_rotation=-90..-50] run scoreboard players set #v astral.tmp 1
execute if entity @s[y_rotation=-45..45] run function astral:tool/d/s
execute if entity @s[y_rotation=45..135] run function astral:tool/d/w
execute if entity @s[y_rotation=-135..-45] run function astral:tool/d/e
execute unless entity @s[y_rotation=-135..135] run function astral:tool/d/n
playsound minecraft:block.stone.break block @a ~ ~ ~ 0.8 0.8
