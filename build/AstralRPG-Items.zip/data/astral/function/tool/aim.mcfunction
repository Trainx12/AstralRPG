scoreboard players set @s astral.tok 0
scoreboard players set #r astral.tmp 52
execute anchored eyes positioned ^ ^ ^ run function astral:tool/ray
