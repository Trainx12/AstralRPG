execute store result score @a[tag=astral.me,limit=1] astral.tx run data get entity @s Pos[0]
execute store result score @a[tag=astral.me,limit=1] astral.ty run data get entity @s Pos[1]
execute store result score @a[tag=astral.me,limit=1] astral.tz run data get entity @s Pos[2]
kill @s
