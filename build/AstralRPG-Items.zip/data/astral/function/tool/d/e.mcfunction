execute if score #a astral.tmp matches 2 if score #v astral.tmp matches 0 if score #up astral.tmp matches 0 run function astral:tool/d/e2h0
execute if score #a astral.tmp matches 2 if score #v astral.tmp matches 0 if score #up astral.tmp matches 1 run function astral:tool/d/e2h1
execute if score #a astral.tmp matches 2 if score #v astral.tmp matches 1 run function astral:tool/d/e2v0
execute if score #a astral.tmp matches 3 if score #v astral.tmp matches 0 if score #up astral.tmp matches 0 run function astral:tool/d/e3h0
execute if score #a astral.tmp matches 3 if score #v astral.tmp matches 0 if score #up astral.tmp matches 1 run function astral:tool/d/e3h1
execute if score #a astral.tmp matches 3 if score #v astral.tmp matches 1 run function astral:tool/d/e3v0
execute if score #a astral.tmp matches 4 if score #v astral.tmp matches 0 if score #up astral.tmp matches 0 run function astral:tool/d/e4h0
execute if score #a astral.tmp matches 4 if score #v astral.tmp matches 0 if score #up astral.tmp matches 1 run function astral:tool/d/e4h1
execute if score #a astral.tmp matches 4 if score #v astral.tmp matches 1 run function astral:tool/d/e4v0
execute if score #a astral.tmp matches 5 if score #v astral.tmp matches 0 if score #up astral.tmp matches 0 run function astral:tool/d/e5h0
execute if score #a astral.tmp matches 5 if score #v astral.tmp matches 0 if score #up astral.tmp matches 1 run function astral:tool/d/e5h1
execute if score #a astral.tmp matches 5 if score #v astral.tmp matches 1 run function astral:tool/d/e5v0
