execute if score #a astral.tmp matches 2 if score #v astral.tmp matches 0 if score #up astral.tmp matches 0 run function astral:tool/d/w2h0
execute if score #a astral.tmp matches 2 if score #v astral.tmp matches 0 if score #up astral.tmp matches 1 run function astral:tool/d/w2h1
execute if score #a astral.tmp matches 2 if score #v astral.tmp matches 1 run function astral:tool/d/w2v0
execute if score #a astral.tmp matches 3 if score #v astral.tmp matches 0 if score #up astral.tmp matches 0 run function astral:tool/d/w3h0
execute if score #a astral.tmp matches 3 if score #v astral.tmp matches 0 if score #up astral.tmp matches 1 run function astral:tool/d/w3h1
execute if score #a astral.tmp matches 3 if score #v astral.tmp matches 1 run function astral:tool/d/w3v0
execute if score #a astral.tmp matches 4 if score #v astral.tmp matches 0 if score #up astral.tmp matches 0 run function astral:tool/d/w4h0
execute if score #a astral.tmp matches 4 if score #v astral.tmp matches 0 if score #up astral.tmp matches 1 run function astral:tool/d/w4h1
execute if score #a astral.tmp matches 4 if score #v astral.tmp matches 1 run function astral:tool/d/w4v0
execute if score #a astral.tmp matches 5 if score #v astral.tmp matches 0 if score #up astral.tmp matches 0 run function astral:tool/d/w5h0
execute if score #a astral.tmp matches 5 if score #v astral.tmp matches 0 if score #up astral.tmp matches 1 run function astral:tool/d/w5h1
execute if score #a astral.tmp matches 5 if score #v astral.tmp matches 1 run function astral:tool/d/w5v0
