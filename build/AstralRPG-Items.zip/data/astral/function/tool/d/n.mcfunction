execute if score #a astral.tmp matches 2 if score #v astral.tmp matches 0 if score #up astral.tmp matches 0 run function astral:tool/d/n2h0
execute if score #a astral.tmp matches 2 if score #v astral.tmp matches 0 if score #up astral.tmp matches 1 run function astral:tool/d/n2h1
execute if score #a astral.tmp matches 2 if score #v astral.tmp matches 1 run function astral:tool/d/n2v0
execute if score #a astral.tmp matches 3 if score #v astral.tmp matches 0 if score #up astral.tmp matches 0 run function astral:tool/d/n3h0
execute if score #a astral.tmp matches 3 if score #v astral.tmp matches 0 if score #up astral.tmp matches 1 run function astral:tool/d/n3h1
execute if score #a astral.tmp matches 3 if score #v astral.tmp matches 1 run function astral:tool/d/n3v0
execute if score #a astral.tmp matches 4 if score #v astral.tmp matches 0 if score #up astral.tmp matches 0 run function astral:tool/d/n4h0
execute if score #a astral.tmp matches 4 if score #v astral.tmp matches 0 if score #up astral.tmp matches 1 run function astral:tool/d/n4h1
execute if score #a astral.tmp matches 4 if score #v astral.tmp matches 1 run function astral:tool/d/n4v0
execute if score #a astral.tmp matches 5 if score #v astral.tmp matches 0 if score #up astral.tmp matches 0 run function astral:tool/d/n5h0
execute if score #a astral.tmp matches 5 if score #v astral.tmp matches 0 if score #up astral.tmp matches 1 run function astral:tool/d/n5h1
execute if score #a astral.tmp matches 5 if score #v astral.tmp matches 1 run function astral:tool/d/n5v0
