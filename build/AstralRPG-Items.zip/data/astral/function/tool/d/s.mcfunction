execute if score #a astral.tmp matches 2 if score #v astral.tmp matches 0 if score #up astral.tmp matches 0 run function astral:tool/d/s2h0
execute if score #a astral.tmp matches 2 if score #v astral.tmp matches 0 if score #up astral.tmp matches 1 run function astral:tool/d/s2h1
execute if score #a astral.tmp matches 2 if score #v astral.tmp matches 1 run function astral:tool/d/s2v0
execute if score #a astral.tmp matches 3 if score #v astral.tmp matches 0 if score #up astral.tmp matches 0 run function astral:tool/d/s3h0
execute if score #a astral.tmp matches 3 if score #v astral.tmp matches 0 if score #up astral.tmp matches 1 run function astral:tool/d/s3h1
execute if score #a astral.tmp matches 3 if score #v astral.tmp matches 1 run function astral:tool/d/s3v0
execute if score #a astral.tmp matches 4 if score #v astral.tmp matches 0 if score #up astral.tmp matches 0 run function astral:tool/d/s4h0
execute if score #a astral.tmp matches 4 if score #v astral.tmp matches 0 if score #up astral.tmp matches 1 run function astral:tool/d/s4h1
execute if score #a astral.tmp matches 4 if score #v astral.tmp matches 1 run function astral:tool/d/s4v0
execute if score #a astral.tmp matches 5 if score #v astral.tmp matches 0 if score #up astral.tmp matches 0 run function astral:tool/d/s5h0
execute if score #a astral.tmp matches 5 if score #v astral.tmp matches 0 if score #up astral.tmp matches 1 run function astral:tool/d/s5h1
execute if score #a astral.tmp matches 5 if score #v astral.tmp matches 1 run function astral:tool/d/s5v0
