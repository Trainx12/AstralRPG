execute positioned ~0 ~1 ~0 if block ~ ~ ~ #astral:drillable run function astral:tool/mine
