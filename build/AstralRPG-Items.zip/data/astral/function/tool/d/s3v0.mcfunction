execute positioned ~0 ~0 ~1 if block ~ ~ ~ #astral:drillable run function astral:tool/mine
execute positioned ~-1 ~0 ~0 if block ~ ~ ~ #astral:drillable run function astral:tool/mine
execute positioned ~-1 ~0 ~1 if block ~ ~ ~ #astral:drillable run function astral:tool/mine
