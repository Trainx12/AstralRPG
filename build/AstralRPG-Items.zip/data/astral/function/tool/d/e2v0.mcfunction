execute positioned ~1 ~0 ~0 if block ~ ~ ~ #astral:drillable run function astral:tool/mine
