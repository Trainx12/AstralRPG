scoreboard players reset @s astral.dr
scoreboard players reset @s astral.cs
execute if score @s astral.tok matches ..0 run return 0
execute store result storage astral:tmp tool.x int 1 run scoreboard players get @s astral.tx
execute store result storage astral:tmp tool.y int 1 run scoreboard players get @s astral.ty
execute store result storage astral:tmp tool.z int 1 run scoreboard players get @s astral.tz
function astral:tool/at with storage astral:tmp tool
