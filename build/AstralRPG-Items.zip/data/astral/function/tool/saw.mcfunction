execute store result score #b astral.tmp run data get entity @s SelectedItem.components."minecraft:custom_data".astral.chain
execute if score #b astral.tmp matches ..0 run return 0
# solo arboles naturales: tiene que haber hojas que no puso un jugador
execute unless predicate astral:natural_tree run return 0
execute if score #b astral.tmp matches 300.. run scoreboard players set #b astral.tmp 300
function astral:tool/chain
playsound minecraft:block.wood.break block @a ~ ~ ~ 1 0.7
