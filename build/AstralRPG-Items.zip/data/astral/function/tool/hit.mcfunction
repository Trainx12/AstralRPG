scoreboard players set @s astral.tok 1
execute if block ~ ~ ~ #astral:tree_logs run scoreboard players set @s astral.tok 2
tag @s add astral.me
execute align xyz summon minecraft:marker run function astral:tool/store
tag @s remove astral.me
