loot spawn ~0.5 ~0.5 ~0.5 mine ~ ~ ~ mainhand
particle minecraft:poof ~0.5 ~0.5 ~0.5 0.2 0.2 0.2 0.01 2
setblock ~ ~ ~ minecraft:air
