execute if score @s astral.set_ber matches 4.. run effect give @s minecraft:strength 5 0
execute if score @s astral.set_mag matches 4.. run effect give @s minecraft:regeneration 4 0
execute if score @s astral.set_mag matches 4.. run effect give @s minecraft:speed 4 0
execute if score @s astral.set_arq matches 4.. run effect give @s minecraft:speed 4 1
execute if score @s astral.set_arq matches 4.. run effect give @s minecraft:jump_boost 4 0
scoreboard players set @s astral.kills 0
