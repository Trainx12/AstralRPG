scoreboard players set @s astral.set_ber 0
execute if items entity @s armor.head *[minecraft:custom_data~{astral:{set:"berserker"}}] run scoreboard players add @s astral.set_ber 1
execute if items entity @s armor.chest *[minecraft:custom_data~{astral:{set:"berserker"}}] run scoreboard players add @s astral.set_ber 1
execute if items entity @s armor.legs *[minecraft:custom_data~{astral:{set:"berserker"}}] run scoreboard players add @s astral.set_ber 1
execute if items entity @s armor.feet *[minecraft:custom_data~{astral:{set:"berserker"}}] run scoreboard players add @s astral.set_ber 1
attribute @s minecraft:attack_damage modifier remove astral:set_berserker_2
execute if score @s astral.set_ber matches 2.. run attribute @s minecraft:attack_damage modifier add astral:set_berserker_2 0.05 add_multiplied_total
scoreboard players set @s astral.set_mag 0
execute if items entity @s armor.head *[minecraft:custom_data~{astral:{set:"mago"}}] run scoreboard players add @s astral.set_mag 1
execute if items entity @s armor.chest *[minecraft:custom_data~{astral:{set:"mago"}}] run scoreboard players add @s astral.set_mag 1
execute if items entity @s armor.legs *[minecraft:custom_data~{astral:{set:"mago"}}] run scoreboard players add @s astral.set_mag 1
execute if items entity @s armor.feet *[minecraft:custom_data~{astral:{set:"mago"}}] run scoreboard players add @s astral.set_mag 1
attribute @s minecraft:armor modifier remove astral:set_mago_2
execute if score @s astral.set_mag matches 2.. run attribute @s minecraft:armor modifier add astral:set_mago_2 2 add_value
scoreboard players set @s astral.set_arq 0
execute if items entity @s armor.head *[minecraft:custom_data~{astral:{set:"arquero"}}] run scoreboard players add @s astral.set_arq 1
execute if items entity @s armor.chest *[minecraft:custom_data~{astral:{set:"arquero"}}] run scoreboard players add @s astral.set_arq 1
execute if items entity @s armor.legs *[minecraft:custom_data~{astral:{set:"arquero"}}] run scoreboard players add @s astral.set_arq 1
execute if items entity @s armor.feet *[minecraft:custom_data~{astral:{set:"arquero"}}] run scoreboard players add @s astral.set_arq 1
attribute @s minecraft:movement_speed modifier remove astral:set_arquero_2
execute if score @s astral.set_arq matches 2.. run attribute @s minecraft:movement_speed modifier add astral:set_arquero_2 0.05 add_multiplied_base
