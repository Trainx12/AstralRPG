execute as @a run function astral:player/hp
schedule function astral:loop/t5 5t replace
