execute as @a run function astral:player/hp
execute as @a[scores={astral.kills=1..}] run function astral:set/kill
schedule function astral:loop/t5 5t replace
