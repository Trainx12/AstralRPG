execute as @e[scores={astral.bleed=1..}] at @s run function astral:fx/bleed_tick
execute as @e[scores={astral.rem=1..}] at @s run function astral:fx/remate_tick
schedule function astral:loop/t20 20t replace
