execute as @e[scores={astral.bleed=1..}] at @s run function astral:fx/bleed_tick
execute as @a run function astral:upgrade/check
execute as @a run function astral:set/check
execute as @e[scores={astral.rem=1..}] at @s run function astral:fx/remate_tick
execute as @a run function astral:player/lvl
execute as @e[type=#astral:escalable,tag=!astral.seen] at @s run function astral:mob/roll
execute as @e[tag=astral.hpname] at @s if entity @a[distance=..32] run function astral:mob/vida
function astral:elite/fx
schedule function astral:loop/t20 20t replace
function astral:quest/tick
function astral:tanda2/ui_tick
