execute as @a run function astral:player/def
execute as @a[tag=!astral.vida100] run function astral:player/vida_base
execute as @a[scores={astral.m_es=1..}] at @s run function astral:mine/endstone
execute as @a[scores={astral.m_ch=1..}] at @s run function astral:mine/chorus
execute as @a[scores={astral.m_oak_log=1..}] at @s run function astral:mine/log
execute as @a[scores={astral.m_stripped_oak_log=1..}] at @s run function astral:mine/log
execute as @a[scores={astral.m_oak_wood=1..}] at @s run function astral:mine/log
execute as @a[scores={astral.m_stripped_oak_wood=1..}] at @s run function astral:mine/log
execute as @a[scores={astral.m_spruce_log=1..}] at @s run function astral:mine/log
execute as @a[scores={astral.m_stripped_spruce_log=1..}] at @s run function astral:mine/log
execute as @a[scores={astral.m_spruce_wood=1..}] at @s run function astral:mine/log
execute as @a[scores={astral.m_stripped_spruce_wood=1..}] at @s run function astral:mine/log
execute as @a[scores={astral.m_birch_log=1..}] at @s run function astral:mine/log
execute as @a[scores={astral.m_stripped_birch_log=1..}] at @s run function astral:mine/log
execute as @a[scores={astral.m_birch_wood=1..}] at @s run function astral:mine/log
execute as @a[scores={astral.m_stripped_birch_wood=1..}] at @s run function astral:mine/log
execute as @a[scores={astral.m_jungle_log=1..}] at @s run function astral:mine/log
execute as @a[scores={astral.m_stripped_jungle_log=1..}] at @s run function astral:mine/log
execute as @a[scores={astral.m_jungle_wood=1..}] at @s run function astral:mine/log
execute as @a[scores={astral.m_stripped_jungle_wood=1..}] at @s run function astral:mine/log
execute as @a[scores={astral.m_acacia_log=1..}] at @s run function astral:mine/log
execute as @a[scores={astral.m_stripped_acacia_log=1..}] at @s run function astral:mine/log
execute as @a[scores={astral.m_acacia_wood=1..}] at @s run function astral:mine/log
execute as @a[scores={astral.m_stripped_acacia_wood=1..}] at @s run function astral:mine/log
execute as @a[scores={astral.m_dark_oak_log=1..}] at @s run function astral:mine/log
execute as @a[scores={astral.m_stripped_dark_oak_log=1..}] at @s run function astral:mine/log
execute as @a[scores={astral.m_dark_oak_wood=1..}] at @s run function astral:mine/log
execute as @a[scores={astral.m_stripped_dark_oak_wood=1..}] at @s run function astral:mine/log
execute as @a[scores={astral.m_mangrove_log=1..}] at @s run function astral:mine/log
execute as @a[scores={astral.m_stripped_mangrove_log=1..}] at @s run function astral:mine/log
execute as @a[scores={astral.m_mangrove_wood=1..}] at @s run function astral:mine/log
execute as @a[scores={astral.m_stripped_mangrove_wood=1..}] at @s run function astral:mine/log
execute as @a[scores={astral.m_cherry_log=1..}] at @s run function astral:mine/log
execute as @a[scores={astral.m_stripped_cherry_log=1..}] at @s run function astral:mine/log
execute as @a[scores={astral.m_cherry_wood=1..}] at @s run function astral:mine/log
execute as @a[scores={astral.m_stripped_cherry_wood=1..}] at @s run function astral:mine/log
execute as @a[scores={astral.m_pale_oak_log=1..}] at @s run function astral:mine/log
execute as @a[scores={astral.m_stripped_pale_oak_log=1..}] at @s run function astral:mine/log
execute as @a[scores={astral.m_pale_oak_wood=1..}] at @s run function astral:mine/log
execute as @a[scores={astral.m_stripped_pale_oak_wood=1..}] at @s run function astral:mine/log
scoreboard players enable @a astral.guia
scoreboard players enable @a astral.forja
execute as @a[scores={astral.guia=1..}] run function astral:guide/give
schedule function astral:loop/t10 10t replace
