tellraw @s [{"text": "Bienvenido a AstralRPG. ", "color": "light_purple", "italic": false}, {"text": "Abri la guia con Esc -> Guia AstralRPG, o con /trigger astral.guia", "color": "gray", "italic": false}]
dialog show @s astral:guia
