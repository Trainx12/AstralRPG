loot give @s loot astral:guia
tellraw @s [{"text": "Bienvenido a AstralRPG. ", "color": "light_purple", "italic": false}, {"text": "Te dimos la guia de la Forja Astral. Si la perdes: /trigger astral.guia", "color": "gray", "italic": false}]
