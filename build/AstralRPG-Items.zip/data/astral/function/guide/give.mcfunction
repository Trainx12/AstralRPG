scoreboard players reset @s astral.guia
loot give @s loot astral:guia
