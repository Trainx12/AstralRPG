scoreboard players reset @s astral.guia
dialog show @s astral:guia
