scoreboard players set @s astral.bleed 5
function astral:fx/attacker_tier
execute if score #ht astral.tmp matches 0 run scoreboard players set @s astral.bleedd 15
execute if score #ht astral.tmp matches 1 run scoreboard players set @s astral.bleedd 15
execute if score #ht astral.tmp matches 2 run scoreboard players set @s astral.bleedd 15
execute if score #ht astral.tmp matches 3 run scoreboard players set @s astral.bleedd 15
execute if score #ht astral.tmp matches 4 run scoreboard players set @s astral.bleedd 15
execute if score #ht astral.tmp matches 5 run scoreboard players set @s astral.bleedd 15
particle minecraft:dust{color:[0.7,0.0,0.0],scale:1.2} ~ ~1 ~ 0.3 0.4 0.3 0 15
