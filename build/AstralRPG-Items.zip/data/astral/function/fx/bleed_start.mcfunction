scoreboard players set @s astral.bleed 5
particle minecraft:dust{color:[0.7,0.0,0.0],scale:1.2} ~ ~1 ~ 0.3 0.4 0.3 0 15
