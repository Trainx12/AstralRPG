scoreboard players remove @s astral.rem 1
execute if score @s astral.rem matches 1.. run return 0
tag @s add astral.nohit
execute store result storage astral:tmp hit.dmg float 0.1 run scoreboard players get @s astral.remd
function astral:fx/generic_hit with storage astral:tmp hit
particle minecraft:crit ~ ~1 ~ 0.3 0.4 0.3 0.1 8
tag @s remove astral.nohit
