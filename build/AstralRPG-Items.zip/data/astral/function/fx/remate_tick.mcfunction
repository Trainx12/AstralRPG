scoreboard players remove @s astral.rem 1
execute if score @s astral.rem matches 1.. run return 0
tag @s add astral.nohit
damage @s 1.5 minecraft:generic
particle minecraft:crit ~ ~1 ~ 0.3 0.4 0.3 0.1 8
tag @s remove astral.nohit
