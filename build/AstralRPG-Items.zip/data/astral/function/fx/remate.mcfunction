function astral:fx/victim_pct
execute if score #pct astral.tmp matches 50.. run return 0
execute if score #pct astral.tmp matches ..0 run return 0
# se aplica un rato despues para que no lo absorba la invulnerabilidad del golpe
scoreboard players set @s astral.rem 2
function astral:fx/attacker_tier
execute if score #ht astral.tmp matches 0 run scoreboard players set @s astral.remd 15
execute if score #ht astral.tmp matches 1 run scoreboard players set @s astral.remd 227
execute if score #ht astral.tmp matches 2 run scoreboard players set @s astral.remd 1059
execute if score #ht astral.tmp matches 3 run scoreboard players set @s astral.remd 4286
execute if score #ht astral.tmp matches 4 run scoreboard players set @s astral.remd 19841
execute if score #ht astral.tmp matches 5 run scoreboard players set @s astral.remd 78125
