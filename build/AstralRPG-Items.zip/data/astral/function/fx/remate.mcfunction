function astral:fx/victim_pct
execute if score #pct astral.tmp matches 50.. run return 0
execute if score #pct astral.tmp matches ..0 run return 0
# se aplica un rato despues para que no lo absorba la invulnerabilidad del golpe
scoreboard players set @s astral.rem 2
