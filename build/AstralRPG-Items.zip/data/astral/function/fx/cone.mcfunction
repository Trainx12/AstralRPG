tag @s add astral.src
execute on attacker run tag @s add astral.atk
execute as @e[tag=astral.atk,limit=1] at @s anchored eyes positioned ^ ^-0.6 ^2 run tag @e[type=!minecraft:player,type=!#astral:ignore,distance=..2,tag=!astral.src,tag=!astral.atk] add astral.tgt
execute as @e[tag=astral.atk,limit=1] at @s anchored eyes positioned ^ ^-0.6 ^3.5 run tag @e[type=!minecraft:player,type=!#astral:ignore,distance=..1.8,tag=!astral.src,tag=!astral.atk] add astral.tgt
execute as @e[tag=astral.atk,limit=1] at @s anchored eyes positioned ^ ^-0.4 ^2 run particle minecraft:sweep_attack ~ ~ ~ 0.8 0.2 0.8 0 4
tag @e[tag=astral.tgt] add astral.nohit
execute as @e[tag=astral.tgt] at @s run damage @s 4 minecraft:player_attack by @e[tag=astral.atk,limit=1]
tag @e[tag=astral.tgt] remove astral.nohit
tag @e[tag=astral.tgt] remove astral.tgt
tag @e[tag=astral.atk] remove astral.atk
tag @s remove astral.src
