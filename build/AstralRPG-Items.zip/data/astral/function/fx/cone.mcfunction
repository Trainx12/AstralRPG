tag @s add astral.src
execute on attacker run tag @s add astral.atk
execute as @e[tag=astral.atk,limit=1] at @s anchored eyes positioned ^ ^-0.6 ^2 run tag @e[type=!minecraft:player,type=!#astral:ignore,distance=..2,tag=!astral.src,tag=!astral.atk] add astral.tgt
execute as @e[tag=astral.atk,limit=1] at @s anchored eyes positioned ^ ^-0.6 ^3.5 run tag @e[type=!minecraft:player,type=!#astral:ignore,distance=..1.8,tag=!astral.src,tag=!astral.atk] add astral.tgt
execute as @e[tag=astral.atk,limit=1] at @s anchored eyes positioned ^ ^-0.4 ^2 run particle minecraft:sweep_attack ~ ~ ~ 0.8 0.2 0.8 0 4
tag @e[tag=astral.tgt] add astral.nohit
scoreboard players set #ht astral.tmp 0
scoreboard players operation #ht astral.tmp = @e[tag=astral.atk,limit=1] astral.ht
execute if score #ht astral.tmp matches 0 as @e[tag=astral.tgt] at @s run damage @s 4.0 minecraft:player_attack by @e[tag=astral.atk,limit=1]
execute if score #ht astral.tmp matches 1 as @e[tag=astral.tgt] at @s run damage @s 60.61 minecraft:player_attack by @e[tag=astral.atk,limit=1]
execute if score #ht astral.tmp matches 2 as @e[tag=astral.tgt] at @s run damage @s 282.49 minecraft:player_attack by @e[tag=astral.atk,limit=1]
execute if score #ht astral.tmp matches 3 as @e[tag=astral.tgt] at @s run damage @s 1142.86 minecraft:player_attack by @e[tag=astral.atk,limit=1]
execute if score #ht astral.tmp matches 4 as @e[tag=astral.tgt] at @s run damage @s 5291.01 minecraft:player_attack by @e[tag=astral.atk,limit=1]
execute if score #ht astral.tmp matches 5 as @e[tag=astral.tgt] at @s run damage @s 20833.33 minecraft:player_attack by @e[tag=astral.atk,limit=1]
tag @e[tag=astral.tgt] remove astral.nohit
tag @e[tag=astral.tgt] remove astral.tgt
tag @e[tag=astral.atk] remove astral.atk
tag @s remove astral.src
