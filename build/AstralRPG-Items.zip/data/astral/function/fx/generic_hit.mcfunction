$damage @s $(dmg) minecraft:generic
