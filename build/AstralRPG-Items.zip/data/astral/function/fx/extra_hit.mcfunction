tag @s add astral.nohit
execute on attacker run tag @s add astral.atk
$execute if entity @e[tag=astral.atk,limit=1] run damage @s $(dmg) minecraft:player_attack by @e[tag=astral.atk,limit=1]
$execute unless entity @e[tag=astral.atk,limit=1] run damage @s $(dmg) minecraft:generic
tag @e[tag=astral.atk] remove astral.atk
tag @s remove astral.nohit
