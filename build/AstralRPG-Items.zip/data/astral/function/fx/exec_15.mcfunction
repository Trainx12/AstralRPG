execute if entity @s[type=#astral:bosses] run return 0
function astral:fx/victim_pct
execute if score #pct astral.tmp matches 15.. run return 0
execute if score #pct astral.tmp matches ..0 run return 0
particle minecraft:damage_indicator ~ ~1 ~ 0.3 0.3 0.3 0.1 10
playsound minecraft:entity.player.attack.crit player @a[distance=..16] ~ ~ ~ 1 0.6
function astral:fx/extra_hit {dmg:1.0E9}
