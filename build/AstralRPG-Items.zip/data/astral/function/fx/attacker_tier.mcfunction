scoreboard players set #ht astral.tmp 0
execute on attacker run scoreboard players operation #ht astral.tmp = @s astral.ht
# contra jugadores (arena) el sangrado y el remate quedan como antes
execute if entity @s[type=minecraft:player] run scoreboard players set #ht astral.tmp 0
