tag @s add astral.src
execute on attacker run tag @s add astral.atk
tag @e[type=!minecraft:player,type=!#astral:ignore,distance=..2.5,tag=!astral.src,tag=!astral.atk] add astral.tgt
tag @e[tag=astral.tgt] add astral.nohit
execute as @e[tag=astral.tgt] at @s run damage @s 5 minecraft:player_attack by @e[tag=astral.atk,limit=1]
particle minecraft:sweep_attack ~ ~1 ~ 1 0.2 1 0 5
tag @e[tag=astral.tgt] remove astral.nohit
tag @e[tag=astral.tgt] remove astral.tgt
tag @e[tag=astral.atk] remove astral.atk
tag @s remove astral.src
