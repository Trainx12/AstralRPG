tag @s add astral.src
execute on attacker run tag @s add astral.atk
tag @e[type=!minecraft:player,type=!#astral:ignore,distance=..2.5,tag=!astral.src,tag=!astral.atk] add astral.tgt
tag @e[tag=astral.tgt] add astral.nohit
scoreboard players set #ht astral.tmp 0
scoreboard players operation #ht astral.tmp = @e[tag=astral.atk,limit=1] astral.ht
execute if score #ht astral.tmp matches 0 as @e[tag=astral.tgt] at @s run damage @s 5.0 minecraft:player_attack by @e[tag=astral.atk,limit=1]
execute if score #ht astral.tmp matches 1 as @e[tag=astral.tgt] at @s run damage @s 75.76 minecraft:player_attack by @e[tag=astral.atk,limit=1]
execute if score #ht astral.tmp matches 2 as @e[tag=astral.tgt] at @s run damage @s 353.11 minecraft:player_attack by @e[tag=astral.atk,limit=1]
execute if score #ht astral.tmp matches 3 as @e[tag=astral.tgt] at @s run damage @s 1428.57 minecraft:player_attack by @e[tag=astral.atk,limit=1]
execute if score #ht astral.tmp matches 4 as @e[tag=astral.tgt] at @s run damage @s 6613.76 minecraft:player_attack by @e[tag=astral.atk,limit=1]
execute if score #ht astral.tmp matches 5 as @e[tag=astral.tgt] at @s run damage @s 26041.67 minecraft:player_attack by @e[tag=astral.atk,limit=1]
particle minecraft:sweep_attack ~ ~1 ~ 1 0.2 1 0 5
tag @e[tag=astral.tgt] remove astral.nohit
tag @e[tag=astral.tgt] remove astral.tgt
tag @e[tag=astral.atk] remove astral.atk
tag @s remove astral.src
