scoreboard players remove @s astral.bleed 1
particle minecraft:dust{color:[0.7,0.0,0.0],scale:1.0} ~ ~1 ~ 0.3 0.4 0.3 0 8
tag @s add astral.nohit
execute store result storage astral:tmp hit.dmg float 0.1 run scoreboard players get @s astral.bleedd
function astral:fx/generic_hit with storage astral:tmp hit
tag @s remove astral.nohit
