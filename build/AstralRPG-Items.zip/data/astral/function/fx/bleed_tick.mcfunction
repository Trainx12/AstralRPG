scoreboard players remove @s astral.bleed 1
particle minecraft:dust{color:[0.7,0.0,0.0],scale:1.0} ~ ~1 ~ 0.3 0.4 0.3 0 8
tag @s add astral.nohit
damage @s 1.5 minecraft:generic
tag @s remove astral.nohit
