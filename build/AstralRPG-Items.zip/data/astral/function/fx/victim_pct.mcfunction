execute store result score #h astral.tmp run data get entity @s Health 100
execute store result score #m astral.tmp run attribute @s minecraft:max_health get 1
execute if score #m astral.tmp matches ..0 run scoreboard players set #m astral.tmp 1
scoreboard players operation #h astral.tmp /= #m astral.tmp
scoreboard players operation #pct astral.tmp = #h astral.tmp
