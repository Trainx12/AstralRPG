$item modify entity @s weapon.mainhand astral:ficha/$(id)/5
