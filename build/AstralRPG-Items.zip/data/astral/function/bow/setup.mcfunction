tag @s add astral.newarrow
data modify entity @s Owner set from entity @a[tag=astral.archer,limit=1] UUID
data modify entity @s crit set value 1b
data modify entity @s damage set value 2.0d
execute if score #free astral.tmp matches 1 run data modify entity @s pickup set value 2b
execute if score #free astral.tmp matches 0 run data modify entity @s pickup set value 1b
execute summon minecraft:marker run function astral:bow/vec2
tag @s remove astral.newarrow
