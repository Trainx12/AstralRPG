tag @s remove astral.bowshot
execute on origin run tag @s add astral.shooter
scoreboard players set #red astral.tmp -1
execute if entity @a[tag=astral.shooter,limit=1] as @a[tag=astral.shooter,limit=1] if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"arco_1"}}] run scoreboard players set #red astral.tmp 10
execute if entity @a[tag=astral.shooter,limit=1] as @a[tag=astral.shooter,limit=1] if items entity @s weapon.offhand *[minecraft:custom_data~{astral:{id:"arco_1"}}] run scoreboard players set #red astral.tmp 10
execute if entity @a[tag=astral.shooter,limit=1] as @a[tag=astral.shooter,limit=1] if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"arco_2"}}] run scoreboard players set #red astral.tmp 25
execute if entity @a[tag=astral.shooter,limit=1] as @a[tag=astral.shooter,limit=1] if items entity @s weapon.offhand *[minecraft:custom_data~{astral:{id:"arco_2"}}] run scoreboard players set #red astral.tmp 25
execute if entity @a[tag=astral.shooter,limit=1] as @a[tag=astral.shooter,limit=1] if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"arco_3"}}] run scoreboard players set #red astral.tmp 45
execute if entity @a[tag=astral.shooter,limit=1] as @a[tag=astral.shooter,limit=1] if items entity @s weapon.offhand *[minecraft:custom_data~{astral:{id:"arco_3"}}] run scoreboard players set #red astral.tmp 45
execute if entity @a[tag=astral.shooter,limit=1] as @a[tag=astral.shooter,limit=1] if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"arco_4"}}] run scoreboard players set #red astral.tmp 65
execute if entity @a[tag=astral.shooter,limit=1] as @a[tag=astral.shooter,limit=1] if items entity @s weapon.offhand *[minecraft:custom_data~{astral:{id:"arco_4"}}] run scoreboard players set #red astral.tmp 65
execute if entity @a[tag=astral.shooter,limit=1] as @a[tag=astral.shooter,limit=1] if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"arco_5"}}] run scoreboard players set #red astral.tmp 95
execute if entity @a[tag=astral.shooter,limit=1] as @a[tag=astral.shooter,limit=1] if items entity @s weapon.offhand *[minecraft:custom_data~{astral:{id:"arco_5"}}] run scoreboard players set #red astral.tmp 95
execute if entity @a[tag=astral.shooter,limit=1] as @a[tag=astral.shooter,limit=1] if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"arco_6"}}] run scoreboard players set #red astral.tmp 95
execute if entity @a[tag=astral.shooter,limit=1] as @a[tag=astral.shooter,limit=1] if items entity @s weapon.offhand *[minecraft:custom_data~{astral:{id:"arco_6"}}] run scoreboard players set #red astral.tmp 95
execute if entity @a[tag=astral.shooter,limit=1] as @a[tag=astral.shooter,limit=1] if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"arco_7"}}] run scoreboard players set #red astral.tmp 95
execute if entity @a[tag=astral.shooter,limit=1] as @a[tag=astral.shooter,limit=1] if items entity @s weapon.offhand *[minecraft:custom_data~{astral:{id:"arco_7"}}] run scoreboard players set #red astral.tmp 95
execute if entity @a[tag=astral.shooter,limit=1] as @a[tag=astral.shooter,limit=1] if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"arco_8"}}] run scoreboard players set #red astral.tmp 95
execute if entity @a[tag=astral.shooter,limit=1] as @a[tag=astral.shooter,limit=1] if items entity @s weapon.offhand *[minecraft:custom_data~{astral:{id:"arco_8"}}] run scoreboard players set #red astral.tmp 95
execute if entity @a[tag=astral.shooter,limit=1] as @a[tag=astral.shooter,limit=1] if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"arco_9"}}] run scoreboard players set #red astral.tmp 95
execute if entity @a[tag=astral.shooter,limit=1] as @a[tag=astral.shooter,limit=1] if items entity @s weapon.offhand *[minecraft:custom_data~{astral:{id:"arco_9"}}] run scoreboard players set #red astral.tmp 95
execute if entity @a[tag=astral.shooter,limit=1] as @a[tag=astral.shooter,limit=1] if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"arco_10"}}] run scoreboard players set #red astral.tmp 95
execute if entity @a[tag=astral.shooter,limit=1] as @a[tag=astral.shooter,limit=1] if items entity @s weapon.offhand *[minecraft:custom_data~{astral:{id:"arco_10"}}] run scoreboard players set #red astral.tmp 95
execute as @a[tag=astral.shooter,limit=1] if items entity @s armor.chest *[minecraft:custom_data~{astral:{id:"arquero_4_chestplate"}}] if score #red astral.tmp matches 0.. run scoreboard players add #red astral.tmp 10
execute as @a[tag=astral.shooter,limit=1] if items entity @s armor.chest *[minecraft:custom_data~{astral:{id:"arquero_5_chestplate"}}] if score #red astral.tmp matches 0.. run scoreboard players add #red astral.tmp 20
execute as @a[tag=astral.shooter,limit=1] if items entity @s armor.chest *[minecraft:custom_data~{astral:{id:"arquero_6_chestplate"}}] if score #red astral.tmp matches 0.. run scoreboard players add #red astral.tmp 24
execute as @a[tag=astral.shooter,limit=1] if items entity @s armor.chest *[minecraft:custom_data~{astral:{id:"arquero_7_chestplate"}}] if score #red astral.tmp matches 0.. run scoreboard players add #red astral.tmp 28
execute as @a[tag=astral.shooter,limit=1] if items entity @s armor.chest *[minecraft:custom_data~{astral:{id:"arquero_8_chestplate"}}] if score #red astral.tmp matches 0.. run scoreboard players add #red astral.tmp 32
execute as @a[tag=astral.shooter,limit=1] if items entity @s armor.chest *[minecraft:custom_data~{astral:{id:"arquero_9_chestplate"}}] if score #red astral.tmp matches 0.. run scoreboard players add #red astral.tmp 36
execute as @a[tag=astral.shooter,limit=1] if items entity @s armor.chest *[minecraft:custom_data~{astral:{id:"arquero_10_chestplate"}}] if score #red astral.tmp matches 0.. run scoreboard players add #red astral.tmp 40
execute if score #red astral.tmp matches ..-1 run return run tag @a remove astral.shooter
execute if score #red astral.tmp matches 0..4 run scoreboard players set #thr astral.tmp 90000
execute if score #red astral.tmp matches 5..9 run scoreboard players set #thr astral.tmp 78540
execute if score #red astral.tmp matches 10..14 run scoreboard players set #thr astral.tmp 68121
execute if score #red astral.tmp matches 15..19 run scoreboard players set #thr astral.tmp 58685
execute if score #red astral.tmp matches 20..24 run scoreboard players set #thr astral.tmp 50176
execute if score #red astral.tmp matches 25..29 run scoreboard players set #thr astral.tmp 42539
execute if score #red astral.tmp matches 30..34 run scoreboard players set #thr astral.tmp 35721
execute if score #red astral.tmp matches 35..39 run scoreboard players set #thr astral.tmp 29670
execute if score #red astral.tmp matches 40..44 run scoreboard players set #thr astral.tmp 24336
execute if score #red astral.tmp matches 45..49 run scoreboard players set #thr astral.tmp 19670
execute if score #red astral.tmp matches 50..54 run scoreboard players set #thr astral.tmp 15625
execute if score #red astral.tmp matches 55..59 run scoreboard players set #thr astral.tmp 12155
execute if score #red astral.tmp matches 60..64 run scoreboard players set #thr astral.tmp 9216
execute if score #red astral.tmp matches 65..69 run scoreboard players set #thr astral.tmp 6765
execute if score #red astral.tmp matches 70..74 run scoreboard players set #thr astral.tmp 4761
execute if score #red astral.tmp matches 75..79 run scoreboard players set #thr astral.tmp 3164
execute if score #red astral.tmp matches 80..84 run scoreboard players set #thr astral.tmp 1935
execute if score #red astral.tmp matches 85..89 run scoreboard players set #thr astral.tmp 1040
execute if score #red astral.tmp matches 90..94 run scoreboard players set #thr astral.tmp 440
execute if score #red astral.tmp matches 95..99 run scoreboard players set #thr astral.tmp 105
execute if score #red astral.tmp matches 100..104 run scoreboard players set #thr astral.tmp 37
execute if score #red astral.tmp matches 105..109 run scoreboard players set #thr astral.tmp 37
execute if score #red astral.tmp matches 110..114 run scoreboard players set #thr astral.tmp 37
execute if score #red astral.tmp matches 115..119 run scoreboard players set #thr astral.tmp 37
execute if score #red astral.tmp matches 120..124 run scoreboard players set #thr astral.tmp 37
execute if score #red astral.tmp matches 125..129 run scoreboard players set #thr astral.tmp 37
execute if score #red astral.tmp matches 130..134 run scoreboard players set #thr astral.tmp 37
execute if score #red astral.tmp matches 135..139 run scoreboard players set #thr astral.tmp 37
execute if score #red astral.tmp matches 140..144 run scoreboard players set #thr astral.tmp 37
execute if score #red astral.tmp matches 145..149 run scoreboard players set #thr astral.tmp 37
execute if score #red astral.tmp matches 150..154 run scoreboard players set #thr astral.tmp 37
execute if score #red astral.tmp matches 155..159 run scoreboard players set #thr astral.tmp 37
execute if score #red astral.tmp matches 160..164 run scoreboard players set #thr astral.tmp 37
execute if score #red astral.tmp matches 165..169 run scoreboard players set #thr astral.tmp 37
execute if score #red astral.tmp matches 170..174 run scoreboard players set #thr astral.tmp 37
execute if score #red astral.tmp matches 175..179 run scoreboard players set #thr astral.tmp 37
execute if score #red astral.tmp matches 180..184 run scoreboard players set #thr astral.tmp 37
execute if score #red astral.tmp matches 185..189 run scoreboard players set #thr astral.tmp 37
execute if score #red astral.tmp matches 190..194 run scoreboard players set #thr astral.tmp 37
execute if score #red astral.tmp matches 195..199 run scoreboard players set #thr astral.tmp 37
execute store result score #x astral.tmp run data get entity @s Motion[0] 100
execute store result score #y astral.tmp run data get entity @s Motion[1] 100
execute store result score #z astral.tmp run data get entity @s Motion[2] 100
scoreboard players operation #x astral.tmp *= #x astral.tmp
scoreboard players operation #y astral.tmp *= #y astral.tmp
scoreboard players operation #z astral.tmp *= #z astral.tmp
scoreboard players operation #x astral.tmp += #y astral.tmp
scoreboard players operation #x astral.tmp += #z astral.tmp
execute if score #x astral.tmp >= #thr astral.tmp at @s rotated as @a[tag=astral.shooter,limit=1] summon minecraft:marker run function astral:bow/vec
tag @a remove astral.shooter
