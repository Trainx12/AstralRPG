execute store result score #ox astral.tmp run data get entity @s Pos[0] 1000
execute store result score #oy astral.tmp run data get entity @s Pos[1] 1000
execute store result score #oz astral.tmp run data get entity @s Pos[2] 1000
tp @s ^ ^ ^3
execute store result score #nx astral.tmp run data get entity @s Pos[0] 1000
execute store result score #ny astral.tmp run data get entity @s Pos[1] 1000
execute store result score #nz astral.tmp run data get entity @s Pos[2] 1000
scoreboard players operation #nx astral.tmp -= #ox astral.tmp
scoreboard players operation #ny astral.tmp -= #oy astral.tmp
scoreboard players operation #nz astral.tmp -= #oz astral.tmp
kill @s
execute as @e[type=#minecraft:arrows,distance=..0.5,limit=1,sort=nearest] run function astral:bow/apply
