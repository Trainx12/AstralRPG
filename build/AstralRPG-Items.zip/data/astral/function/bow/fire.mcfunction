# necesita flechas (salvo creativo o Arco Astral)
scoreboard players set #free astral.tmp 0
execute if entity @s[gamemode=creative] run scoreboard players set #free astral.tmp 1
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"arco_5"}}] run scoreboard players set #free astral.tmp 1
execute if score #free astral.tmp matches 0 unless items entity @s container.* minecraft:arrow unless items entity @s weapon.offhand minecraft:arrow run return 0
execute if score #free astral.tmp matches 0 run clear @s minecraft:arrow 1
tag @s add astral.archer
execute anchored eyes positioned ^ ^ ^0.6 summon minecraft:arrow run function astral:bow/setup
tag @s remove astral.archer
playsound minecraft:entity.arrow.shoot player @a[distance=..16] ~ ~ ~ 1 1.2
