tag @s add astral.bowshot
scoreboard players set #flechas astral.tmp 1
