tag @s add astral.bowshot
