advancement revoke @s only astral:bow/hold
tag @s add astral.drew
scoreboard players add @s astral.draw 1
scoreboard players set #need astral.tmp 20
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"arco_1"}}] run scoreboard players set #need astral.tmp 18
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"arco_2"}}] run scoreboard players set #need astral.tmp 15
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"arco_3"}}] run scoreboard players set #need astral.tmp 12
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"arco_4"}}] run scoreboard players set #need astral.tmp 10
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"arco_5"}}] run scoreboard players set #need astral.tmp 8
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"arco_6"}}] run scoreboard players set #need astral.tmp 7
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"arco_7"}}] run scoreboard players set #need astral.tmp 6
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"arco_8"}}] run scoreboard players set #need astral.tmp 5
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"arco_9"}}] run scoreboard players set #need astral.tmp 5
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"arco_10"}}] run scoreboard players set #need astral.tmp 4
execute if items entity @s armor.chest *[minecraft:custom_data~{astral:{id:"arquero_4_chestplate"}}] run scoreboard players remove #need astral.tmp 0
execute if items entity @s armor.chest *[minecraft:custom_data~{astral:{id:"arquero_5_chestplate"}}] run scoreboard players remove #need astral.tmp 1
execute if items entity @s armor.chest *[minecraft:custom_data~{astral:{id:"arquero_6_chestplate"}}] run scoreboard players remove #need astral.tmp 1
execute if items entity @s armor.chest *[minecraft:custom_data~{astral:{id:"arquero_7_chestplate"}}] run scoreboard players remove #need astral.tmp 1
execute if items entity @s armor.chest *[minecraft:custom_data~{astral:{id:"arquero_8_chestplate"}}] run scoreboard players remove #need astral.tmp 1
execute if items entity @s armor.chest *[minecraft:custom_data~{astral:{id:"arquero_9_chestplate"}}] run scoreboard players remove #need astral.tmp 1
execute if items entity @s armor.chest *[minecraft:custom_data~{astral:{id:"arquero_10_chestplate"}}] run scoreboard players remove #need astral.tmp 2
execute if score #need astral.tmp matches ..2 run scoreboard players set #need astral.tmp 3
execute if score @s astral.draw < #need astral.tmp run return 0
scoreboard players set @s astral.draw 0
function astral:bow/fire
