execute store result entity @s Motion[0] double 0.001 run scoreboard players get #nx astral.tmp
execute store result entity @s Motion[1] double 0.001 run scoreboard players get #ny astral.tmp
execute store result entity @s Motion[2] double 0.001 run scoreboard players get #nz astral.tmp
data modify entity @s crit set value 1b
