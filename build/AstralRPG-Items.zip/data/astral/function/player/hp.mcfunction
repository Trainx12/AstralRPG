execute store result score @s astral.hp run data get entity @s Health 100
execute store result score #m astral.tmp run attribute @s minecraft:max_health get 1
execute if score #m astral.tmp matches ..0 run scoreboard players set #m astral.tmp 1
scoreboard players operation @s astral.hp /= #m astral.tmp
