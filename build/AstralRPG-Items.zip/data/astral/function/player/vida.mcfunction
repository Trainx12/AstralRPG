execute store result score @s astral.vida run data get entity @s Health 10
execute store result score @s astral.vidamax run attribute @s minecraft:max_health get 10
execute if score @s astral.at matches 0 run scoreboard players set #vm astral.tmp 1
execute if score @s astral.at matches 1 run scoreboard players set #vm astral.tmp 25
execute if score @s astral.at matches 2 run scoreboard players set #vm astral.tmp 120
execute if score @s astral.at matches 3 run scoreboard players set #vm astral.tmp 575
execute if score @s astral.at matches 4 run scoreboard players set #vm astral.tmp 2750
execute if score @s astral.at matches 5 run scoreboard players set #vm astral.tmp 13125
scoreboard players operation @s astral.vida *= #vm astral.tmp
scoreboard players operation @s astral.vidamax *= #vm astral.tmp
scoreboard players operation @s astral.vida /= #10 astral.const
scoreboard players operation @s astral.vidamax /= #10 astral.const
