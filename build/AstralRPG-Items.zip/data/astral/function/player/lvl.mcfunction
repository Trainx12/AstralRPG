scoreboard players set @s astral.lvl 0
execute if score @s astral.lvl matches ..0 if items entity @s armor.head *[minecraft:custom_data~{astral:{tier:1}}] run scoreboard players set @s astral.lvl 1
execute if score @s astral.lvl matches ..0 if items entity @s armor.chest *[minecraft:custom_data~{astral:{tier:1}}] run scoreboard players set @s astral.lvl 1
execute if score @s astral.lvl matches ..0 if items entity @s armor.legs *[minecraft:custom_data~{astral:{tier:1}}] run scoreboard players set @s astral.lvl 1
execute if score @s astral.lvl matches ..0 if items entity @s armor.feet *[minecraft:custom_data~{astral:{tier:1}}] run scoreboard players set @s astral.lvl 1
execute if score @s astral.lvl matches ..0 if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{tier:1}}] run scoreboard players set @s astral.lvl 1
execute if score @s astral.lvl matches ..0 if items entity @s weapon.offhand *[minecraft:custom_data~{astral:{tier:1}}] run scoreboard players set @s astral.lvl 1
execute if score @s astral.lvl matches ..1 if items entity @s armor.head *[minecraft:custom_data~{astral:{tier:2}}] run scoreboard players set @s astral.lvl 2
execute if score @s astral.lvl matches ..1 if items entity @s armor.chest *[minecraft:custom_data~{astral:{tier:2}}] run scoreboard players set @s astral.lvl 2
execute if score @s astral.lvl matches ..1 if items entity @s armor.legs *[minecraft:custom_data~{astral:{tier:2}}] run scoreboard players set @s astral.lvl 2
execute if score @s astral.lvl matches ..1 if items entity @s armor.feet *[minecraft:custom_data~{astral:{tier:2}}] run scoreboard players set @s astral.lvl 2
execute if score @s astral.lvl matches ..1 if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{tier:2}}] run scoreboard players set @s astral.lvl 2
execute if score @s astral.lvl matches ..1 if items entity @s weapon.offhand *[minecraft:custom_data~{astral:{tier:2}}] run scoreboard players set @s astral.lvl 2
execute if score @s astral.lvl matches ..2 if items entity @s armor.head *[minecraft:custom_data~{astral:{tier:3}}] run scoreboard players set @s astral.lvl 3
execute if score @s astral.lvl matches ..2 if items entity @s armor.chest *[minecraft:custom_data~{astral:{tier:3}}] run scoreboard players set @s astral.lvl 3
execute if score @s astral.lvl matches ..2 if items entity @s armor.legs *[minecraft:custom_data~{astral:{tier:3}}] run scoreboard players set @s astral.lvl 3
execute if score @s astral.lvl matches ..2 if items entity @s armor.feet *[minecraft:custom_data~{astral:{tier:3}}] run scoreboard players set @s astral.lvl 3
execute if score @s astral.lvl matches ..2 if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{tier:3}}] run scoreboard players set @s astral.lvl 3
execute if score @s astral.lvl matches ..2 if items entity @s weapon.offhand *[minecraft:custom_data~{astral:{tier:3}}] run scoreboard players set @s astral.lvl 3
execute if score @s astral.lvl matches ..3 if items entity @s armor.head *[minecraft:custom_data~{astral:{tier:4}}] run scoreboard players set @s astral.lvl 4
execute if score @s astral.lvl matches ..3 if items entity @s armor.chest *[minecraft:custom_data~{astral:{tier:4}}] run scoreboard players set @s astral.lvl 4
execute if score @s astral.lvl matches ..3 if items entity @s armor.legs *[minecraft:custom_data~{astral:{tier:4}}] run scoreboard players set @s astral.lvl 4
execute if score @s astral.lvl matches ..3 if items entity @s armor.feet *[minecraft:custom_data~{astral:{tier:4}}] run scoreboard players set @s astral.lvl 4
execute if score @s astral.lvl matches ..3 if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{tier:4}}] run scoreboard players set @s astral.lvl 4
execute if score @s astral.lvl matches ..3 if items entity @s weapon.offhand *[minecraft:custom_data~{astral:{tier:4}}] run scoreboard players set @s astral.lvl 4
execute if score @s astral.lvl matches ..4 if items entity @s armor.head *[minecraft:custom_data~{astral:{tier:5}}] run scoreboard players set @s astral.lvl 5
execute if score @s astral.lvl matches ..4 if items entity @s armor.chest *[minecraft:custom_data~{astral:{tier:5}}] run scoreboard players set @s astral.lvl 5
execute if score @s astral.lvl matches ..4 if items entity @s armor.legs *[minecraft:custom_data~{astral:{tier:5}}] run scoreboard players set @s astral.lvl 5
execute if score @s astral.lvl matches ..4 if items entity @s armor.feet *[minecraft:custom_data~{astral:{tier:5}}] run scoreboard players set @s astral.lvl 5
execute if score @s astral.lvl matches ..4 if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{tier:5}}] run scoreboard players set @s astral.lvl 5
execute if score @s astral.lvl matches ..4 if items entity @s weapon.offhand *[minecraft:custom_data~{astral:{tier:5}}] run scoreboard players set @s astral.lvl 5
scoreboard players set @s astral.ht 0
scoreboard players set @s astral.wt 0
scoreboard players set @s astral.at 0
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{type:"weapon",tier:1}}] run scoreboard players set @s astral.ht 1
execute if score @s astral.wt matches ..0 if items entity @s container.* *[minecraft:custom_data~{astral:{type:"weapon",tier:1}}] run scoreboard players set @s astral.wt 1
execute if score @s astral.wt matches ..0 if items entity @s weapon.offhand *[minecraft:custom_data~{astral:{type:"weapon",tier:1}}] run scoreboard players set @s astral.wt 1
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{type:"staff",tier:1}}] run scoreboard players set @s astral.ht 1
execute if score @s astral.wt matches ..0 if items entity @s container.* *[minecraft:custom_data~{astral:{type:"staff",tier:1}}] run scoreboard players set @s astral.wt 1
execute if score @s astral.wt matches ..0 if items entity @s weapon.offhand *[minecraft:custom_data~{astral:{type:"staff",tier:1}}] run scoreboard players set @s astral.wt 1
execute if score @s astral.at matches ..0 if items entity @s armor.head *[minecraft:custom_data~{astral:{type:"armor",tier:1}}] run scoreboard players set @s astral.at 1
execute if score @s astral.at matches ..0 if items entity @s armor.chest *[minecraft:custom_data~{astral:{type:"armor",tier:1}}] run scoreboard players set @s astral.at 1
execute if score @s astral.at matches ..0 if items entity @s armor.legs *[minecraft:custom_data~{astral:{type:"armor",tier:1}}] run scoreboard players set @s astral.at 1
execute if score @s astral.at matches ..0 if items entity @s armor.feet *[minecraft:custom_data~{astral:{type:"armor",tier:1}}] run scoreboard players set @s astral.at 1
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{type:"weapon",tier:2}}] run scoreboard players set @s astral.ht 2
execute if score @s astral.wt matches ..1 if items entity @s container.* *[minecraft:custom_data~{astral:{type:"weapon",tier:2}}] run scoreboard players set @s astral.wt 2
execute if score @s astral.wt matches ..1 if items entity @s weapon.offhand *[minecraft:custom_data~{astral:{type:"weapon",tier:2}}] run scoreboard players set @s astral.wt 2
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{type:"staff",tier:2}}] run scoreboard players set @s astral.ht 2
execute if score @s astral.wt matches ..1 if items entity @s container.* *[minecraft:custom_data~{astral:{type:"staff",tier:2}}] run scoreboard players set @s astral.wt 2
execute if score @s astral.wt matches ..1 if items entity @s weapon.offhand *[minecraft:custom_data~{astral:{type:"staff",tier:2}}] run scoreboard players set @s astral.wt 2
execute if score @s astral.at matches ..1 if items entity @s armor.head *[minecraft:custom_data~{astral:{type:"armor",tier:2}}] run scoreboard players set @s astral.at 2
execute if score @s astral.at matches ..1 if items entity @s armor.chest *[minecraft:custom_data~{astral:{type:"armor",tier:2}}] run scoreboard players set @s astral.at 2
execute if score @s astral.at matches ..1 if items entity @s armor.legs *[minecraft:custom_data~{astral:{type:"armor",tier:2}}] run scoreboard players set @s astral.at 2
execute if score @s astral.at matches ..1 if items entity @s armor.feet *[minecraft:custom_data~{astral:{type:"armor",tier:2}}] run scoreboard players set @s astral.at 2
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{type:"weapon",tier:3}}] run scoreboard players set @s astral.ht 3
execute if score @s astral.wt matches ..2 if items entity @s container.* *[minecraft:custom_data~{astral:{type:"weapon",tier:3}}] run scoreboard players set @s astral.wt 3
execute if score @s astral.wt matches ..2 if items entity @s weapon.offhand *[minecraft:custom_data~{astral:{type:"weapon",tier:3}}] run scoreboard players set @s astral.wt 3
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{type:"staff",tier:3}}] run scoreboard players set @s astral.ht 3
execute if score @s astral.wt matches ..2 if items entity @s container.* *[minecraft:custom_data~{astral:{type:"staff",tier:3}}] run scoreboard players set @s astral.wt 3
execute if score @s astral.wt matches ..2 if items entity @s weapon.offhand *[minecraft:custom_data~{astral:{type:"staff",tier:3}}] run scoreboard players set @s astral.wt 3
execute if score @s astral.at matches ..2 if items entity @s armor.head *[minecraft:custom_data~{astral:{type:"armor",tier:3}}] run scoreboard players set @s astral.at 3
execute if score @s astral.at matches ..2 if items entity @s armor.chest *[minecraft:custom_data~{astral:{type:"armor",tier:3}}] run scoreboard players set @s astral.at 3
execute if score @s astral.at matches ..2 if items entity @s armor.legs *[minecraft:custom_data~{astral:{type:"armor",tier:3}}] run scoreboard players set @s astral.at 3
execute if score @s astral.at matches ..2 if items entity @s armor.feet *[minecraft:custom_data~{astral:{type:"armor",tier:3}}] run scoreboard players set @s astral.at 3
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{type:"weapon",tier:4}}] run scoreboard players set @s astral.ht 4
execute if score @s astral.wt matches ..3 if items entity @s container.* *[minecraft:custom_data~{astral:{type:"weapon",tier:4}}] run scoreboard players set @s astral.wt 4
execute if score @s astral.wt matches ..3 if items entity @s weapon.offhand *[minecraft:custom_data~{astral:{type:"weapon",tier:4}}] run scoreboard players set @s astral.wt 4
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{type:"staff",tier:4}}] run scoreboard players set @s astral.ht 4
execute if score @s astral.wt matches ..3 if items entity @s container.* *[minecraft:custom_data~{astral:{type:"staff",tier:4}}] run scoreboard players set @s astral.wt 4
execute if score @s astral.wt matches ..3 if items entity @s weapon.offhand *[minecraft:custom_data~{astral:{type:"staff",tier:4}}] run scoreboard players set @s astral.wt 4
execute if score @s astral.at matches ..3 if items entity @s armor.head *[minecraft:custom_data~{astral:{type:"armor",tier:4}}] run scoreboard players set @s astral.at 4
execute if score @s astral.at matches ..3 if items entity @s armor.chest *[minecraft:custom_data~{astral:{type:"armor",tier:4}}] run scoreboard players set @s astral.at 4
execute if score @s astral.at matches ..3 if items entity @s armor.legs *[minecraft:custom_data~{astral:{type:"armor",tier:4}}] run scoreboard players set @s astral.at 4
execute if score @s astral.at matches ..3 if items entity @s armor.feet *[minecraft:custom_data~{astral:{type:"armor",tier:4}}] run scoreboard players set @s astral.at 4
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{type:"weapon",tier:5}}] run scoreboard players set @s astral.ht 5
execute if score @s astral.wt matches ..4 if items entity @s container.* *[minecraft:custom_data~{astral:{type:"weapon",tier:5}}] run scoreboard players set @s astral.wt 5
execute if score @s astral.wt matches ..4 if items entity @s weapon.offhand *[minecraft:custom_data~{astral:{type:"weapon",tier:5}}] run scoreboard players set @s astral.wt 5
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{type:"staff",tier:5}}] run scoreboard players set @s astral.ht 5
execute if score @s astral.wt matches ..4 if items entity @s container.* *[minecraft:custom_data~{astral:{type:"staff",tier:5}}] run scoreboard players set @s astral.wt 5
execute if score @s astral.wt matches ..4 if items entity @s weapon.offhand *[minecraft:custom_data~{astral:{type:"staff",tier:5}}] run scoreboard players set @s astral.wt 5
execute if score @s astral.at matches ..4 if items entity @s armor.head *[minecraft:custom_data~{astral:{type:"armor",tier:5}}] run scoreboard players set @s astral.at 5
execute if score @s astral.at matches ..4 if items entity @s armor.chest *[minecraft:custom_data~{astral:{type:"armor",tier:5}}] run scoreboard players set @s astral.at 5
execute if score @s astral.at matches ..4 if items entity @s armor.legs *[minecraft:custom_data~{astral:{type:"armor",tier:5}}] run scoreboard players set @s astral.at 5
execute if score @s astral.at matches ..4 if items entity @s armor.feet *[minecraft:custom_data~{astral:{type:"armor",tier:5}}] run scoreboard players set @s astral.at 5
tag @s remove astral.ht0
tag @s remove astral.ht1
tag @s remove astral.ht2
tag @s remove astral.ht3
tag @s remove astral.ht4
tag @s remove astral.ht5
execute if score @s astral.ht matches 0 run tag @s add astral.ht0
execute if score @s astral.ht matches 1 run tag @s add astral.ht1
execute if score @s astral.ht matches 2 run tag @s add astral.ht2
execute if score @s astral.ht matches 3 run tag @s add astral.ht3
execute if score @s astral.ht matches 4 run tag @s add astral.ht4
execute if score @s astral.ht matches 5 run tag @s add astral.ht5
