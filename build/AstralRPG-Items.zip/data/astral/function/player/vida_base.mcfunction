attribute @s minecraft:max_health base set 100
tag @s add astral.vida100
effect give @s minecraft:instant_health 1 6 true
