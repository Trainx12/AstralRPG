scoreboard players set #d astral.tmp 0
data modify storage astral:tmp eq set value {}
data modify storage astral:tmp eq set from entity @s equipment
execute store result score #p astral.tmp run data get storage astral:tmp eq.head.components."minecraft:custom_data".astral.def
scoreboard players operation #d astral.tmp += #p astral.tmp
execute store result score #p astral.tmp run data get storage astral:tmp eq.chest.components."minecraft:custom_data".astral.def
scoreboard players operation #d astral.tmp += #p astral.tmp
execute store result score #p astral.tmp run data get storage astral:tmp eq.legs.components."minecraft:custom_data".astral.def
scoreboard players operation #d astral.tmp += #p astral.tmp
execute store result score #p astral.tmp run data get storage astral:tmp eq.feet.components."minecraft:custom_data".astral.def
scoreboard players operation #d astral.tmp += #p astral.tmp
execute store result score #v astral.tmp run attribute @s minecraft:armor get 5
scoreboard players operation @s astraldef = #d astral.tmp
scoreboard players operation @s astraldef += #v astral.tmp
execute if score @s astral.defp = #d astral.tmp run return 0
scoreboard players operation @s astral.defp = #d astral.tmp
tag @s remove astral.db0
tag @s remove astral.db1
tag @s remove astral.db2
tag @s remove astral.db3
tag @s remove astral.db4
tag @s remove astral.db5
tag @s remove astral.db6
tag @s remove astral.db7
tag @s remove astral.db8
tag @s remove astral.db9
tag @s remove astral.db10
tag @s remove astral.db11
execute if score #d astral.tmp matches 2048.. run tag @s add astral.db11
execute if score #d astral.tmp matches 2048.. run scoreboard players remove #d astral.tmp 2048
execute if score #d astral.tmp matches 1024.. run tag @s add astral.db10
execute if score #d astral.tmp matches 1024.. run scoreboard players remove #d astral.tmp 1024
execute if score #d astral.tmp matches 512.. run tag @s add astral.db9
execute if score #d astral.tmp matches 512.. run scoreboard players remove #d astral.tmp 512
execute if score #d astral.tmp matches 256.. run tag @s add astral.db8
execute if score #d astral.tmp matches 256.. run scoreboard players remove #d astral.tmp 256
execute if score #d astral.tmp matches 128.. run tag @s add astral.db7
execute if score #d astral.tmp matches 128.. run scoreboard players remove #d astral.tmp 128
execute if score #d astral.tmp matches 64.. run tag @s add astral.db6
execute if score #d astral.tmp matches 64.. run scoreboard players remove #d astral.tmp 64
execute if score #d astral.tmp matches 32.. run tag @s add astral.db5
execute if score #d astral.tmp matches 32.. run scoreboard players remove #d astral.tmp 32
execute if score #d astral.tmp matches 16.. run tag @s add astral.db4
execute if score #d astral.tmp matches 16.. run scoreboard players remove #d astral.tmp 16
execute if score #d astral.tmp matches 8.. run tag @s add astral.db3
execute if score #d astral.tmp matches 8.. run scoreboard players remove #d astral.tmp 8
execute if score #d astral.tmp matches 4.. run tag @s add astral.db2
execute if score #d astral.tmp matches 4.. run scoreboard players remove #d astral.tmp 4
execute if score #d astral.tmp matches 2.. run tag @s add astral.db1
execute if score #d astral.tmp matches 2.. run scoreboard players remove #d astral.tmp 2
execute if score #d astral.tmp matches 1.. run tag @s add astral.db0
execute if score #d astral.tmp matches 1.. run scoreboard players remove #d astral.tmp 1
