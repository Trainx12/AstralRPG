execute store result score #c astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"berserker_5_chestplate"}},!minecraft:custom_data~{astral:{v:2}}]
execute if score #c astral.tmp matches ..0 run return 0
execute store result storage astral:tmp up.n int 1 run scoreboard players get #c astral.tmp
function astral:upgrade/g/berserker_5_chestplate with storage astral:tmp up
