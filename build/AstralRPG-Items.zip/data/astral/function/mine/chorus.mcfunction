scoreboard players reset @s astral.m_ch
execute if dimension minecraft:the_end if predicate astral:chance/80 run function astral:drop/give {id:"madera_estelar",name:"Madera Estelar"}
