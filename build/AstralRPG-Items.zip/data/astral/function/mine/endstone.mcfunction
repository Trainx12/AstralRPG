scoreboard players reset @s astral.m_es
execute if dimension minecraft:the_end if entity @s[y=-64,dy=114] if predicate astral:chance/40 run function astral:drop/give {id:"fragmento_cristal",name:"Fragmento de Cristal Arcano"}
