scoreboard players reset @s astral.use
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{type:"staff"}}] run return run function astral:spell/cast
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{type:"hook"}}] run return run function astral:grapple/use
