$damage @s $(dmg) minecraft:magic by @a[tag=astral.caster,limit=1]
particle minecraft:dragon_breath ~ ~1 ~ 0.3 0.4 0.3 0.02 25
playsound minecraft:entity.illusioner.cast_spell player @a[distance=..16] ~ ~ ~ 0.7 1.8
return 1
