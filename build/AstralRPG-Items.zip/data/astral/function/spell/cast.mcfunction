execute if score @s astral.cd matches 1.. run return run title @s actionbar {"text": "El hechizo se esta recargando...", "color": "gray", "italic": false}
scoreboard players set #base astral.tmp 0
scoreboard players set #pct astral.tmp 10000
scoreboard players set #cd astral.tmp 20
scoreboard players set #cdr astral.tmp 0
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"baston_1"}}] run scoreboard players set #base astral.tmp 500
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"baston_1"}}] run scoreboard players add #pct astral.tmp 500
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"baston_1"}}] run scoreboard players set #cd astral.tmp 25
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"baston_2"}}] run scoreboard players set #base astral.tmp 600
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"baston_2"}}] run scoreboard players add #pct astral.tmp 1000
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"baston_2"}}] run scoreboard players set #cd astral.tmp 24
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"baston_3"}}] run scoreboard players set #base astral.tmp 700
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"baston_3"}}] run scoreboard players add #pct astral.tmp 1800
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"baston_3"}}] run scoreboard players set #cd astral.tmp 22
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"baston_4"}}] run scoreboard players set #base astral.tmp 850
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"baston_4"}}] run scoreboard players add #pct astral.tmp 2500
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"baston_4"}}] run scoreboard players set #cd astral.tmp 21
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"baston_4"}}] run scoreboard players add #cdr astral.tmp 10
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"baston_5"}}] run scoreboard players set #base astral.tmp 1000
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"baston_5"}}] run scoreboard players add #pct astral.tmp 4000
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"baston_5"}}] run scoreboard players set #cd astral.tmp 20
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"baston_5"}}] run scoreboard players add #pct astral.tmp 2000
execute if items entity @s armor.head *[minecraft:custom_data~{astral:{id:"mago_1_helmet"}}] run scoreboard players add #pct astral.tmp 125
execute if items entity @s armor.chest *[minecraft:custom_data~{astral:{id:"mago_1_chestplate"}}] run scoreboard players add #pct astral.tmp 125
execute if items entity @s armor.legs *[minecraft:custom_data~{astral:{id:"mago_1_leggings"}}] run scoreboard players add #pct astral.tmp 125
execute if items entity @s armor.feet *[minecraft:custom_data~{astral:{id:"mago_1_boots"}}] run scoreboard players add #pct astral.tmp 125
execute if items entity @s armor.head *[minecraft:custom_data~{astral:{id:"mago_2_helmet"}}] run scoreboard players add #pct astral.tmp 250
execute if items entity @s armor.chest *[minecraft:custom_data~{astral:{id:"mago_2_chestplate"}}] run scoreboard players add #pct astral.tmp 250
execute if items entity @s armor.legs *[minecraft:custom_data~{astral:{id:"mago_2_leggings"}}] run scoreboard players add #pct astral.tmp 250
execute if items entity @s armor.feet *[minecraft:custom_data~{astral:{id:"mago_2_boots"}}] run scoreboard players add #pct astral.tmp 250
execute if items entity @s armor.head *[minecraft:custom_data~{astral:{id:"mago_3_helmet"}}] run scoreboard players add #pct astral.tmp 450
execute if items entity @s armor.chest *[minecraft:custom_data~{astral:{id:"mago_3_chestplate"}}] run scoreboard players add #pct astral.tmp 450
execute if items entity @s armor.legs *[minecraft:custom_data~{astral:{id:"mago_3_leggings"}}] run scoreboard players add #pct astral.tmp 450
execute if items entity @s armor.feet *[minecraft:custom_data~{astral:{id:"mago_3_boots"}}] run scoreboard players add #pct astral.tmp 450
execute if items entity @s armor.head *[minecraft:custom_data~{astral:{id:"mago_4_helmet"}}] run scoreboard players add #pct astral.tmp 625
execute if items entity @s armor.head *[minecraft:custom_data~{astral:{id:"mago_4_helmet"}}] run scoreboard players add #cdr astral.tmp 2
execute if items entity @s armor.chest *[minecraft:custom_data~{astral:{id:"mago_4_chestplate"}}] run scoreboard players add #pct astral.tmp 625
execute if items entity @s armor.chest *[minecraft:custom_data~{astral:{id:"mago_4_chestplate"}}] run scoreboard players add #cdr astral.tmp 2
execute if items entity @s armor.legs *[minecraft:custom_data~{astral:{id:"mago_4_leggings"}}] run scoreboard players add #pct astral.tmp 625
execute if items entity @s armor.legs *[minecraft:custom_data~{astral:{id:"mago_4_leggings"}}] run scoreboard players add #cdr astral.tmp 2
execute if items entity @s armor.feet *[minecraft:custom_data~{astral:{id:"mago_4_boots"}}] run scoreboard players add #pct astral.tmp 625
execute if items entity @s armor.feet *[minecraft:custom_data~{astral:{id:"mago_4_boots"}}] run scoreboard players add #cdr astral.tmp 2
execute if items entity @s armor.head *[minecraft:custom_data~{astral:{id:"mago_5_helmet"}}] run scoreboard players add #pct astral.tmp 1000
execute if items entity @s armor.chest *[minecraft:custom_data~{astral:{id:"mago_5_chestplate"}}] run scoreboard players add #pct astral.tmp 1000
execute if items entity @s armor.legs *[minecraft:custom_data~{astral:{id:"mago_5_leggings"}}] run scoreboard players add #pct astral.tmp 1000
execute if items entity @s armor.feet *[minecraft:custom_data~{astral:{id:"mago_5_boots"}}] run scoreboard players add #pct astral.tmp 1000
execute if score #base astral.tmp matches ..0 run return 0
scoreboard players operation #base astral.tmp *= #pct astral.tmp
scoreboard players operation #base astral.tmp /= #10000 astral.const
execute store result storage astral:tmp spell.dmg float 0.01 run scoreboard players get #base astral.tmp
scoreboard players operation #cdr astral.tmp *= #cd astral.tmp
scoreboard players operation #cdr astral.tmp /= #100 astral.const
scoreboard players operation #cd astral.tmp -= #cdr astral.tmp
scoreboard players operation @s astral.cd = #cd astral.tmp
tag @s add astral.caster
scoreboard players set #steps astral.tmp 0
playsound minecraft:entity.evoker.cast_spell player @a[distance=..16] ~ ~ ~ 0.8 1.6
execute anchored eyes positioned ^ ^ ^0.8 run function astral:spell/ray
tag @s remove astral.caster
