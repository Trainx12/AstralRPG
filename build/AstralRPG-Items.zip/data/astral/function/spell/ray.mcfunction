particle minecraft:witch ~ ~ ~ 0.05 0.05 0.05 0 2 force
particle minecraft:end_rod ~ ~ ~ 0 0 0 0 1 force
execute as @e[type=!minecraft:player,type=!#astral:ignore,distance=..1.1,tag=!astral.caster,limit=1,sort=nearest] run return run function astral:spell/hit with storage astral:tmp spell
execute unless block ~ ~ ~ #astral:passable run return run particle minecraft:large_smoke ~ ~ ~ 0.1 0.1 0.1 0.01 6
scoreboard players add #steps astral.tmp 1
execute if score #steps astral.tmp matches 50.. run return 0
execute positioned ^ ^ ^0.5 run function astral:spell/ray
