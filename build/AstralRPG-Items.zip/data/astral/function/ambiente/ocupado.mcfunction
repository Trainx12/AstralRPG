tellraw @s {"text":"No hay espacio libre: hace falta una zona de 7 de ancho, 5 de fondo y 6 de alto. El frente mira al norte.","color":"yellow"}
return 0
