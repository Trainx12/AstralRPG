execute align xyz run function astral:ambiente/herrero/build
