execute align xyz run function astral:ambiente/bazar/build
