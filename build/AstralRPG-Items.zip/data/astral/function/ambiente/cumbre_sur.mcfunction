execute align xyz run function astral:ambiente/cumbre_sur/build
