execute align xyz run function astral:ambiente/santuario/build
