execute align xyz run function astral:ambiente/tumba/build
