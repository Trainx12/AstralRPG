execute in minecraft:forja run fill 48 52 -90 116 55 -22 minecraft:air
execute in minecraft:forja run fill 48 56 -90 116 59 -22 minecraft:air
execute in minecraft:forja run fill 48 60 -90 116 63 -22 minecraft:air
execute in minecraft:forja run fill 48 64 -90 116 65 -22 minecraft:air
execute in minecraft:forja run fill 48 50 -90 116 51 -22 minecraft:polished_blackstone_bricks
execute in minecraft:forja run fill 48 52 -90 116 52 -90 minecraft:stone_brick_wall
execute in minecraft:forja run fill 48 52 -22 116 52 -22 minecraft:stone_brick_wall
execute in minecraft:forja run fill 48 52 -90 48 52 -22 minecraft:stone_brick_wall
execute in minecraft:forja run fill 116 52 -90 116 52 -22 minecraft:stone_brick_wall
execute in minecraft:forja run setblock 49 52 -89 minecraft:lantern
execute in minecraft:forja run setblock 49 52 -23 minecraft:lantern
execute in minecraft:forja run setblock 115 52 -89 minecraft:lantern
execute in minecraft:forja run setblock 115 52 -23 minecraft:lantern
