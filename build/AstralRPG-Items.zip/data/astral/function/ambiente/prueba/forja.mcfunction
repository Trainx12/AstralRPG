execute in minecraft:forja run fill 1514 224 1878 1558 227 1922 minecraft:air
execute in minecraft:forja run fill 1514 228 1878 1558 231 1922 minecraft:air
execute in minecraft:forja run fill 1514 232 1878 1558 235 1922 minecraft:air
execute in minecraft:forja run fill 1514 236 1878 1558 237 1922 minecraft:air
execute in minecraft:forja run fill 1514 222 1878 1558 223 1922 minecraft:polished_blackstone_bricks
execute in minecraft:forja run fill 1514 224 1878 1558 224 1878 minecraft:stone_brick_wall
execute in minecraft:forja run fill 1514 224 1922 1558 224 1922 minecraft:stone_brick_wall
execute in minecraft:forja run fill 1514 224 1878 1514 224 1922 minecraft:stone_brick_wall
execute in minecraft:forja run fill 1558 224 1878 1558 224 1922 minecraft:stone_brick_wall
execute in minecraft:forja run setblock 1515 224 1879 minecraft:lantern
execute in minecraft:forja run setblock 1515 224 1921 minecraft:lantern
execute in minecraft:forja run setblock 1557 224 1879 minecraft:lantern
execute in minecraft:forja run setblock 1557 224 1921 minecraft:lantern
execute in minecraft:forja run fill 1434 210 2010 1478 213 2054 minecraft:air
execute in minecraft:forja run fill 1434 214 2010 1478 217 2054 minecraft:air
execute in minecraft:forja run fill 1434 218 2010 1478 221 2054 minecraft:air
execute in minecraft:forja run fill 1434 222 2010 1478 223 2054 minecraft:air
execute in minecraft:forja run fill 1434 208 2010 1478 209 2054 minecraft:polished_blackstone_bricks
execute in minecraft:forja run fill 1434 210 2010 1478 210 2010 minecraft:stone_brick_wall
execute in minecraft:forja run fill 1434 210 2054 1478 210 2054 minecraft:stone_brick_wall
execute in minecraft:forja run fill 1434 210 2010 1434 210 2054 minecraft:stone_brick_wall
execute in minecraft:forja run fill 1478 210 2010 1478 210 2054 minecraft:stone_brick_wall
execute in minecraft:forja run setblock 1435 210 2011 minecraft:lantern
execute in minecraft:forja run setblock 1435 210 2053 minecraft:lantern
execute in minecraft:forja run setblock 1477 210 2011 minecraft:lantern
execute in minecraft:forja run setblock 1477 210 2053 minecraft:lantern
execute in minecraft:forja run fill 1502 200 2270 1570 203 2338 minecraft:air
execute in minecraft:forja run fill 1502 204 2270 1570 207 2338 minecraft:air
execute in minecraft:forja run fill 1502 208 2270 1570 211 2338 minecraft:air
execute in minecraft:forja run fill 1502 212 2270 1570 213 2338 minecraft:air
execute in minecraft:forja run fill 1502 198 2270 1570 199 2338 minecraft:polished_blackstone_bricks
execute in minecraft:forja run fill 1502 200 2270 1570 200 2270 minecraft:stone_brick_wall
execute in minecraft:forja run fill 1502 200 2338 1570 200 2338 minecraft:stone_brick_wall
execute in minecraft:forja run fill 1502 200 2270 1502 200 2338 minecraft:stone_brick_wall
execute in minecraft:forja run fill 1570 200 2270 1570 200 2338 minecraft:stone_brick_wall
execute in minecraft:forja run setblock 1503 200 2271 minecraft:lantern
execute in minecraft:forja run setblock 1503 200 2337 minecraft:lantern
execute in minecraft:forja run setblock 1569 200 2271 minecraft:lantern
execute in minecraft:forja run setblock 1569 200 2337 minecraft:lantern
