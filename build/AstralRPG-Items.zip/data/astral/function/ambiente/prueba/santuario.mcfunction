execute in minecraft:santuario run fill 222 64 222 290 67 290 minecraft:air
execute in minecraft:santuario run fill 222 68 222 290 71 290 minecraft:air
execute in minecraft:santuario run fill 222 72 222 290 75 290 minecraft:air
execute in minecraft:santuario run fill 222 76 222 290 77 290 minecraft:air
execute in minecraft:santuario run fill 222 62 222 290 63 290 minecraft:smooth_quartz
execute in minecraft:santuario run fill 222 64 222 290 64 222 minecraft:stone_brick_wall
execute in minecraft:santuario run fill 222 64 290 290 64 290 minecraft:stone_brick_wall
execute in minecraft:santuario run fill 222 64 222 222 64 290 minecraft:stone_brick_wall
execute in minecraft:santuario run fill 290 64 222 290 64 290 minecraft:stone_brick_wall
execute in minecraft:santuario run setblock 223 64 223 minecraft:lantern
execute in minecraft:santuario run setblock 223 64 289 minecraft:lantern
execute in minecraft:santuario run setblock 289 64 223 minecraft:lantern
execute in minecraft:santuario run setblock 289 64 289 minecraft:lantern
