execute in minecraft:santuario run fill 12 180 14 80 183 82 minecraft:air
execute in minecraft:santuario run fill 12 184 14 80 187 82 minecraft:air
execute in minecraft:santuario run fill 12 188 14 80 191 82 minecraft:air
execute in minecraft:santuario run fill 12 192 14 80 193 82 minecraft:air
execute in minecraft:santuario run fill 12 178 14 80 179 82 minecraft:smooth_quartz
execute in minecraft:santuario run fill 12 180 14 80 180 14 minecraft:stone_brick_wall
execute in minecraft:santuario run fill 12 180 82 80 180 82 minecraft:stone_brick_wall
execute in minecraft:santuario run fill 12 180 14 12 180 82 minecraft:stone_brick_wall
execute in minecraft:santuario run fill 80 180 14 80 180 82 minecraft:stone_brick_wall
execute in minecraft:santuario run setblock 13 180 15 minecraft:lantern
execute in minecraft:santuario run setblock 13 180 81 minecraft:lantern
execute in minecraft:santuario run setblock 79 180 15 minecraft:lantern
execute in minecraft:santuario run setblock 79 180 81 minecraft:lantern
