execute in minecraft:santuario run fill -364 51 31 -296 54 99 minecraft:air
execute in minecraft:santuario run fill -364 55 31 -296 58 99 minecraft:air
execute in minecraft:santuario run fill -364 59 31 -296 62 99 minecraft:air
execute in minecraft:santuario run fill -364 63 31 -296 64 99 minecraft:air
execute in minecraft:santuario run fill -364 49 31 -296 50 99 minecraft:smooth_quartz
execute in minecraft:santuario run fill -364 51 31 -296 51 31 minecraft:stone_brick_wall
execute in minecraft:santuario run fill -364 51 99 -296 51 99 minecraft:stone_brick_wall
execute in minecraft:santuario run fill -364 51 31 -364 51 99 minecraft:stone_brick_wall
execute in minecraft:santuario run fill -296 51 31 -296 51 99 minecraft:stone_brick_wall
execute in minecraft:santuario run setblock -363 51 32 minecraft:lantern
execute in minecraft:santuario run setblock -363 51 98 minecraft:lantern
execute in minecraft:santuario run setblock -297 51 32 minecraft:lantern
execute in minecraft:santuario run setblock -297 51 98 minecraft:lantern
