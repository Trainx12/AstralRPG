execute in minecraft:santuario run fill 213 57 -15 281 60 53 minecraft:air
execute in minecraft:santuario run fill 213 61 -15 281 64 53 minecraft:air
execute in minecraft:santuario run fill 213 65 -15 281 68 53 minecraft:air
execute in minecraft:santuario run fill 213 69 -15 281 70 53 minecraft:air
execute in minecraft:santuario run fill 213 55 -15 281 56 53 minecraft:smooth_quartz
execute in minecraft:santuario run fill 213 57 -15 281 57 -15 minecraft:stone_brick_wall
execute in minecraft:santuario run fill 213 57 53 281 57 53 minecraft:stone_brick_wall
execute in minecraft:santuario run fill 213 57 -15 213 57 53 minecraft:stone_brick_wall
execute in minecraft:santuario run fill 281 57 -15 281 57 53 minecraft:stone_brick_wall
execute in minecraft:santuario run setblock 214 57 -14 minecraft:lantern
execute in minecraft:santuario run setblock 214 57 52 minecraft:lantern
execute in minecraft:santuario run setblock 280 57 -14 minecraft:lantern
execute in minecraft:santuario run setblock 280 57 52 minecraft:lantern
