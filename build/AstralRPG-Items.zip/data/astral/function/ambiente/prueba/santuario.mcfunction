execute in minecraft:santuario run fill 222 180 220 290 183 288 minecraft:air
execute in minecraft:santuario run fill 222 184 220 290 187 288 minecraft:air
execute in minecraft:santuario run fill 222 188 220 290 191 288 minecraft:air
execute in minecraft:santuario run fill 222 192 220 290 193 288 minecraft:air
execute in minecraft:santuario run fill 222 178 220 290 179 288 minecraft:smooth_quartz
execute in minecraft:santuario run fill 222 180 220 290 180 220 minecraft:stone_brick_wall
execute in minecraft:santuario run fill 222 180 288 290 180 288 minecraft:stone_brick_wall
execute in minecraft:santuario run fill 222 180 220 222 180 288 minecraft:stone_brick_wall
execute in minecraft:santuario run fill 290 180 220 290 180 288 minecraft:stone_brick_wall
execute in minecraft:santuario run setblock 223 180 221 minecraft:lantern
execute in minecraft:santuario run setblock 223 180 287 minecraft:lantern
execute in minecraft:santuario run setblock 289 180 221 minecraft:lantern
execute in minecraft:santuario run setblock 289 180 287 minecraft:lantern
