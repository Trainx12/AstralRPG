execute in minecraft:cumbre run fill -151 79 -22 -107 82 22 minecraft:air
execute in minecraft:cumbre run fill -151 83 -22 -107 86 22 minecraft:air
execute in minecraft:cumbre run fill -151 87 -22 -107 90 22 minecraft:air
execute in minecraft:cumbre run fill -151 91 -22 -107 92 22 minecraft:air
execute in minecraft:cumbre run fill -151 77 -22 -107 78 22 minecraft:packed_ice
execute in minecraft:cumbre run fill -151 79 -22 -107 79 -22 minecraft:stone_brick_wall
execute in minecraft:cumbre run fill -151 79 22 -107 79 22 minecraft:stone_brick_wall
execute in minecraft:cumbre run fill -151 79 -22 -151 79 22 minecraft:stone_brick_wall
execute in minecraft:cumbre run fill -107 79 -22 -107 79 22 minecraft:stone_brick_wall
execute in minecraft:cumbre run setblock -150 79 -21 minecraft:lantern
execute in minecraft:cumbre run setblock -150 79 21 minecraft:lantern
execute in minecraft:cumbre run setblock -108 79 -21 minecraft:lantern
execute in minecraft:cumbre run setblock -108 79 21 minecraft:lantern
execute in minecraft:cumbre run fill -22 115 -22 22 118 22 minecraft:air
execute in minecraft:cumbre run fill -22 119 -22 22 122 22 minecraft:air
execute in minecraft:cumbre run fill -22 123 -22 22 126 22 minecraft:air
execute in minecraft:cumbre run fill -22 127 -22 22 128 22 minecraft:air
execute in minecraft:cumbre run fill -22 113 -22 22 114 22 minecraft:packed_ice
execute in minecraft:cumbre run fill -22 115 -22 22 115 -22 minecraft:stone_brick_wall
execute in minecraft:cumbre run fill -22 115 22 22 115 22 minecraft:stone_brick_wall
execute in minecraft:cumbre run fill -22 115 -22 -22 115 22 minecraft:stone_brick_wall
execute in minecraft:cumbre run fill 22 115 -22 22 115 22 minecraft:stone_brick_wall
execute in minecraft:cumbre run setblock -21 115 -21 minecraft:lantern
execute in minecraft:cumbre run setblock -21 115 21 minecraft:lantern
execute in minecraft:cumbre run setblock 21 115 -21 minecraft:lantern
execute in minecraft:cumbre run setblock 21 115 21 minecraft:lantern
execute in minecraft:cumbre run fill 62 97 -34 130 100 34 minecraft:air
execute in minecraft:cumbre run fill 62 101 -34 130 104 34 minecraft:air
execute in minecraft:cumbre run fill 62 105 -34 130 108 34 minecraft:air
execute in minecraft:cumbre run fill 62 109 -34 130 110 34 minecraft:air
execute in minecraft:cumbre run fill 62 95 -34 130 96 34 minecraft:packed_ice
execute in minecraft:cumbre run fill 62 97 -34 130 97 -34 minecraft:stone_brick_wall
execute in minecraft:cumbre run fill 62 97 34 130 97 34 minecraft:stone_brick_wall
execute in minecraft:cumbre run fill 62 97 -34 62 97 34 minecraft:stone_brick_wall
execute in minecraft:cumbre run fill 130 97 -34 130 97 34 minecraft:stone_brick_wall
execute in minecraft:cumbre run setblock 63 97 -33 minecraft:lantern
execute in minecraft:cumbre run setblock 63 97 33 minecraft:lantern
execute in minecraft:cumbre run setblock 129 97 -33 minecraft:lantern
execute in minecraft:cumbre run setblock 129 97 33 minecraft:lantern
