execute in minecraft:cumbre run fill -48 33 -46 -4 36 -2 minecraft:air
execute in minecraft:cumbre run fill -48 37 -46 -4 40 -2 minecraft:air
execute in minecraft:cumbre run fill -48 41 -46 -4 44 -2 minecraft:air
execute in minecraft:cumbre run fill -48 45 -46 -4 46 -2 minecraft:air
execute in minecraft:cumbre run fill -48 31 -46 -4 32 -2 minecraft:packed_ice
execute in minecraft:cumbre run fill -48 33 -46 -4 33 -46 minecraft:stone_brick_wall
execute in minecraft:cumbre run fill -48 33 -2 -4 33 -2 minecraft:stone_brick_wall
execute in minecraft:cumbre run fill -48 33 -46 -48 33 -2 minecraft:stone_brick_wall
execute in minecraft:cumbre run fill -4 33 -46 -4 33 -2 minecraft:stone_brick_wall
execute in minecraft:cumbre run setblock -47 33 -45 minecraft:lantern
execute in minecraft:cumbre run setblock -47 33 -3 minecraft:lantern
execute in minecraft:cumbre run setblock -5 33 -45 minecraft:lantern
execute in minecraft:cumbre run setblock -5 33 -3 minecraft:lantern
execute in minecraft:cumbre run fill -136 30 22 -68 33 90 minecraft:air
execute in minecraft:cumbre run fill -136 34 22 -68 37 90 minecraft:air
execute in minecraft:cumbre run fill -136 38 22 -68 41 90 minecraft:air
execute in minecraft:cumbre run fill -136 42 22 -68 43 90 minecraft:air
execute in minecraft:cumbre run fill -136 28 22 -68 29 90 minecraft:packed_ice
execute in minecraft:cumbre run fill -136 30 22 -68 30 22 minecraft:stone_brick_wall
execute in minecraft:cumbre run fill -136 30 90 -68 30 90 minecraft:stone_brick_wall
execute in minecraft:cumbre run fill -136 30 22 -136 30 90 minecraft:stone_brick_wall
execute in minecraft:cumbre run fill -68 30 22 -68 30 90 minecraft:stone_brick_wall
execute in minecraft:cumbre run setblock -135 30 23 minecraft:lantern
execute in minecraft:cumbre run setblock -135 30 89 minecraft:lantern
execute in minecraft:cumbre run setblock -69 30 23 minecraft:lantern
execute in minecraft:cumbre run setblock -69 30 89 minecraft:lantern
