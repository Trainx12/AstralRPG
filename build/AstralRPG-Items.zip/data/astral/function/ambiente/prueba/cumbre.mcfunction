execute in minecraft:cumbre run fill -6 64 -4 38 67 40 minecraft:air
execute in minecraft:cumbre run fill -6 68 -4 38 71 40 minecraft:air
execute in minecraft:cumbre run fill -6 72 -4 38 75 40 minecraft:air
execute in minecraft:cumbre run fill -6 76 -4 38 77 40 minecraft:air
execute in minecraft:cumbre run fill -6 62 -4 38 63 40 minecraft:packed_ice
execute in minecraft:cumbre run fill -6 64 -4 38 64 -4 minecraft:stone_brick_wall
execute in minecraft:cumbre run fill -6 64 40 38 64 40 minecraft:stone_brick_wall
execute in minecraft:cumbre run fill -6 64 -4 -6 64 40 minecraft:stone_brick_wall
execute in minecraft:cumbre run fill 38 64 -4 38 64 40 minecraft:stone_brick_wall
execute in minecraft:cumbre run setblock -5 64 -3 minecraft:lantern
execute in minecraft:cumbre run setblock -5 64 39 minecraft:lantern
execute in minecraft:cumbre run setblock 37 64 -3 minecraft:lantern
execute in minecraft:cumbre run setblock 37 64 39 minecraft:lantern
execute in minecraft:cumbre run fill 2 66 -24 46 69 20 minecraft:air
execute in minecraft:cumbre run fill 2 70 -24 46 73 20 minecraft:air
execute in minecraft:cumbre run fill 2 74 -24 46 77 20 minecraft:air
execute in minecraft:cumbre run fill 2 78 -24 46 79 20 minecraft:air
execute in minecraft:cumbre run fill 2 64 -24 46 65 20 minecraft:packed_ice
execute in minecraft:cumbre run fill 2 66 -24 46 66 -24 minecraft:stone_brick_wall
execute in minecraft:cumbre run fill 2 66 20 46 66 20 minecraft:stone_brick_wall
execute in minecraft:cumbre run fill 2 66 -24 2 66 20 minecraft:stone_brick_wall
execute in minecraft:cumbre run fill 46 66 -24 46 66 20 minecraft:stone_brick_wall
execute in minecraft:cumbre run setblock 3 66 -23 minecraft:lantern
execute in minecraft:cumbre run setblock 3 66 19 minecraft:lantern
execute in minecraft:cumbre run setblock 45 66 -23 minecraft:lantern
execute in minecraft:cumbre run setblock 45 66 19 minecraft:lantern
execute in minecraft:cumbre run fill -28 63 -2 40 66 66 minecraft:air
execute in minecraft:cumbre run fill -28 67 -2 40 70 66 minecraft:air
execute in minecraft:cumbre run fill -28 71 -2 40 74 66 minecraft:air
execute in minecraft:cumbre run fill -28 75 -2 40 76 66 minecraft:air
execute in minecraft:cumbre run fill -28 61 -2 40 62 66 minecraft:packed_ice
execute in minecraft:cumbre run fill -28 63 -2 40 63 -2 minecraft:stone_brick_wall
execute in minecraft:cumbre run fill -28 63 66 40 63 66 minecraft:stone_brick_wall
execute in minecraft:cumbre run fill -28 63 -2 -28 63 66 minecraft:stone_brick_wall
execute in minecraft:cumbre run fill 40 63 -2 40 63 66 minecraft:stone_brick_wall
execute in minecraft:cumbre run setblock -27 63 -1 minecraft:lantern
execute in minecraft:cumbre run setblock -27 63 65 minecraft:lantern
execute in minecraft:cumbre run setblock 39 63 -1 minecraft:lantern
execute in minecraft:cumbre run setblock 39 63 65 minecraft:lantern
