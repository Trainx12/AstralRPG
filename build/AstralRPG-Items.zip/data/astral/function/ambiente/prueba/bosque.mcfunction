execute in minecraft:bosque run fill 1418 104 1546 1462 107 1590 minecraft:air
execute in minecraft:bosque run fill 1418 108 1546 1462 111 1590 minecraft:air
execute in minecraft:bosque run fill 1418 112 1546 1462 115 1590 minecraft:air
execute in minecraft:bosque run fill 1418 116 1546 1462 117 1590 minecraft:air
execute in minecraft:bosque run fill 1418 102 1546 1462 103 1590 minecraft:mossy_stone_bricks
execute in minecraft:bosque run fill 1418 104 1546 1462 104 1546 minecraft:stone_brick_wall
execute in minecraft:bosque run fill 1418 104 1590 1462 104 1590 minecraft:stone_brick_wall
execute in minecraft:bosque run fill 1418 104 1546 1418 104 1590 minecraft:stone_brick_wall
execute in minecraft:bosque run fill 1462 104 1546 1462 104 1590 minecraft:stone_brick_wall
execute in minecraft:bosque run setblock 1419 104 1547 minecraft:lantern
execute in minecraft:bosque run setblock 1419 104 1589 minecraft:lantern
execute in minecraft:bosque run setblock 1461 104 1547 minecraft:lantern
execute in minecraft:bosque run setblock 1461 104 1589 minecraft:lantern
execute in minecraft:bosque run fill 1482 107 1482 1526 110 1526 minecraft:air
execute in minecraft:bosque run fill 1482 111 1482 1526 114 1526 minecraft:air
execute in minecraft:bosque run fill 1482 115 1482 1526 118 1526 minecraft:air
execute in minecraft:bosque run fill 1482 119 1482 1526 120 1526 minecraft:air
execute in minecraft:bosque run fill 1482 105 1482 1526 106 1526 minecraft:mossy_stone_bricks
execute in minecraft:bosque run fill 1482 107 1482 1526 107 1482 minecraft:stone_brick_wall
execute in minecraft:bosque run fill 1482 107 1526 1526 107 1526 minecraft:stone_brick_wall
execute in minecraft:bosque run fill 1482 107 1482 1482 107 1526 minecraft:stone_brick_wall
execute in minecraft:bosque run fill 1526 107 1482 1526 107 1526 minecraft:stone_brick_wall
execute in minecraft:bosque run setblock 1483 107 1483 minecraft:lantern
execute in minecraft:bosque run setblock 1483 107 1525 minecraft:lantern
execute in minecraft:bosque run setblock 1525 107 1483 minecraft:lantern
execute in minecraft:bosque run setblock 1525 107 1525 minecraft:lantern
execute in minecraft:bosque run fill 1566 97 1406 1634 100 1474 minecraft:air
execute in minecraft:bosque run fill 1566 101 1406 1634 104 1474 minecraft:air
execute in minecraft:bosque run fill 1566 105 1406 1634 108 1474 minecraft:air
execute in minecraft:bosque run fill 1566 109 1406 1634 110 1474 minecraft:air
execute in minecraft:bosque run fill 1566 95 1406 1634 96 1474 minecraft:mossy_stone_bricks
execute in minecraft:bosque run fill 1566 97 1406 1634 97 1406 minecraft:stone_brick_wall
execute in minecraft:bosque run fill 1566 97 1474 1634 97 1474 minecraft:stone_brick_wall
execute in minecraft:bosque run fill 1566 97 1406 1566 97 1474 minecraft:stone_brick_wall
execute in minecraft:bosque run fill 1634 97 1406 1634 97 1474 minecraft:stone_brick_wall
execute in minecraft:bosque run setblock 1567 97 1407 minecraft:lantern
execute in minecraft:bosque run setblock 1567 97 1473 minecraft:lantern
execute in minecraft:bosque run setblock 1633 97 1407 minecraft:lantern
execute in minecraft:bosque run setblock 1633 97 1473 minecraft:lantern
