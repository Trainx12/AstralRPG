execute in minecraft:tumba run fill -215 83 106 -171 86 150 minecraft:air
execute in minecraft:tumba run fill -215 87 106 -171 90 150 minecraft:air
execute in minecraft:tumba run fill -215 91 106 -171 94 150 minecraft:air
execute in minecraft:tumba run fill -215 95 106 -171 96 150 minecraft:air
execute in minecraft:tumba run fill -215 81 106 -171 82 150 minecraft:smooth_sandstone
execute in minecraft:tumba run fill -215 83 106 -171 83 106 minecraft:stone_brick_wall
execute in minecraft:tumba run fill -215 83 150 -171 83 150 minecraft:stone_brick_wall
execute in minecraft:tumba run fill -215 83 106 -215 83 150 minecraft:stone_brick_wall
execute in minecraft:tumba run fill -171 83 106 -171 83 150 minecraft:stone_brick_wall
execute in minecraft:tumba run setblock -214 83 107 minecraft:lantern
execute in minecraft:tumba run setblock -214 83 149 minecraft:lantern
execute in minecraft:tumba run setblock -172 83 107 minecraft:lantern
execute in minecraft:tumba run setblock -172 83 149 minecraft:lantern
execute in minecraft:tumba run fill -151 72 -87 -107 75 -43 minecraft:air
execute in minecraft:tumba run fill -151 76 -87 -107 79 -43 minecraft:air
execute in minecraft:tumba run fill -151 80 -87 -107 83 -43 minecraft:air
execute in minecraft:tumba run fill -151 84 -87 -107 85 -43 minecraft:air
execute in minecraft:tumba run fill -151 70 -87 -107 71 -43 minecraft:smooth_sandstone
execute in minecraft:tumba run fill -151 72 -87 -107 72 -87 minecraft:stone_brick_wall
execute in minecraft:tumba run fill -151 72 -43 -107 72 -43 minecraft:stone_brick_wall
execute in minecraft:tumba run fill -151 72 -87 -151 72 -43 minecraft:stone_brick_wall
execute in minecraft:tumba run fill -107 72 -87 -107 72 -43 minecraft:stone_brick_wall
execute in minecraft:tumba run setblock -150 72 -86 minecraft:lantern
execute in minecraft:tumba run setblock -150 72 -44 minecraft:lantern
execute in minecraft:tumba run setblock -108 72 -86 minecraft:lantern
execute in minecraft:tumba run setblock -108 72 -44 minecraft:lantern
execute in minecraft:tumba run fill 62 73 -227 130 76 -159 minecraft:air
execute in minecraft:tumba run fill 62 77 -227 130 80 -159 minecraft:air
execute in minecraft:tumba run fill 62 81 -227 130 84 -159 minecraft:air
execute in minecraft:tumba run fill 62 85 -227 130 86 -159 minecraft:air
execute in minecraft:tumba run fill 62 71 -227 130 72 -159 minecraft:smooth_sandstone
execute in minecraft:tumba run fill 62 73 -227 130 73 -227 minecraft:stone_brick_wall
execute in minecraft:tumba run fill 62 73 -159 130 73 -159 minecraft:stone_brick_wall
execute in minecraft:tumba run fill 62 73 -227 62 73 -159 minecraft:stone_brick_wall
execute in minecraft:tumba run fill 130 73 -227 130 73 -159 minecraft:stone_brick_wall
execute in minecraft:tumba run setblock 63 73 -226 minecraft:lantern
execute in minecraft:tumba run setblock 63 73 -160 minecraft:lantern
execute in minecraft:tumba run setblock 129 73 -226 minecraft:lantern
execute in minecraft:tumba run setblock 129 73 -160 minecraft:lantern
