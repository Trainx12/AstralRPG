execute in minecraft:tumba run fill -171 60 -121 -127 63 -77 minecraft:air
execute in minecraft:tumba run fill -171 64 -121 -127 67 -77 minecraft:air
execute in minecraft:tumba run fill -171 68 -121 -127 71 -77 minecraft:air
execute in minecraft:tumba run fill -171 72 -121 -127 73 -77 minecraft:air
execute in minecraft:tumba run fill -171 58 -121 -127 59 -77 minecraft:smooth_sandstone
execute in minecraft:tumba run fill -171 60 -121 -127 60 -121 minecraft:stone_brick_wall
execute in minecraft:tumba run fill -171 60 -77 -127 60 -77 minecraft:stone_brick_wall
execute in minecraft:tumba run fill -171 60 -121 -171 60 -77 minecraft:stone_brick_wall
execute in minecraft:tumba run fill -127 60 -121 -127 60 -77 minecraft:stone_brick_wall
execute in minecraft:tumba run setblock -170 60 -120 minecraft:lantern
execute in minecraft:tumba run setblock -170 60 -78 minecraft:lantern
execute in minecraft:tumba run setblock -128 60 -120 minecraft:lantern
execute in minecraft:tumba run setblock -128 60 -78 minecraft:lantern
execute in minecraft:tumba run fill -198 88 181 -154 91 225 minecraft:air
execute in minecraft:tumba run fill -198 92 181 -154 95 225 minecraft:air
execute in minecraft:tumba run fill -198 96 181 -154 99 225 minecraft:air
execute in minecraft:tumba run fill -198 100 181 -154 101 225 minecraft:air
execute in minecraft:tumba run fill -198 86 181 -154 87 225 minecraft:smooth_sandstone
execute in minecraft:tumba run fill -198 88 181 -154 88 181 minecraft:stone_brick_wall
execute in minecraft:tumba run fill -198 88 225 -154 88 225 minecraft:stone_brick_wall
execute in minecraft:tumba run fill -198 88 181 -198 88 225 minecraft:stone_brick_wall
execute in minecraft:tumba run fill -154 88 181 -154 88 225 minecraft:stone_brick_wall
execute in minecraft:tumba run setblock -197 88 182 minecraft:lantern
execute in minecraft:tumba run setblock -197 88 224 minecraft:lantern
execute in minecraft:tumba run setblock -155 88 182 minecraft:lantern
execute in minecraft:tumba run setblock -155 88 224 minecraft:lantern
execute in minecraft:tumba run fill -34 72 -34 34 75 34 minecraft:air
execute in minecraft:tumba run fill -34 76 -34 34 79 34 minecraft:air
execute in minecraft:tumba run fill -34 80 -34 34 83 34 minecraft:air
execute in minecraft:tumba run fill -34 84 -34 34 85 34 minecraft:air
execute in minecraft:tumba run fill -34 70 -34 34 71 34 minecraft:smooth_sandstone
execute in minecraft:tumba run fill -34 72 -34 34 72 -34 minecraft:stone_brick_wall
execute in minecraft:tumba run fill -34 72 34 34 72 34 minecraft:stone_brick_wall
execute in minecraft:tumba run fill -34 72 -34 -34 72 34 minecraft:stone_brick_wall
execute in minecraft:tumba run fill 34 72 -34 34 72 34 minecraft:stone_brick_wall
execute in minecraft:tumba run setblock -33 72 -33 minecraft:lantern
execute in minecraft:tumba run setblock -33 72 33 minecraft:lantern
execute in minecraft:tumba run setblock 33 72 -33 minecraft:lantern
execute in minecraft:tumba run setblock 33 72 33 minecraft:lantern
