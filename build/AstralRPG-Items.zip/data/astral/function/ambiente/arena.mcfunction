execute align xyz run function astral:ambiente/arena/build
