execute align xyz run function astral:ambiente/mina/build
