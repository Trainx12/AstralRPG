execute align xyz run function astral:ambiente/bosque/build
