execute align xyz run function astral:ambiente/expediciones_sur/build
