execute align xyz run function astral:ambiente/subastas/build
