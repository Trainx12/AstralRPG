execute align xyz run function astral:ambiente/expediciones/build
