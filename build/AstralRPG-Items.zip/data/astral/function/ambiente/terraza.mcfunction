# Galeria retirada: no recrear construcciones ni rotulos.
return 0
