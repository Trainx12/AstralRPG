execute align xyz run function astral:ambiente/cumbre/build
