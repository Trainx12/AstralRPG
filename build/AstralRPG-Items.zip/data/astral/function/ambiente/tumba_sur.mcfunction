execute align xyz run function astral:ambiente/tumba_sur/build
