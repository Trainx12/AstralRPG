execute align xyz run function astral:ambiente/mina_sur/build
