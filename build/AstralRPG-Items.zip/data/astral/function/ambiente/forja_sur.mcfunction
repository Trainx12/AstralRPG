execute align xyz run function astral:ambiente/forja_sur/build
