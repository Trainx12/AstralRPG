execute align xyz run function astral:ambiente/arena_sur/build
