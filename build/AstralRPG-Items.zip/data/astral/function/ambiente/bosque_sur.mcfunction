execute align xyz run function astral:ambiente/bosque_sur/build
