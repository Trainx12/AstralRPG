execute align xyz run function astral:ambiente/santuario_sur/build
