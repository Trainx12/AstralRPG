execute align xyz run function astral:ambiente/forja/build
