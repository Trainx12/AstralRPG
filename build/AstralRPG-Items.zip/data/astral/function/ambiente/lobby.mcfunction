execute in minecraft:lobby positioned 172 100 214 run function astral:ambiente/expediciones
execute in minecraft:lobby positioned 166 100 187 run function astral:ambiente/bazar
execute in minecraft:lobby positioned 190 100 187 run function astral:ambiente/subastas
execute in minecraft:lobby positioned 180 100 202 run function astral:ambiente/herrero
