execute if entity @e[type=minecraft:marker,tag=astral.amb.forja,distance=..1] run return 0
execute unless block ~3 ~0 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~3 ~1 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~3 ~2 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~3 ~3 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~3 ~4 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~3 ~5 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~3 ~0 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~3 ~1 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~3 ~2 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~3 ~3 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~3 ~4 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~3 ~5 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~3 ~0 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~3 ~1 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~3 ~2 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~3 ~3 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~3 ~4 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~3 ~5 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~3 ~0 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~3 ~1 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~3 ~2 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~3 ~3 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~3 ~4 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~3 ~5 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~3 ~0 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~3 ~1 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~3 ~2 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~3 ~3 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~3 ~4 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~3 ~5 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~2 ~0 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~2 ~1 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~2 ~2 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~2 ~3 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~2 ~4 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~2 ~5 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~2 ~0 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~2 ~1 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~2 ~2 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~2 ~3 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~2 ~4 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~2 ~5 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~2 ~0 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~2 ~1 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~2 ~2 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~2 ~3 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~2 ~4 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~2 ~5 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~2 ~0 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~2 ~1 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~2 ~2 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~2 ~3 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~2 ~4 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~2 ~5 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~2 ~0 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~2 ~1 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~2 ~2 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~2 ~3 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~2 ~4 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~2 ~5 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~1 ~0 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~1 ~1 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~1 ~2 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~1 ~3 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~1 ~4 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~1 ~5 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~1 ~0 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~1 ~1 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~1 ~2 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~1 ~3 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~1 ~4 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~1 ~5 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~1 ~0 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~1 ~1 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~1 ~2 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~1 ~3 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~1 ~4 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~1 ~5 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~1 ~0 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~1 ~1 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~1 ~2 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~1 ~3 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~1 ~4 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~1 ~5 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~1 ~0 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~1 ~1 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~1 ~2 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~1 ~3 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~1 ~4 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~1 ~5 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~0 ~0 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~0 ~1 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~0 ~2 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~0 ~3 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~0 ~4 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~0 ~5 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~0 ~0 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~0 ~1 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~0 ~2 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~0 ~3 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~0 ~4 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~0 ~5 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~0 ~0 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~0 ~1 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~0 ~2 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~0 ~3 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~0 ~4 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~0 ~5 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~0 ~0 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~0 ~1 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~0 ~2 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~0 ~3 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~0 ~4 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~0 ~5 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~0 ~0 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~0 ~1 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~0 ~2 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~0 ~3 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~0 ~4 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~0 ~5 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-1 ~0 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-1 ~1 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-1 ~2 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-1 ~3 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-1 ~4 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-1 ~5 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-1 ~0 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-1 ~1 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-1 ~2 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-1 ~3 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-1 ~4 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-1 ~5 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-1 ~0 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-1 ~1 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-1 ~2 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-1 ~3 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-1 ~4 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-1 ~5 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-1 ~0 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-1 ~1 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-1 ~2 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-1 ~3 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-1 ~4 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-1 ~5 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-1 ~0 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-1 ~1 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-1 ~2 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-1 ~3 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-1 ~4 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-1 ~5 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-2 ~0 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-2 ~1 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-2 ~2 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-2 ~3 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-2 ~4 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-2 ~5 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-2 ~0 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-2 ~1 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-2 ~2 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-2 ~3 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-2 ~4 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-2 ~5 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-2 ~0 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-2 ~1 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-2 ~2 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-2 ~3 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-2 ~4 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-2 ~5 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-2 ~0 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-2 ~1 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-2 ~2 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-2 ~3 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-2 ~4 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-2 ~5 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-2 ~0 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-2 ~1 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-2 ~2 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-2 ~3 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-2 ~4 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-2 ~5 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-3 ~0 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-3 ~1 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-3 ~2 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-3 ~3 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-3 ~4 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-3 ~5 ~0 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-3 ~0 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-3 ~1 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-3 ~2 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-3 ~3 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-3 ~4 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-3 ~5 ~-1 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-3 ~0 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-3 ~1 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-3 ~2 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-3 ~3 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-3 ~4 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-3 ~5 ~-2 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-3 ~0 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-3 ~1 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-3 ~2 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-3 ~3 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-3 ~4 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-3 ~5 ~-3 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-3 ~0 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-3 ~1 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-3 ~2 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-3 ~3 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-3 ~4 ~-4 minecraft:air run return run function astral:ambiente/ocupado
execute unless block ~-3 ~5 ~-4 minecraft:air run return run function astral:ambiente/ocupado
fill ~-3 ~-1 ~-4 ~3 ~-1 ~0 minecraft:polished_basalt
summon minecraft:marker ~0.5 ~ ~0.5 {Tags:["astral.amb.forja","astral.amb.modulo"]}
setblock ~2 ~0 ~-3 minecraft:polished_blackstone_bricks keep
setblock ~2 ~1 ~-3 minecraft:polished_blackstone_bricks keep
setblock ~2 ~2 ~-3 minecraft:polished_blackstone_bricks keep
setblock ~2 ~3 ~-3 minecraft:polished_blackstone_bricks keep
setblock ~2 ~4 ~-3 minecraft:chiseled_polished_blackstone keep
setblock ~-2 ~0 ~-3 minecraft:polished_blackstone_bricks keep
setblock ~-2 ~1 ~-3 minecraft:polished_blackstone_bricks keep
setblock ~-2 ~2 ~-3 minecraft:polished_blackstone_bricks keep
setblock ~-2 ~3 ~-3 minecraft:polished_blackstone_bricks keep
setblock ~-2 ~4 ~-3 minecraft:chiseled_polished_blackstone keep
setblock ~1 ~4 ~-3 minecraft:chiseled_polished_blackstone keep
setblock ~1 ~1 ~-3 minecraft:red_stained_glass keep
setblock ~1 ~2 ~-3 minecraft:red_stained_glass keep
setblock ~1 ~3 ~-3 minecraft:red_stained_glass keep
setblock ~0 ~4 ~-3 minecraft:chiseled_polished_blackstone keep
setblock ~0 ~1 ~-3 minecraft:red_stained_glass keep
setblock ~0 ~2 ~-3 minecraft:red_stained_glass keep
setblock ~0 ~3 ~-3 minecraft:red_stained_glass keep
setblock ~-1 ~4 ~-3 minecraft:chiseled_polished_blackstone keep
setblock ~-1 ~1 ~-3 minecraft:red_stained_glass keep
setblock ~-1 ~2 ~-3 minecraft:red_stained_glass keep
setblock ~-1 ~3 ~-3 minecraft:red_stained_glass keep
setblock ~3 ~0 ~-3 minecraft:chiseled_polished_blackstone keep
setblock ~3 ~1 ~-3 minecraft:lantern keep
setblock ~-3 ~0 ~-3 minecraft:chiseled_polished_blackstone keep
setblock ~-3 ~1 ~-3 minecraft:lantern keep
setblock ~0 ~5 ~-3 minecraft:chiseled_polished_blackstone keep
setblock ~3 ~0 ~-1 minecraft:shroomlight keep
setblock ~-3 ~0 ~-1 minecraft:shroomlight keep
setblock ~-1 ~-2 ~2 minecraft:stone_brick_stairs[facing=north] keep
setblock ~-1 ~-1 ~1 minecraft:stone_brick_stairs[facing=north] keep
setblock ~0 ~-2 ~2 minecraft:stone_brick_stairs[facing=north] keep
setblock ~0 ~-1 ~1 minecraft:stone_brick_stairs[facing=north] keep
setblock ~1 ~-2 ~2 minecraft:stone_brick_stairs[facing=north] keep
setblock ~1 ~-1 ~1 minecraft:stone_brick_stairs[facing=north] keep
summon minecraft:text_display ~0.5 ~5.8 ~-2.5 {Tags:["astral.amb.rotulo","astral.amb.forja"],billboard:"center",background:1073741824,view_range:0.8f,line_width:240,text:[{"text": "Corazon de la Forja", "color": "red", "bold": true}, {"text": "\nHabla con el guardian", "color": "gray", "bold": false}]}
return 1
