attribute @s minecraft:max_health modifier add astral:tier 13124.0 add_multiplied_base
attribute @s minecraft:attack_damage modifier add astral:tier 6.59 add_multiplied_base
tag @s add astral.mt5
