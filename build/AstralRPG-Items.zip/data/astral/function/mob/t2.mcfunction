attribute @s minecraft:max_health modifier add astral:tier 119.0 add_multiplied_base
attribute @s minecraft:attack_damage modifier add astral:tier 1.25 add_multiplied_base
tag @s add astral.mt2
