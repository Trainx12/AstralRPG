attribute @s minecraft:max_health modifier add astral:tier 0.6992 add_multiplied_base
tag @s add astral.mt2
