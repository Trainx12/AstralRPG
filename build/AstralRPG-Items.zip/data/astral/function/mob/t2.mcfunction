attribute @s minecraft:max_health modifier add astral:tier 119.0 add_multiplied_base
attribute @s minecraft:attack_damage modifier add astral:tier 0.15 add_multiplied_base
