data modify storage astral:tmp mob.n set value []
execute if score #mt astral.tmp matches 1 run data modify storage astral:tmp mob.n append value {text:"[T1] ",color:"#9fe870"}
execute if score #mt astral.tmp matches 2 run data modify storage astral:tmp mob.n append value {text:"[T2] ",color:"#4fb0ff"}
execute if score #mt astral.tmp matches 3 run data modify storage astral:tmp mob.n append value {text:"[T3] ",color:"#c070ff"}
execute if score #mt astral.tmp matches 4 run data modify storage astral:tmp mob.n append value {text:"[T4] ",color:"#ff8a3d"}
execute if score #mt astral.tmp matches 5 run data modify storage astral:tmp mob.n append value {text:"[T5] ",color:"#ffd84d"}
execute if entity @s[tag=astral.elite1] run data modify storage astral:tmp mob.n append value {text:"Veterano ",color:"#9fe870",bold:false}
execute if entity @s[tag=astral.elite2] run data modify storage astral:tmp mob.n append value {text:"Elite ",color:"#4fb0ff",bold:false}
execute if entity @s[tag=astral.elite3] run data modify storage astral:tmp mob.n append value {text:"Campeon ",color:"#c070ff",bold:false}
execute if entity @s[tag=astral.elite4] run data modify storage astral:tmp mob.n append value {text:"Pesadilla ",color:"#ff4d4d",bold:true}
execute if entity @s[tag=astral.elite5] run data modify storage astral:tmp mob.n append value {text:"Astral ",color:"#ffd84d",bold:true}
execute if data entity @s CustomName run data modify storage astral:tmp mob.n append from entity @s CustomName
execute unless data entity @s CustomName run function astral:mob/nombre_vanilla
# un mob comun de tier 0 queda sin cartel
execute unless data storage astral:tmp mob.n[1] run return 0
data modify entity @s CustomName set from storage astral:tmp mob.n
