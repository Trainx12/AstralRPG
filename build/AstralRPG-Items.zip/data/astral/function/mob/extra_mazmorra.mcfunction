execute if dimension minecraft:santuario run attribute @s minecraft:max_health modifier add astral:mazmorra 0.5 add_multiplied_total
execute if dimension minecraft:santuario_interstellar run attribute @s minecraft:max_health modifier add astral:mazmorra 0.5 add_multiplied_total
execute if dimension minecraft:santuario_azeroth run attribute @s minecraft:max_health modifier add astral:mazmorra 0.5 add_multiplied_total
execute if dimension minecraft:santuario_azeroth_2 run attribute @s minecraft:max_health modifier add astral:mazmorra 0.5 add_multiplied_total
execute if dimension minecraft:santuario_azeroth_3 run attribute @s minecraft:max_health modifier add astral:mazmorra 0.5 add_multiplied_total
execute if dimension minecraft:santuario_azeroth_4 run attribute @s minecraft:max_health modifier add astral:mazmorra 0.5 add_multiplied_total
execute if dimension minecraft:santuario_azeroth_5 run attribute @s minecraft:max_health modifier add astral:mazmorra 0.5 add_multiplied_total
execute if dimension minecraft:santuario_azeroth_6 run attribute @s minecraft:max_health modifier add astral:mazmorra 0.5 add_multiplied_total
