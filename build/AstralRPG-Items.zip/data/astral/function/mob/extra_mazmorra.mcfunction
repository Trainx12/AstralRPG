execute if dimension minecraft:santuario run attribute @s minecraft:max_health modifier add astral:mazmorra 0.5 add_multiplied_total
