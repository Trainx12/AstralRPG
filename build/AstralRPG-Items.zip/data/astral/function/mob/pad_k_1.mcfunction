$data modify storage astral:tmp hp.ks set value "0$(k)"
