$data modify storage astral:tmp hp.us set value "00$(u)"
