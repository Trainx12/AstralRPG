scoreboard players operation #mt astral.tmp = @p[distance=..128,gamemode=!spectator] astral.wt
execute if score #mt astral.tmp matches 0 run return 0
execute store result score #r astral.tmp run random value 1..100
execute if score #r astral.tmp matches ..4 if score #mt astral.tmp matches ..4 run return run scoreboard players add #mt astral.tmp 1
execute if score #r astral.tmp matches ..14 run scoreboard players remove #mt astral.tmp 1
