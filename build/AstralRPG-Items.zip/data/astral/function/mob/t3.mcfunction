attribute @s minecraft:max_health modifier add astral:tier 1.0125 add_multiplied_base
tag @s add astral.mt3
