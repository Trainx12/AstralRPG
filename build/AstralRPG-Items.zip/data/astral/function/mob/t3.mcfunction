attribute @s minecraft:max_health modifier add astral:tier 574.0 add_multiplied_base
attribute @s minecraft:attack_damage modifier add astral:tier 2.38 add_multiplied_base
tag @s add astral.mt3
