attribute @s minecraft:max_health modifier add astral:tier 2749.0 add_multiplied_base
tag @s add astral.mt4
