attribute @s minecraft:max_health modifier add astral:tier 2749.0 add_multiplied_base
attribute @s minecraft:attack_damage modifier add astral:tier 0.45 add_multiplied_base
