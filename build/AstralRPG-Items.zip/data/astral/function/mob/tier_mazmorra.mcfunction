execute store result score #r astral.tmp run random value 1..100
execute if score #r astral.tmp matches ..3 if score #mt astral.tmp matches ..4 run return run scoreboard players add #mt astral.tmp 1
execute if score #r astral.tmp matches 4..13 if score #mt astral.tmp matches 2.. run scoreboard players remove #mt astral.tmp 1
