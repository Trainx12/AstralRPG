$data modify storage astral:tmp hp.us set value "$(u)"
