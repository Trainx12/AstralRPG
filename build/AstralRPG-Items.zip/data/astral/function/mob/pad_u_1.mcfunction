$data modify storage astral:tmp hp.us set value "0$(u)"
