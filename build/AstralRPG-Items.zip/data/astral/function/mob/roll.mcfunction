tag @s add astral.seen
# mini juegos: sus criaturas son del mapa (oleadas, niveles): sin tier ni elite
execute if dimension minecraft:parkour_spiral run return 0
execute if dimension minecraft:parkour_spiral2 run return 0
execute if dimension minecraft:parkour_paradise3 run return 0
execute if dimension minecraft:colorescape run return 0
execute if dimension minecraft:magmarun run return 0
execute if dimension minecraft:battleship run return 0
execute if dimension minecraft:dropper_facil run return 0
execute if dimension minecraft:dropper_h4rs run return 0
# mascotas, vendedores y cofres son invulnerables: no se tocan
execute if data entity @s {Invulnerable:1b} run return 0
# golems de aldea (sin nombre de MythicMobs): no se tocan
execute if entity @s[type=minecraft:iron_golem] unless data entity @s CustomName run return 0
scoreboard players set #mt astral.tmp 0
scoreboard players set #dg astral.tmp 0
execute if dimension minecraft:bosque run scoreboard players set #mt astral.tmp 1
execute if dimension minecraft:bosque run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:mina run scoreboard players set #mt astral.tmp 2
execute if dimension minecraft:mina run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:tumba run scoreboard players set #mt astral.tmp 3
execute if dimension minecraft:tumba run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:cumbre run scoreboard players set #mt astral.tmp 4
execute if dimension minecraft:cumbre run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:forja run scoreboard players set #mt astral.tmp 5
execute if dimension minecraft:forja run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:santuario run scoreboard players set #mt astral.tmp 5
execute if dimension minecraft:santuario run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:cumbre_hielo run scoreboard players set #mt astral.tmp 4
execute if dimension minecraft:cumbre_hielo run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:forja_volcano run scoreboard players set #mt astral.tmp 5
execute if dimension minecraft:forja_volcano run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:santuario_interstellar run scoreboard players set #mt astral.tmp 5
execute if dimension minecraft:santuario_interstellar run scoreboard players set #dg astral.tmp 1
execute if score #dg astral.tmp matches 0 if entity @a[distance=..128,gamemode=!spectator] run function astral:mob/tier_mundo
execute if score #mt astral.tmp matches 1 run function astral:mob/t1
execute if score #mt astral.tmp matches 2 run function astral:mob/t2
execute if score #mt astral.tmp matches 3 run function astral:mob/t3
execute if score #mt astral.tmp matches 4 run function astral:mob/t4
execute if score #mt astral.tmp matches 5 run function astral:mob/t5
execute if score #dg astral.tmp matches 1 run function astral:mob/extra_mazmorra
scoreboard players operation @s astral.mt = #mt astral.tmp
function astral:mob/elite_chance
data modify entity @s Health set value 1.0E9f
function astral:mob/nombre
