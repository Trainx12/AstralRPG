$data modify storage astral:tmp hp.ks set value "00$(k)"
