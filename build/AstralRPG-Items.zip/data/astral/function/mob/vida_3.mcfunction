$data modify entity @s CustomName[-1].text set value " ❤ $(m).$(ks).$(us)"
