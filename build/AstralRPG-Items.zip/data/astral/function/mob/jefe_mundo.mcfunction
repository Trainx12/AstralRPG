execute if entity @s[tag=ad.boss.scaled] run return 0
execute if dimension minecraft:santuario run return 0
execute if dimension minecraft:santuario_interstellar run return 0
execute if dimension minecraft:santuario_azeroth run return 0
execute if dimension minecraft:santuario_azeroth_2 run return 0
execute if dimension minecraft:santuario_azeroth_3 run return 0
execute if dimension minecraft:santuario_azeroth_4 run return 0
execute if dimension minecraft:santuario_azeroth_5 run return 0
execute if dimension minecraft:santuario_azeroth_6 run return 0
scoreboard players set #mt astral.tmp 1
execute if entity @a[distance=..128,gamemode=!spectator] run function astral:mob/tier_mundo
execute if score #mt astral.tmp matches ..0 run scoreboard players set #mt astral.tmp 1
execute if score #mt astral.tmp matches 1 run attribute @s minecraft:max_health base set 12500
execute if score #mt astral.tmp matches 2 run attribute @s minecraft:max_health base set 60000
execute if score #mt astral.tmp matches 3 run attribute @s minecraft:max_health base set 287500
execute if score #mt astral.tmp matches 4 run attribute @s minecraft:max_health base set 1375000
execute if score #mt astral.tmp matches 5 run attribute @s minecraft:max_health base set 6562500
data modify entity @s Health set value 1.0E9f
scoreboard players operation @s astral.mt = #mt astral.tmp
tag @s add ad.boss.scaled
