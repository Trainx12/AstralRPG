$data modify entity @s CustomName.extra[-1].text set value " ❤ $(u)"
