execute store result score #hp astral.tmp run data get entity @s Health 1
execute if score #hp astral.tmp matches ..0 run scoreboard players set #hp astral.tmp 1
scoreboard players operation #u astral.tmp = #hp astral.tmp
scoreboard players operation #u astral.tmp %= #1000 astral.const
scoreboard players operation #k astral.tmp = #hp astral.tmp
scoreboard players operation #k astral.tmp /= #1000 astral.const
scoreboard players operation #m astral.tmp = #k astral.tmp
scoreboard players operation #m astral.tmp /= #1000 astral.const
scoreboard players operation #k astral.tmp %= #1000 astral.const
execute store result storage astral:tmp hp.u int 1 run scoreboard players get #u astral.tmp
execute store result storage astral:tmp hp.k int 1 run scoreboard players get #k astral.tmp
execute store result storage astral:tmp hp.m int 1 run scoreboard players get #m astral.tmp
execute if score #u astral.tmp matches ..9 run function astral:mob/pad_u_2 with storage astral:tmp hp
execute if score #u astral.tmp matches 10..99 run function astral:mob/pad_u_1 with storage astral:tmp hp
execute if score #u astral.tmp matches 100.. run function astral:mob/pad_u_0 with storage astral:tmp hp
execute if score #k astral.tmp matches ..9 run function astral:mob/pad_k_2 with storage astral:tmp hp
execute if score #k astral.tmp matches 10..99 run function astral:mob/pad_k_1 with storage astral:tmp hp
execute if score #k astral.tmp matches 100.. run function astral:mob/pad_k_0 with storage astral:tmp hp
execute if score #hp astral.tmp matches ..999 run return run function astral:mob/vida_1 with storage astral:tmp hp
execute if score #hp astral.tmp matches ..999999 run return run function astral:mob/vida_2 with storage astral:tmp hp
function astral:mob/vida_3 with storage astral:tmp hp
