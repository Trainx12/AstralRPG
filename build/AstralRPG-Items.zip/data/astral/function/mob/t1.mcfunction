attribute @s minecraft:max_health modifier add astral:tier 0.65 add_multiplied_base
tag @s add astral.mt1
