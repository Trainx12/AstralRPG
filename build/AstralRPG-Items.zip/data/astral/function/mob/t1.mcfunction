attribute @s minecraft:max_health modifier add astral:tier 24.0 add_multiplied_base
attribute @s minecraft:attack_damage modifier add astral:tier 0.5 add_multiplied_base
tag @s add astral.mt1
