clear @s *[minecraft:custom_data~{astral:{id:"esencia_elite"}}] 5
function astral:quest/daily/claim/7
