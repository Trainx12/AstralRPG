clear @s #minecraft:logs[!minecraft:custom_data] 64
function astral:quest/daily/claim/3
