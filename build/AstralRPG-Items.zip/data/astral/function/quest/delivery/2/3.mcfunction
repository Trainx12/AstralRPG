clear @s minecraft:cooked_chicken[!minecraft:custom_data] 32
function astral:quest/daily/claim/2
