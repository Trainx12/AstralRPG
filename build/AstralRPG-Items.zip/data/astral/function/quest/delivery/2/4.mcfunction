clear @s minecraft:cooked_mutton[!minecraft:custom_data] 32
function astral:quest/daily/claim/2
