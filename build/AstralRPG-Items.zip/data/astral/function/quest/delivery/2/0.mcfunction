clear @s minecraft:bread[!minecraft:custom_data] 32
function astral:quest/daily/claim/2
