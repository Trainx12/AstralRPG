clear @s minecraft:stone[!minecraft:custom_data] 64
clear @s minecraft:iron_ingot[!minecraft:custom_data] 16
function astral:quest/daily/claim/4
