tag @s remove aq.choice
scoreboard players set @s aq.reward 0
loot give @s loot astral:item/arquero_1_helmet
