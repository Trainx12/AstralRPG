execute if biome ~ ~ ~ #astral:quest/desert run function astral:quest/zone/0
execute if biome ~ ~ ~ #astral:quest/snow run function astral:quest/zone/1
execute if biome ~ ~ ~ #astral:quest/swamp run function astral:quest/zone/2
execute if biome ~ ~ ~ #astral:quest/forest run function astral:quest/zone/3
execute if biome ~ ~ ~ #astral:quest/plains run function astral:quest/zone/4
execute if dimension minecraft:the_nether run function astral:quest/zone/5
