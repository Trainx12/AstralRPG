execute unless entity @s[tag=aq.choice] run return run scoreboard players set @s aq.reward 0
execute if score @s aq.reward matches 1 run return run function astral:quest/choice/1
execute if score @s aq.reward matches 2 run return run function astral:quest/choice/2
execute if score @s aq.reward matches 3 run return run function astral:quest/choice/3
execute if score @s aq.reward matches 4 run return run function astral:quest/choice/4
execute if score @s aq.reward matches 5 run return run function astral:quest/choice/5
execute if score @s aq.reward matches 6 run return run function astral:quest/choice/6
execute if score @s aq.reward matches 7 run return run function astral:quest/choice/7
execute if score @s aq.reward matches 8 run return run function astral:quest/choice/8
execute if score @s aq.reward matches 9 run return run function astral:quest/choice/9
execute if score @s aq.reward matches 10 run return run function astral:quest/choice/10
execute if score @s aq.reward matches 11 run return run function astral:quest/choice/11
execute if score @s aq.reward matches 12 run return run function astral:quest/choice/12
scoreboard players set @s aq.reward 0
tellraw @s {"text": "Elegi un numero entre 1 y 12.", "color": "red"}
