function astral:quest/sync
execute unless score @s aq.d0 matches 4 run return 0
execute unless score @s aq.active0 matches 1 run return 0
execute if score @s aq.done0 matches 1 run return 0
execute store result score #ing0 aq.tmp run clear @s minecraft:stone[!minecraft:custom_data] 0
execute store result score #ing1 aq.tmp run clear @s minecraft:iron_ingot[!minecraft:custom_data] 0
execute if score #ing0 aq.tmp matches 64.. if score #ing1 aq.tmp matches 16.. run return run function astral:quest/delivery/4/0
tellraw @s {"text": "Entrega 64 piedras y 16 lingotes de hierro al Herrero. Todavia faltan materiales.", "color": "yellow"}
