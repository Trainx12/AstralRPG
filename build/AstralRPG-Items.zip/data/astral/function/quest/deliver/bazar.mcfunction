function astral:quest/sync
execute unless score @s aq.d1 matches 7 run return 0
execute unless score @s aq.active1 matches 1 run return 0
execute if score @s aq.done1 matches 1 run return 0
execute store result score #ing0 aq.tmp run clear @s *[minecraft:custom_data~{astral:{id:"esencia_elite"}}] 0
execute if score #ing0 aq.tmp matches 5.. run return run function astral:quest/delivery/7/0
tellraw @s {"text": "Entrega 5 Esencias de Elite al Bazar. Todavia faltan materiales.", "color": "yellow"}
