function astral:quest/sync
execute unless score @s aq.d0 matches 2 run return 0
execute if score @s aq.done0 matches 1 run return 0
execute store result score #ing0 aq.tmp run clear @s minecraft:bread[!minecraft:custom_data] 0
execute if score #ing0 aq.tmp matches 32.. run return run function astral:quest/delivery/2/0
execute store result score #ing0 aq.tmp run clear @s minecraft:cooked_beef[!minecraft:custom_data] 0
execute if score #ing0 aq.tmp matches 32.. run return run function astral:quest/delivery/2/1
execute store result score #ing0 aq.tmp run clear @s minecraft:cooked_porkchop[!minecraft:custom_data] 0
execute if score #ing0 aq.tmp matches 32.. run return run function astral:quest/delivery/2/2
execute store result score #ing0 aq.tmp run clear @s minecraft:cooked_chicken[!minecraft:custom_data] 0
execute if score #ing0 aq.tmp matches 32.. run return run function astral:quest/delivery/2/3
execute store result score #ing0 aq.tmp run clear @s minecraft:cooked_mutton[!minecraft:custom_data] 0
execute if score #ing0 aq.tmp matches 32.. run return run function astral:quest/delivery/2/4
execute store result score #ing0 aq.tmp run clear @s minecraft:cooked_rabbit[!minecraft:custom_data] 0
execute if score #ing0 aq.tmp matches 32.. run return run function astral:quest/delivery/2/5
tellraw @s {"text": "Entrega 32 panes o 32 carnes cocidas del mismo tipo a la Tienda. Todavia faltan materiales.", "color": "yellow"}
