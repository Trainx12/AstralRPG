function astral:quest/sync
execute unless score @s aq.d0 matches 3 run return 0
execute unless score @s aq.active0 matches 1 run return 0
execute if score @s aq.done0 matches 1 run return 0
execute store result score #ing0 aq.tmp run clear @s #minecraft:logs[!minecraft:custom_data] 0
execute if score #ing0 aq.tmp matches 64.. run return run function astral:quest/delivery/3/0
tellraw @s {"text": "Entrega 64 troncos al Cronista. Todavia faltan materiales.", "color": "yellow"}
