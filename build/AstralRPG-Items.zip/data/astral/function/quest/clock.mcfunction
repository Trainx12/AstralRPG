scoreboard players operation #today aq.clock = #epoch aq.clock
scoreboard players operation #today aq.clock += #offset aq.clock
scoreboard players operation #today aq.clock /= #seconds aq.clock
execute unless score #today aq.clock = #rolled aq.clock run function astral:quest/roll
