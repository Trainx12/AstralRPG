execute if dimension minecraft:arena run return 0
execute if entity @s[gamemode=spectator] run return 0
function astral:quest/sync
tellraw @s {"text": "Superaste los cinco ecos de la Estrella Astral.", "color": "gold"}
