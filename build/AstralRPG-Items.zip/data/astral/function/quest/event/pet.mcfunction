execute if dimension minecraft:arena run return 0
execute if entity @s[gamemode=spectator] run return 0
function astral:quest/sync
execute unless dimension minecraft:lobby if score @s petsel matches 1..6 run scoreboard players add @s aq.pet 1
