execute if dimension minecraft:arena run return 0
execute if entity @s[gamemode=spectator] run return 0
function astral:quest/sync
scoreboard players add @s aq.boss 1
execute if score @s aq.state matches 5 if score @s aq.f3 matches 0 run function astral:quest/fragment/3
