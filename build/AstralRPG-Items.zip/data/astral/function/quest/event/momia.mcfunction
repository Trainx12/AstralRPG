execute if dimension minecraft:arena run return 0
execute if entity @s[gamemode=spectator] run return 0
function astral:quest/sync
execute if score @s aq.active2 matches 1 run scoreboard players add @s aq.boss 1
execute if score @s aq.accepted matches 1 if score @s aq.state matches 5 if score @s aq.f3 matches 0 run function astral:quest/fragment/3
