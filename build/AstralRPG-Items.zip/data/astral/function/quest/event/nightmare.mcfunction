execute if dimension minecraft:arena run return 0
execute if entity @s[gamemode=spectator] run return 0
function astral:quest/sync
execute if score @s aq.active2 matches 1 run scoreboard players add @s aq.nightmare 1
