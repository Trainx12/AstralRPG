execute if dimension minecraft:arena run return 0
execute if entity @s[gamemode=spectator] run return 0
function astral:quest/sync
function astral:quest/event/hostil
execute if score @s aq.state matches 4 run execute if score @s aq.accepted matches 1 run scoreboard players add @s aq.face 1
