execute if dimension minecraft:arena run return 0
execute if entity @s[gamemode=spectator] run return 0
function astral:quest/sync
function astral:quest/event/hostil
scoreboard players add @s aq.spider 1
