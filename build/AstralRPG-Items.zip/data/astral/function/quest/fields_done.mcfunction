clear @s *[minecraft:custom_data~{astral:{id:"esencia_elite"}}] 3
function astral:quest/complete/2
