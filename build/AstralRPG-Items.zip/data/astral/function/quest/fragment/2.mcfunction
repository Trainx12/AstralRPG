scoreboard players set @s aq.f2 1
loot give @s loot astral:item/fragmento_pantano
tellraw @s {"text": "Una parte de la estrella te reconoce. Volve con el Viajero.", "color": "aqua"}
