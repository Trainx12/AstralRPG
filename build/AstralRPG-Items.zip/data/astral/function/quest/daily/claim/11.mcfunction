execute if score @s aq.done2 matches 1 run return 0
scoreboard players set @s aq.done2 1
scoreboard players add @s aqmoney 1500
tellraw @s {"text": "Diaria completada: Expedicion a las Minas.", "color": "green"}
loot give @s loot astral:item/alma_corrupta
function astral:quest/streak
