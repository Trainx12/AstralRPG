execute unless score @s aq.d2 matches 11 run return 0
execute unless score @s aq.active2 matches 1 run return 0
execute if score @s aq.done2 matches 1 run return 0
execute unless score @s aq.mine matches 1.. run return 0
scoreboard players set @s aq.done2 1
scoreboard players set @s aq.active2 0
scoreboard players add @s aqmoney 1500
tellraw @s {"text": "Diaria completada: Expedicion a las Minas.", "color": "green"}
loot give @s loot astral:item/alma_corrupta
function astral:quest/streak
