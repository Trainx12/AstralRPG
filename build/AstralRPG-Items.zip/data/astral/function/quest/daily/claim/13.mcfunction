execute unless score @s aq.d2 matches 13 run return 0
execute unless score @s aq.active2 matches 1 run return 0
execute if score @s aq.done2 matches 1 run return 0
execute unless score @s aq.nightmare matches 1.. run return 0
scoreboard players set @s aq.done2 1
scoreboard players set @s aq.active2 0
scoreboard players add @s aqmoney 1500
tellraw @s {"text": "Diaria completada: Pesadilla.", "color": "green"}
execute if predicate astral:quest/chispa run loot give @s loot astral:item/chispa_astral
function astral:quest/streak
