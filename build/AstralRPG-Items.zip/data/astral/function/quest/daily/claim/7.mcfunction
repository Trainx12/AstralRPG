execute unless score @s aq.d1 matches 7 run return 0
execute unless score @s aq.active1 matches 1 run return 0
execute if score @s aq.done1 matches 1 run return 0
scoreboard players set @s aq.done1 1
scoreboard players set @s aq.active1 0
scoreboard players add @s aqmoney 750
tellraw @s {"text": "Diaria completada: Encargo del Bazar.", "color": "green"}
function astral:quest/streak
