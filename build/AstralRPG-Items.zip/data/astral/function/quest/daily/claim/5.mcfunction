execute unless score @s aq.d0 matches 5 run return 0
execute unless score @s aq.active0 matches 1 run return 0
execute if score @s aq.done0 matches 1 run return 0
execute unless score @s aq.spider matches 10.. run return 0
scoreboard players set @s aq.done0 1
scoreboard players set @s aq.active0 0
scoreboard players add @s aqmoney 300
tellraw @s {"text": "Diaria completada: Plaga de aranas.", "color": "green"}
function astral:quest/streak
