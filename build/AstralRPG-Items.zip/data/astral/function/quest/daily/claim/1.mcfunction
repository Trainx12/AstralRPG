execute if score @s aq.done0 matches 1 run return 0
scoreboard players set @s aq.done0 1
scoreboard players add @s aqmoney 300
tellraw @s {"text": "Diaria completada: Ronda nocturna.", "color": "green"}
function astral:quest/streak
