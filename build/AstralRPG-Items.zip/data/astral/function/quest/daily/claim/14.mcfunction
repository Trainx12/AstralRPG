execute unless score @s aq.d2 matches 14 run return 0
execute unless score @s aq.active2 matches 1 run return 0
execute if score @s aq.done2 matches 1 run return 0
scoreboard players set @s aq.done2 1
scoreboard players add @s aqmoney 1500
tellraw @s {"text": "Diaria completada: Mejora arriesgada.", "color": "green"}
loot give @s loot astral:item/esencia_elite
loot give @s loot astral:item/esencia_elite
function astral:quest/streak
