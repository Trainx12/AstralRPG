execute unless score @s aq.d0 matches 3 run return 0
execute unless score @s aq.active0 matches 1 run return 0
execute if score @s aq.done0 matches 1 run return 0
scoreboard players set @s aq.done0 1
scoreboard players add @s aqmoney 300
tellraw @s {"text": "Diaria completada: Madera para el Refugio.", "color": "green"}
function astral:quest/streak
