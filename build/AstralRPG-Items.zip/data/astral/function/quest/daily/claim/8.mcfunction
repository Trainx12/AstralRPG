execute unless score @s aq.d1 matches 8 run return 0
execute unless score @s aq.active1 matches 1 run return 0
execute if score @s aq.done1 matches 1 run return 0
scoreboard players set @s aq.done1 1
scoreboard players add @s aqmoney 750
tellraw @s {"text": "Diaria completada: Explorador.", "color": "green"}
function astral:quest/streak
