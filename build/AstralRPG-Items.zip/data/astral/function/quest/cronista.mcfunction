function astral:quest/sync
execute unless score #today aq.clock matches 1.. run return run tellraw @s {"text": "El reloj de diarias no esta conectado. Avisa al administrador.", "color": "yellow"}
execute if score @s aq.d0 matches 1 if score @s aq.done0 matches 0 if score @s aq.hostil matches 15.. run function astral:quest/daily/claim/1
execute if score @s aq.d0 matches 1 run tellraw @s {"text": "[1] Ronda nocturna: Mata 15 hostiles de AstralRPG. Premio: 300$.", "color": "aqua"}
execute if score @s aq.d0 matches 1 run tellraw @s [{"text":"Cobrada (0=no, 1=si): "},{"score":{"name":"@s","objective":"aq.done0"}}]
execute if score @s aq.d0 matches 2 run tellraw @s {"text": "[1] Provisiones: Entrega 32 panes o 32 carnes cocidas del mismo tipo a la Tienda. Premio: 300$.", "color": "aqua"}
execute if score @s aq.d0 matches 2 run tellraw @s [{"text":"Cobrada (0=no, 1=si): "},{"score":{"name":"@s","objective":"aq.done0"}}]
execute if score @s aq.d0 matches 3 run tellraw @s {"text": "[1] Madera para el Refugio: Entrega 64 troncos al Cronista. Premio: 300$.", "color": "aqua"}
execute if score @s aq.d0 matches 3 run tellraw @s [{"text":"Cobrada (0=no, 1=si): "},{"score":{"name":"@s","objective":"aq.done0"}}]
execute if score @s aq.d0 matches 4 run tellraw @s {"text": "[1] Piedra y hierro: Entrega 64 piedras y 16 lingotes de hierro al Herrero. Premio: 300$.", "color": "aqua"}
execute if score @s aq.d0 matches 4 run tellraw @s [{"text":"Cobrada (0=no, 1=si): "},{"score":{"name":"@s","objective":"aq.done0"}}]
execute if score @s aq.d0 matches 5 if score @s aq.done0 matches 0 if score @s aq.spider matches 10.. run function astral:quest/daily/claim/5
execute if score @s aq.d0 matches 5 run tellraw @s {"text": "[1] Plaga de aranas: Mata 10 Aranas Amatista. Premio: 300$.", "color": "aqua"}
execute if score @s aq.d0 matches 5 run tellraw @s [{"text":"Cobrada (0=no, 1=si): "},{"score":{"name":"@s","objective":"aq.done0"}}]
execute if score @s aq.d1 matches 6 if score @s aq.done1 matches 0 if score @s aq.elite matches 3.. run function astral:quest/daily/claim/6
execute if score @s aq.d1 matches 6 run tellraw @s {"text": "[2] Caza de elites: Mata 3 elites vanilla o de MythicMobs. Premio: 750$.", "color": "aqua"}
execute if score @s aq.d1 matches 6 run tellraw @s [{"text":"Cobrada (0=no, 1=si): "},{"score":{"name":"@s","objective":"aq.done1"}}]
execute if score @s aq.d1 matches 7 run tellraw @s {"text": "[2] Encargo del Bazar: Entrega 5 Esencias de Elite al Bazar. Premio: 750$.", "color": "aqua"}
execute if score @s aq.d1 matches 7 run tellraw @s [{"text":"Cobrada (0=no, 1=si): "},{"score":{"name":"@s","objective":"aq.done1"}}]
execute if score @s aq.d1 matches 8 if score @s aq.done1 matches 0 if score @s aq.biomes matches 3.. run function astral:quest/daily/claim/8
execute if score @s aq.d1 matches 8 run tellraw @s {"text": "[2] Explorador: Visita 3 zonas distintas: desierto, nieve, pantano, bosque, llanura, Nether. Premio: 750$.", "color": "aqua"}
execute if score @s aq.d1 matches 8 run tellraw @s [{"text":"Cobrada (0=no, 1=si): "},{"score":{"name":"@s","objective":"aq.done1"}}]
execute if score @s aq.d1 matches 9 if score @s aq.done1 matches 0 if score @s aq.pet matches 25.. run function astral:quest/daily/claim/9
execute if score @s aq.d1 matches 9 run tellraw @s {"text": "[2] Mascota entrenada: Mata 25 mobs con una mascota seleccionada, fuera del lobby. Premio: 750$.", "color": "aqua"}
execute if score @s aq.d1 matches 9 run tellraw @s [{"text":"Cobrada (0=no, 1=si): "},{"score":{"name":"@s","objective":"aq.done1"}}]
execute if score @s aq.d1 matches 10 if score @s aq.done1 matches 0 if score @s aq.ride matches 100000.. run function astral:quest/daily/claim/10
execute if score @s aq.d1 matches 10 run tellraw @s {"text": "[2] Jinete: Recorre 1000 bloques en una montura terrestre. Premio: 750$.", "color": "aqua"}
execute if score @s aq.d1 matches 10 run tellraw @s [{"text":"Cobrada (0=no, 1=si): "},{"score":{"name":"@s","objective":"aq.done1"}}]
execute if score @s aq.d2 matches 11 if score @s aq.done2 matches 0 if score @s aq.mine matches 1.. run function astral:quest/daily/claim/11
execute if score @s aq.d2 matches 11 run tellraw @s {"text": "[3] Expedicion a las Minas: Completa las Minas Olvidadas. Premio: 1500$.", "color": "aqua"}
execute if score @s aq.d2 matches 11 run tellraw @s [{"text":"Cobrada (0=no, 1=si): "},{"score":{"name":"@s","objective":"aq.done2"}}]
execute if score @s aq.d2 matches 12 if score @s aq.done2 matches 0 if score @s aq.boss matches 1.. run function astral:quest/daily/claim/12
execute if score @s aq.d2 matches 12 run tellraw @s {"text": "[3] Cazador de jefes: Derrota a un jefe. Premio: 1500$.", "color": "aqua"}
execute if score @s aq.d2 matches 12 run tellraw @s [{"text":"Cobrada (0=no, 1=si): "},{"score":{"name":"@s","objective":"aq.done2"}}]
execute if score @s aq.d2 matches 13 if score @s aq.done2 matches 0 if score @s aq.nightmare matches 1.. run function astral:quest/daily/claim/13
execute if score @s aq.d2 matches 13 run tellraw @s {"text": "[3] Pesadilla: Mata un elite vanilla de tier IV o V. Premio: 1500$.", "color": "aqua"}
execute if score @s aq.d2 matches 13 run tellraw @s [{"text":"Cobrada (0=no, 1=si): "},{"score":{"name":"@s","objective":"aq.done2"}}]
execute if score @s aq.d2 matches 14 if score @s aq.done2 matches 0 if score @s aq.upgrade matches 1.. run function astral:quest/daily/claim/14
execute if score @s aq.d2 matches 14 run tellraw @s {"text": "[3] Mejora arriesgada: Intenta una mejora +5 o mayor en el Herrero. Premio: 1500$.", "color": "aqua"}
execute if score @s aq.d2 matches 14 run tellraw @s [{"text":"Cobrada (0=no, 1=si): "},{"score":{"name":"@s","objective":"aq.done2"}}]
function astral:quest/deliver/cronista
