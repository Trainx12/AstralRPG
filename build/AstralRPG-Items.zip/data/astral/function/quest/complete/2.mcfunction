scoreboard players set @s aq.state 3
scoreboard players set @s aq.accepted 0
scoreboard players add @s aqmoney 500
tag @s add aq.choice
tellraw @s {"text": "Podes elegir una armadura tier I: /trigger aq.reward set N (1-4 Berserker, 5-8 Mago, 9-12 Arquero; casco, pechera, grebas, botas).", "color": "gold"}
tellraw @s {"text": "Capitulo terminado. Recompensa: 500$.", "color": "green"}
tellraw @s {"text": "La marea: derrota al Cangrejo en las playas y volve con el Viajero.", "color": "aqua"}
