scoreboard players set @s aq.state 8
scoreboard players set @s aq.accepted 0
scoreboard players add @s aqmoney 3000
loot give @s loot astral:item/chispa_astral
tellraw @s {"text": "Capitulo terminado. Recompensa: 3000$.", "color": "green"}
tellraw @s {"text": "El corazon de la forja: forja una pieza tier V y derrota al Golem de Forja.", "color": "aqua"}
