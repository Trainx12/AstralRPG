scoreboard players set @s aq.state 6
scoreboard players add @s aqmoney 2000
loot give @s loot astral:item/alma_corrupta
tellraw @s {"text": "Capitulo terminado. Recompensa: 2000$.", "color": "green"}
tellraw @s {"text": "Minas Olvidadas: completa las cuatro salas.", "color": "aqua"}
