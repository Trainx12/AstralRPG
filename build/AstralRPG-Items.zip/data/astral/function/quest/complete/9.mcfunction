scoreboard players set @s aq.state 10
scoreboard players add @s aqmoney 10000
tag @s add aq.title
particle minecraft:firework ~ ~4 ~ 2 3 2 0.1 100
playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 1 1
tellraw @s {"text": "La Estrella Astral vuelve a brillar. Sos Portador de la Estrella. El Santuario Celestial esta abierto.", "color": "gold"}
tellraw @s {"text": "Capitulo terminado. Recompensa: 10000$.", "color": "green"}
