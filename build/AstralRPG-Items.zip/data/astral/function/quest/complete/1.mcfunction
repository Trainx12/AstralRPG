scoreboard players set @s aq.state 2
scoreboard players set @s aq.accepted 0
scoreboard players add @s aqmoney 300
tellraw @s {"text": "Capitulo terminado. Recompensa: 300$.", "color": "green"}
tellraw @s {"text": "Los campos: mata 10 Espantapajaros, 10 Abejorros y 1 elite; entrega 3 Esencias al Cronista.", "color": "aqua"}
