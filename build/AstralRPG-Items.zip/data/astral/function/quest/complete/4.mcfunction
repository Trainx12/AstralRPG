scoreboard players set @s aq.state 5
scoreboard players add @s aqmoney 1500
tellraw @s {"text": "Capitulo terminado. Recompensa: 1500$.", "color": "green"}
tellraw @s {"text": "Arena con memoria: derrota a la Momia.", "color": "aqua"}
