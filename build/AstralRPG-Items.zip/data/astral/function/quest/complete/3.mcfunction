scoreboard players set @s aq.state 4
scoreboard players set @s aq.accepted 0
scoreboard players add @s aqmoney 1000
tellraw @s {"text": "Capitulo terminado. Recompensa: 1000$.", "color": "green"}
tellraw @s {"text": "El bosque: mata 15 Caras Voladoras y derrota al Chaman.", "color": "aqua"}
