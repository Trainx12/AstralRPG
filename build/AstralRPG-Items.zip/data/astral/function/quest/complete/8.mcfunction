scoreboard players set @s aq.state 9
scoreboard players set @s aq.accepted 0
scoreboard players add @s aqmoney 5000
tellraw @s {"text": "Capitulo terminado. Recompensa: 5000$.", "color": "green"}
tellraw @s {"text": "Encender la estrella: habla con el Viajero para reunir los fragmentos.", "color": "aqua"}
