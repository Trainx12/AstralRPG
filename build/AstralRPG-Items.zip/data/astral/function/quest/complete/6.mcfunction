scoreboard players set @s aq.state 7
scoreboard players set @s aq.accepted 0
scoreboard players add @s aqmoney 2500
tellraw @s {"text": "Capitulo terminado. Recompensa: 2500$.", "color": "green"}
tellraw @s {"text": "El silencio blanco: derrota al Yeti.", "color": "aqua"}
