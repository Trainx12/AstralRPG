execute if score @s aq.f4 matches 1 run return run function astral:quest/complete/6
tellraw @s {"text": "Minas Olvidadas: completa las cuatro salas.", "color": "gray"}
