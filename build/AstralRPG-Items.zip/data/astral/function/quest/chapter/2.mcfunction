execute store result score #have aq.tmp run clear @s *[minecraft:custom_data~{astral:{id:"esencia_elite"}}] 0
execute if score @s aq.scare matches 10.. if score @s aq.bee matches 10.. if score @s aq.helite matches 1.. if score #have aq.tmp matches 3.. run return run function astral:quest/fields_done
tellraw @s {"text": "Los campos: mata 10 Espantapajaros, 10 Abejorros y 1 elite; entrega 3 Esencias al Cronista.", "color": "gray"}
tellraw @s [{"text":"Espantapajaros: "},{"score":{"name":"@s","objective":"aq.scare"}},{"text":"/10 | Abejorros: "},{"score":{"name":"@s","objective":"aq.bee"}},{"text":"/10 | Elites: "},{"score":{"name":"@s","objective":"aq.helite"}},{"text":"/1"}]
