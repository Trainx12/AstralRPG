execute if score @s aq.f1 matches 1 run return run function astral:quest/complete/3
tellraw @s {"text": "La marea: derrota al Cangrejo en las playas y volve con el Viajero.", "color": "gray"}
