tellraw @s {"text": "Cronista: guarde el eco de cada fragmento que trajiste. Juntos vuelven a encender la estrella.", "color": "aqua"}
function astral:quest/complete/9
