execute if score @s aq.f5 matches 1 run return run function astral:quest/complete/7
tellraw @s {"text": "El silencio blanco: derrota al Yeti.", "color": "gray"}
