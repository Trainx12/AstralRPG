execute if score @s aq.f2 matches 1 if score @s aq.face matches 15.. run return run function astral:quest/complete/4
tellraw @s {"text": "El bosque: mata 15 Caras Voladoras y derrota al Chaman.", "color": "gray"}
