execute if score @s aq.herrero matches 1 if score @s aq.forge1 matches 1 run return run function astral:quest/complete/1
tellraw @s {"text": "Llegar al Refugio: habla con el Herrero y forja una pieza de tier I.", "color": "gray"}
