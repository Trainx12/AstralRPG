execute if score @s aq.f3 matches 1 run return run function astral:quest/complete/5
tellraw @s {"text": "Arena con memoria: derrota a la Momia.", "color": "gray"}
