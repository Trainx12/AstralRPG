execute if score @s aq.f6 matches 1 if score @s aq.forge5 matches 1 run return run function astral:quest/complete/8
tellraw @s {"text": "El corazon de la forja: forja una pieza tier V y derrota al Golem de Forja.", "color": "gray"}
