execute unless block ~ ~ ~ #astral:passable run return run particle minecraft:crit ~ ~ ~ 0.2 0.2 0.2 0.1 12
scoreboard players add #steps astral.tmp 1
particle minecraft:crit ~ ~ ~ 0 0 0 0 1
execute if score #steps astral.tmp matches 64.. run return run scoreboard players set #steps astral.tmp 0
execute positioned ^ ^ ^0.5 run function astral:grapple/ray
