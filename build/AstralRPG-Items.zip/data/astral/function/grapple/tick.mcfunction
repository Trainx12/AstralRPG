scoreboard players reset @s astral.grap
