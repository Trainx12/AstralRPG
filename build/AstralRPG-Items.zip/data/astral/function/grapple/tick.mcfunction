scoreboard players remove @s astral.grap 1
execute if entity @s[predicate=astral:sneaking] run scoreboard players set @s astral.grap 0
execute unless items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{id:"gancho"}}] run scoreboard players set @s astral.grap 0
execute if score @s astral.grap matches ..0 run effect give @s minecraft:slow_falling 2 0 true
execute if score @s astral.grap matches ..0 run scoreboard players reset @s astral.grap
