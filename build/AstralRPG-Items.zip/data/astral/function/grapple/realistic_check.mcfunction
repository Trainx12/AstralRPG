tag @s remove astral.realistic.held
execute if items entity @s weapon.mainhand minecraft:fishing_rod[minecraft:custom_data~{astral:{id:"gancho_realista"}}] run tag @s add astral.realistic.held
