execute if score @s astral.grap matches 1.. run return run scoreboard players set @s astral.grap 1
scoreboard players set #steps astral.tmp 0
execute anchored eyes positioned ^ ^ ^1 run function astral:grapple/ray
execute if score #steps astral.tmp matches ..0 run return run title @s actionbar {"text": "No hay nada donde engancharse", "color": "gray", "italic": false}
scoreboard players operation @s astral.grap = #steps astral.tmp
scoreboard players operation @s astral.grap /= #3 astral.const
scoreboard players add @s astral.grap 6
execute if score @s astral.grap matches 30.. run scoreboard players set @s astral.grap 30
playsound minecraft:entity.fishing_bobber.throw player @a[distance=..16] ~ ~ ~ 1 0.6
