execute as @a[scores={astral.use=1..}] at @s run function astral:use/main
scoreboard players remove @a[scores={astral.cd=1..}] astral.cd 1
execute as @a[scores={astral.grap=1..}] run function astral:grapple/tick
execute as @e[type=#minecraft:arrows,tag=astral.bowshot] at @s run function astral:bow/norm
