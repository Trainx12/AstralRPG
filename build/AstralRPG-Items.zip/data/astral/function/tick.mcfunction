execute as @a[scores={astral.use=1..}] at @s run function astral:use/main
execute as @a[scores={astral.forja=1..}] at @s run function astral:forge/craft
scoreboard players remove @a[scores={astral.cd=1..}] astral.cd 1
execute as @a[scores={astral.grap=1..}] run function astral:grapple/tick
execute as @e[type=#minecraft:arrows,tag=astral.bowshot] at @s run function astral:bow/norm
# si soltaste el arco, se reinicia la carga
scoreboard players set @a[tag=!astral.drew,scores={astral.draw=1..}] astral.draw 0
tag @a remove astral.drew
