advancement revoke @s only astral:kill/manzana2_comun
execute if predicate astral:chance/30 run function astral:drop/give {id:"manzana_t2",name:"Manzana Mineral"}
