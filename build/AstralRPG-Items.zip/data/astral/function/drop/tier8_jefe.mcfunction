advancement revoke @s only astral:kill/tier8_jefe
function astral:drop/give {id:"fragmento_ocaso",name:"Fragmento de Ocaso"}
function astral:drop/give {id:"esquirla_eclipse",name:"Esquirla de Eclipse"}
function astral:drop/give {id:"nucleo_supernova",name:"Nucleo de Supernova"}
