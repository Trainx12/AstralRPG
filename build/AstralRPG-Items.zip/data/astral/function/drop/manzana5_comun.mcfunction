advancement revoke @s only astral:kill/manzana5_comun
execute if predicate astral:chance/30 run function astral:drop/give {id:"manzana_t5",name:"Manzana Ignea"}
