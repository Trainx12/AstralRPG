advancement revoke @s only astral:kill/piglin_brute
execute if predicate astral:chance/150 run function astral:drop/give {id:"fragmento_umbrio",name:"Fragmento Umbrio"}
execute if predicate astral:chance/60 run function astral:drop/give {id:"nucleo_furia",name:"Nucleo de Furia"}
