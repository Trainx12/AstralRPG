advancement revoke @s only astral:kill/tier6_jefe
function astral:drop/give {id:"fragmento_ocaso",name:"Fragmento de Ocaso"}
