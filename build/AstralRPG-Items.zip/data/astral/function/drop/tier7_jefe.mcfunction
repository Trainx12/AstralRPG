advancement revoke @s only astral:kill/tier7_jefe
function astral:drop/give {id:"fragmento_ocaso",name:"Fragmento de Ocaso"}
function astral:drop/give {id:"esquirla_eclipse",name:"Esquirla de Eclipse"}
