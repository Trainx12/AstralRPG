advancement revoke @s only astral:kill/any
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{reset_cd:1}}] run scoreboard players set @s astral.cd 0
