advancement revoke @s only astral:kill/manzana9_comun
execute if predicate astral:chance/30 run function astral:drop/give {id:"manzana_t9",name:"Manzana del Vacio"}
