$loot give @s loot astral:item/$(id)
$title @s actionbar [{"text": "Conseguiste: ", "color": "gray", "italic": false}, {"text": "$(name)", "color": "light_purple", "italic": false}]
playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.6 0.7
