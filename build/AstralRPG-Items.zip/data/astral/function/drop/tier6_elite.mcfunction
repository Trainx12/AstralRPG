advancement revoke @s only astral:kill/tier6_elite
execute if predicate astral:chance/120 run function astral:drop/give {id:"fragmento_ocaso",name:"Fragmento de Ocaso"}
