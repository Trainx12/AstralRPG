advancement revoke @s only astral:kill/tier10_jefe
function astral:drop/give {id:"fragmento_ocaso",name:"Fragmento de Ocaso"}
function astral:drop/give {id:"esquirla_eclipse",name:"Esquirla de Eclipse"}
function astral:drop/give {id:"nucleo_supernova",name:"Nucleo de Supernova"}
function astral:drop/give {id:"esencia_vacio",name:"Esencia del Vacio"}
function astral:drop/give {id:"corazon_fin",name:"Corazon del Fin"}
