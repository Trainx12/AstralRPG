advancement revoke @s only astral:kill/manzana5_elite
execute if predicate astral:chance/120 run function astral:drop/give {id:"manzana_t5",name:"Manzana Ignea"}
