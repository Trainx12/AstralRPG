advancement revoke @s only astral:kill/elite1
execute if predicate astral:chance/500 run function astral:drop/give {id:"esencia_elite",name:"Esencia de Elite"}
execute if predicate astral:chance/150 if dimension minecraft:the_nether run function astral:drop/give {id:"fragmento_umbrio",name:"Fragmento Umbrio"}
execute if predicate astral:chance/150 if dimension minecraft:the_end run function astral:drop/give {id:"fragmento_astral",name:"Fragmento Astral"}
execute if predicate astral:chance/80 if dimension minecraft:overworld run function astral:drop/give {id:"gema_luminica",name:"Gema Luminica"}
