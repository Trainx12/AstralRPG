advancement revoke @s only astral:loot/chest
execute if dimension minecraft:overworld if predicate astral:chance/250 run function astral:drop/give {id:"gema_luminica",name:"Gema Luminica"}
