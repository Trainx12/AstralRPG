advancement revoke @s only astral:kill/manzana7_comun
execute if predicate astral:chance/30 run function astral:drop/give {id:"manzana_t7",name:"Manzana del Eclipse"}
