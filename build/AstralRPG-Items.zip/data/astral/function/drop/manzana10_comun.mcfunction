advancement revoke @s only astral:kill/manzana10_comun
execute if predicate astral:chance/30 run function astral:drop/give {id:"manzana_t10",name:"Manzana del Fin"}
