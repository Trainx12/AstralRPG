advancement revoke @s only astral:kill/tier5_jefe
execute if predicate astral:chance/500 run function astral:drop/give {id:"fragmento_ocaso",name:"Fragmento de Ocaso"}
