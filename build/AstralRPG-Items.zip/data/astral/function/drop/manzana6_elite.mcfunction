advancement revoke @s only astral:kill/manzana6_elite
execute if predicate astral:chance/120 run function astral:drop/give {id:"manzana_t6",name:"Manzana del Ocaso"}
