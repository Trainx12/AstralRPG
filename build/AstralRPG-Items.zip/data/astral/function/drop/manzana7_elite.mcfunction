advancement revoke @s only astral:kill/manzana7_elite
execute if predicate astral:chance/120 run function astral:drop/give {id:"manzana_t7",name:"Manzana del Eclipse"}
