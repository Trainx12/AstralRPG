advancement revoke @s only astral:kill/manzana9_elite
execute if predicate astral:chance/120 run function astral:drop/give {id:"manzana_t9",name:"Manzana del Vacio"}
