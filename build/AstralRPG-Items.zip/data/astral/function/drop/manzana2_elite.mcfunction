advancement revoke @s only astral:kill/manzana2_elite
execute if predicate astral:chance/120 run function astral:drop/give {id:"manzana_t2",name:"Manzana Mineral"}
