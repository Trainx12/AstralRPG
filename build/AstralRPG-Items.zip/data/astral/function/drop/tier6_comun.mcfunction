advancement revoke @s only astral:kill/tier6_comun
execute if predicate astral:chance/12 run function astral:drop/give {id:"fragmento_ocaso",name:"Fragmento de Ocaso"}
