advancement revoke @s only astral:kill/manzana8_elite
execute if predicate astral:chance/120 run function astral:drop/give {id:"manzana_t8",name:"Manzana Supernova"}
