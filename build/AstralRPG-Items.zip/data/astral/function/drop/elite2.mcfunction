advancement revoke @s only astral:kill/elite2
function astral:drop/give {id:"esencia_elite",name:"Esencia de Elite"}
execute if predicate astral:chance/300 run function astral:drop/give {id:"esencia_elite",name:"Esencia de Elite"}
execute if predicate astral:chance/300 if dimension minecraft:the_nether run function astral:drop/give {id:"fragmento_umbrio",name:"Fragmento Umbrio"}
execute if predicate astral:chance/300 if dimension minecraft:the_end run function astral:drop/give {id:"fragmento_astral",name:"Fragmento Astral"}
execute if predicate astral:chance/160 if dimension minecraft:overworld run function astral:drop/give {id:"gema_luminica",name:"Gema Luminica"}
function astral:quest/event/elite
