advancement revoke @s only astral:kill/manzana4_comun
execute if predicate astral:chance/30 run function astral:drop/give {id:"manzana_t4",name:"Manzana Glacial"}
