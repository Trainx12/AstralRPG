advancement revoke @s only astral:kill/tier5_elite
execute if predicate astral:chance/40 run function astral:drop/give {id:"fragmento_ocaso",name:"Fragmento de Ocaso"}
