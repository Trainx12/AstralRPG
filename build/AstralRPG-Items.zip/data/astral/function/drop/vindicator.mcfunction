advancement revoke @s only astral:kill/vindicator
execute if predicate astral:chance/100 run function astral:drop/give {id:"nucleo_eolico",name:"Nucleo Eolico"}
