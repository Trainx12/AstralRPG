advancement revoke @s only astral:kill/manzana6_comun
execute if predicate astral:chance/30 run function astral:drop/give {id:"manzana_t6",name:"Manzana del Ocaso"}
