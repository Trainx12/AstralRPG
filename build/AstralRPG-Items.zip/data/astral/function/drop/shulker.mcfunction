advancement revoke @s only astral:kill/shulker
execute if predicate astral:chance/100 run function astral:drop/give {id:"corazon_shulker",name:"Corazon de Shulker"}
