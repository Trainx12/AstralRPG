advancement revoke @s only astral:kill/tier10_comun
execute if predicate astral:chance/12 run function astral:drop/give {id:"fragmento_ocaso",name:"Fragmento de Ocaso"}
execute if predicate astral:chance/12 run function astral:drop/give {id:"esquirla_eclipse",name:"Esquirla de Eclipse"}
execute if predicate astral:chance/12 run function astral:drop/give {id:"nucleo_supernova",name:"Nucleo de Supernova"}
execute if predicate astral:chance/12 run function astral:drop/give {id:"esencia_vacio",name:"Esencia del Vacio"}
execute if predicate astral:chance/12 run function astral:drop/give {id:"corazon_fin",name:"Corazon del Fin"}
