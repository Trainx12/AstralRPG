advancement revoke @s only astral:kill/manzana3_elite
execute if predicate astral:chance/120 run function astral:drop/give {id:"manzana_t3",name:"Manzana Ancestral"}
