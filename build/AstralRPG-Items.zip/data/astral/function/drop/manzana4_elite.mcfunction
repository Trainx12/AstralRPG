advancement revoke @s only astral:kill/manzana4_elite
execute if predicate astral:chance/120 run function astral:drop/give {id:"manzana_t4",name:"Manzana Glacial"}
