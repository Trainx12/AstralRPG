advancement revoke @s only astral:kill/wither_skeleton
execute if predicate astral:chance/80 run function astral:drop/give {id:"esencia_nether",name:"Esencia del Nether"}
execute if predicate astral:chance/150 run function astral:drop/give {id:"fragmento_umbrio",name:"Fragmento Umbrio"}
execute if predicate astral:chance/60 run function astral:drop/give {id:"nucleo_furia",name:"Nucleo de Furia"}
