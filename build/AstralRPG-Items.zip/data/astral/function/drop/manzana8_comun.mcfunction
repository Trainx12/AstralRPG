advancement revoke @s only astral:kill/manzana8_comun
execute if predicate astral:chance/30 run function astral:drop/give {id:"manzana_t8",name:"Manzana Supernova"}
