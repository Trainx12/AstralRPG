advancement revoke @s only astral:kill/nether_esencia
execute if predicate astral:chance/50 run function astral:drop/give {id:"esencia_nether",name:"Esencia del Nether"}
