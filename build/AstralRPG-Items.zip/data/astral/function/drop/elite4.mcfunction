advancement revoke @s only astral:kill/elite4
function astral:drop/give {id:"alma_corrupta",name:"Alma Corrupta"}
execute if predicate astral:chance/400 run function astral:drop/give {id:"alma_corrupta",name:"Alma Corrupta"}
function astral:drop/give {id:"esencia_elite",name:"Esencia de Elite"}
function astral:drop/give {id:"esencia_elite",name:"Esencia de Elite"}
execute if predicate astral:chance/600 if dimension minecraft:the_nether run function astral:drop/give {id:"fragmento_umbrio",name:"Fragmento Umbrio"}
execute if predicate astral:chance/600 if dimension minecraft:the_end run function astral:drop/give {id:"fragmento_astral",name:"Fragmento Astral"}
execute if predicate astral:chance/320 if dimension minecraft:overworld run function astral:drop/give {id:"gema_luminica",name:"Gema Luminica"}
function astral:quest/event/elite
function astral:quest/event/nightmare
