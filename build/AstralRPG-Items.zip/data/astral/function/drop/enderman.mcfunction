advancement revoke @s only astral:kill/enderman
execute if predicate astral:chance/50 run function astral:drop/give {id:"cristal_arcano",name:"Cristal Arcano"}
execute if dimension minecraft:the_end if predicate astral:chance/200 run function astral:drop/give {id:"fragmento_astral",name:"Fragmento Astral"}
