advancement revoke @s only astral:kill/nether
execute if predicate astral:chance/20 run function astral:drop/give {id:"gema_umbria",name:"Gema Umbria"}
