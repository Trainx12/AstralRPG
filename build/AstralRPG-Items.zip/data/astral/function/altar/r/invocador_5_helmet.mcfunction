execute unless entity @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_invocador_3_helmet_1] run return 0
execute unless entity @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_cristal_refinado_3] run return 0
execute unless entity @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_corazon_shulker_1] run return 0
execute unless entity @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_nucleo_astral_1] run return 0
execute unless entity @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_gema_luminica_perfecta_1] run return 0
execute as @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_invocador_3_helmet_1,limit=1,sort=nearest] run function astral:forge/ipl/invocador_5_helmet/invocador_3_helmet {slot:"contents"}
execute as @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_cristal_refinado_3,limit=1,sort=nearest] run item modify entity @s contents astral:sub/3
execute as @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_corazon_shulker_1,limit=1,sort=nearest] run item modify entity @s contents astral:sub/1
execute as @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_nucleo_astral_1,limit=1,sort=nearest] run item modify entity @s contents astral:sub/1
execute as @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_gema_luminica_perfecta_1,limit=1,sort=nearest] run item modify entity @s contents astral:sub/1
function astral:quest/event/forge5
particle minecraft:enchant ~ ~0.5 ~ 0.3 0.3 0.3 1 40
particle minecraft:end_rod ~ ~0.5 ~ 0.2 0.2 0.2 0.02 12
playsound minecraft:block.smithing_table.use block @a[distance=..12] ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use block @a[distance=..12] ~ ~ ~ 0.8 1.4
title @a[distance=..6] actionbar [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Capucha Kintsugi", "color": "#7b5cff", "italic": false}]
return 1
