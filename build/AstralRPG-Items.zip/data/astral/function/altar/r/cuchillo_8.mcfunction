execute unless entity @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_cuchillo_7_1] run return 0
execute unless entity @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_nucleo_supernova_4] run return 0
execute unless entity @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_esquirla_eclipse_2] run return 0
execute unless entity @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_nucleo_furia_pura_2] run return 0
execute as @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_cuchillo_7_1,limit=1,sort=nearest] run function astral:forge/ipl/cuchillo_8/cuchillo_7 {slot:"contents"}
execute as @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_nucleo_supernova_4,limit=1,sort=nearest] run item modify entity @s contents astral:sub/4
execute as @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_esquirla_eclipse_2,limit=1,sort=nearest] run item modify entity @s contents astral:sub/2
execute as @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_nucleo_furia_pura_2,limit=1,sort=nearest] run item modify entity @s contents astral:sub/2
particle minecraft:enchant ~ ~0.5 ~ 0.3 0.3 0.3 1 40
particle minecraft:end_rod ~ ~0.5 ~ 0.2 0.2 0.2 0.02 12
playsound minecraft:block.smithing_table.use block @a[distance=..12] ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use block @a[distance=..12] ~ ~ ~ 0.8 1.4
title @a[distance=..6] actionbar [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Cuchillo de Supernova", "color": "#3fbf8f", "italic": false}]
return 1
