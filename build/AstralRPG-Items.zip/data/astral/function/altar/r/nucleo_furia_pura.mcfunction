execute unless entity @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_nucleo_furia_4] run return 0
execute unless entity @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/v_blaze_powder_4] run return 0
execute unless entity @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/v_lava_bucket_1] run return 0
execute as @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_nucleo_furia_4,limit=1,sort=nearest] run item modify entity @s contents astral:sub/4
execute as @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/v_blaze_powder_4,limit=1,sort=nearest] run item modify entity @s contents astral:sub/4
execute as @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/v_lava_bucket_1,limit=1,sort=nearest] run item modify entity @s contents astral:sub/1
summon minecraft:item ~ ~0.3 ~ {Item:{id:"minecraft:bucket",count:1}}
loot spawn ~ ~0.3 ~ loot astral:item/nucleo_furia_pura
particle minecraft:enchant ~ ~0.5 ~ 0.3 0.3 0.3 1 40
particle minecraft:end_rod ~ ~0.5 ~ 0.2 0.2 0.2 0.02 12
playsound minecraft:block.smithing_table.use block @a[distance=..12] ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use block @a[distance=..12] ~ ~ ~ 0.8 1.4
title @a[distance=..6] actionbar [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Nucleo de Furia Pura", "color": "#ff1a1a", "italic": false}]
return 1
