execute unless entity @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_taladro_amatista_1] run return 0
execute unless entity @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_nucleo_furia_2] run return 0
execute unless entity @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_shadowsteel_2] run return 0
execute unless entity @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/v_redstone_block_8] run return 0
execute as @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_taladro_amatista_1,limit=1,sort=nearest] run function astral:forge/ipl/taladro_rubi/taladro_amatista {slot:"contents"}
execute as @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_nucleo_furia_2,limit=1,sort=nearest] run item modify entity @s contents astral:sub/2
execute as @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_shadowsteel_2,limit=1,sort=nearest] run item modify entity @s contents astral:sub/2
execute as @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/v_redstone_block_8,limit=1,sort=nearest] run item modify entity @s contents astral:sub/8
particle minecraft:enchant ~ ~0.5 ~ 0.3 0.3 0.3 1 40
particle minecraft:end_rod ~ ~0.5 ~ 0.2 0.2 0.2 0.02 12
playsound minecraft:block.smithing_table.use block @a[distance=..12] ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use block @a[distance=..12] ~ ~ ~ 0.8 1.4
title @a[distance=..6] actionbar [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Taladro de Rubi", "color": "#ff4b4b", "italic": false}]
return 1
