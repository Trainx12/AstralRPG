execute unless entity @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_lanza_4_1] run return 0
execute unless entity @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_chispa_astral_1] run return 0
execute unless entity @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_nucleo_astral_1] run return 0
execute as @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_lanza_4_1,limit=1,sort=nearest] run function astral:forge/ipl/lanza_5/lanza_4 {slot:"contents"}
execute as @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_chispa_astral_1,limit=1,sort=nearest] run item modify entity @s contents astral:sub/1
execute as @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_nucleo_astral_1,limit=1,sort=nearest] run item modify entity @s contents astral:sub/1
function astral:quest/event/forge5
particle minecraft:enchant ~ ~0.5 ~ 0.3 0.3 0.3 1 40
particle minecraft:end_rod ~ ~0.5 ~ 0.2 0.2 0.2 0.02 12
playsound minecraft:block.smithing_table.use block @a[distance=..12] ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use block @a[distance=..12] ~ ~ ~ 0.8 1.4
title @a[distance=..6] actionbar [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Lanza Astral", "color": "#ffb347", "italic": false}]
return 1
