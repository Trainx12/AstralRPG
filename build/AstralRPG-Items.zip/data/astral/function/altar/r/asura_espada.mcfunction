execute unless entity @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_asura_moneda_emerald_32] run return 0
execute unless entity @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_asura_moneda_card_2] run return 0
execute unless entity @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_asura_moneda_circle_2] run return 0
execute unless entity @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_asura_moneda_square_2] run return 0
execute unless entity @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_asura_moneda_triangle_2] run return 0
execute unless entity @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_netherita_reforzada_3] run return 0
execute unless entity @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_gema_umbria_2] run return 0
execute as @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_asura_moneda_emerald_32,limit=1,sort=nearest] run item modify entity @s contents astral:sub/32
execute as @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_asura_moneda_card_2,limit=1,sort=nearest] run item modify entity @s contents astral:sub/2
execute as @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_asura_moneda_circle_2,limit=1,sort=nearest] run item modify entity @s contents astral:sub/2
execute as @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_asura_moneda_square_2,limit=1,sort=nearest] run item modify entity @s contents astral:sub/2
execute as @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_asura_moneda_triangle_2,limit=1,sort=nearest] run item modify entity @s contents astral:sub/2
execute as @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_netherita_reforzada_3,limit=1,sort=nearest] run item modify entity @s contents astral:sub/3
execute as @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_gema_umbria_2,limit=1,sort=nearest] run item modify entity @s contents astral:sub/2
loot spawn ~ ~0.3 ~ loot astral:item/asura_espada
particle minecraft:enchant ~ ~0.5 ~ 0.3 0.3 0.3 1 40
particle minecraft:end_rod ~ ~0.5 ~ 0.2 0.2 0.2 0.02 12
playsound minecraft:block.smithing_table.use block @a[distance=..12] ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use block @a[distance=..12] ~ ~ ~ 0.8 1.4
title @a[distance=..6] actionbar [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Espada Asura", "color": "#ff4d4d", "italic": false}]
return 1
