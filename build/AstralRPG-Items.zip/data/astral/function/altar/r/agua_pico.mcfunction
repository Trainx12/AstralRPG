execute unless entity @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_perla_abisal_6] run return 0
execute unless entity @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_coral_astral_2] run return 0
execute unless entity @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_netherita_reforzada_1] run return 0
execute as @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_perla_abisal_6,limit=1,sort=nearest] run item modify entity @s contents astral:sub/6
execute as @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_coral_astral_2,limit=1,sort=nearest] run item modify entity @s contents astral:sub/2
execute as @e[type=minecraft:item,distance=..1.2,predicate=astral:ing/c_netherita_reforzada_1,limit=1,sort=nearest] run item modify entity @s contents astral:sub/1
loot spawn ~ ~0.3 ~ loot astral:item/agua_pico
particle minecraft:enchant ~ ~0.5 ~ 0.3 0.3 0.3 1 40
particle minecraft:end_rod ~ ~0.5 ~ 0.2 0.2 0.2 0.02 12
playsound minecraft:block.smithing_table.use block @a[distance=..12] ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use block @a[distance=..12] ~ ~ ~ 0.8 1.4
title @a[distance=..6] actionbar [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Pico de las Mareas", "color": "#4fd8e8", "italic": false}]
return 1
