# Cada jugador agachado busca items arriba de una mesa de herreria cercana
execute as @a[gamemode=!spectator,predicate=astral:sneaking] at @s as @e[type=minecraft:item,distance=..4] at @s if block ~ ~-0.2 ~ minecraft:smithing_table positioned ~ ~-0.2 ~ align xyz positioned ~0.5 ~1 ~0.5 run function astral:altar/try
