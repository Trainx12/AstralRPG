tag @s add astral.seen
execute unless entity @a[distance=..64,gamemode=!spectator] run return 0
scoreboard players operation #a astral.tmp = @p[distance=..64,gamemode=!spectator] astral.lvl
execute store result score #day astral.tmp run time query day
scoreboard players operation #day astral.tmp /= #7 astral.const
execute if score #day astral.tmp matches 4.. run scoreboard players set #day astral.tmp 3
scoreboard players operation #a astral.tmp += #day astral.tmp
# probabilidad = 6% + 5% por nivel de amenaza
scoreboard players operation #c astral.tmp = #a astral.tmp
scoreboard players operation #c astral.tmp *= #5 astral.const
scoreboard players add #c astral.tmp 6
execute store result score #r astral.tmp run random value 1..100
execute if score #r astral.tmp > #c astral.tmp run return 0
# tier = 1 + azar(0..amenaza)/2, maximo 5
execute store result storage astral:tmp elite.max int 1 run scoreboard players get #a astral.tmp
function astral:elite/rand with storage astral:tmp elite
scoreboard players operation #t astral.tmp /= #2 astral.const
scoreboard players add #t astral.tmp 1
execute if score #t astral.tmp matches 6.. run scoreboard players set #t astral.tmp 5
execute if score #t astral.tmp matches 1 run return run function astral:elite/t1
execute if score #t astral.tmp matches 2 run return run function astral:elite/t2
execute if score #t astral.tmp matches 3 run return run function astral:elite/t3
execute if score #t astral.tmp matches 4 run return run function astral:elite/t4
execute if score #t astral.tmp matches 5 run return run function astral:elite/t5
