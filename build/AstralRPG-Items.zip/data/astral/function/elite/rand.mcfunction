$execute store result score #t astral.tmp run random value 0..$(max)
