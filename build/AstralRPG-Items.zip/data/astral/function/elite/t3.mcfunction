tag @s add astral.elite
tag @s add astral.elite3
attribute @s minecraft:max_health modifier add astral:elite 1.6 add_multiplied_base
attribute @s minecraft:attack_damage modifier add astral:elite 0.5 add_multiplied_base
attribute @s minecraft:movement_speed modifier add astral:elite 0.12 add_multiplied_base
attribute @s minecraft:armor modifier add astral:elite 6 add_value
attribute @s minecraft:knockback_resistance modifier add astral:elite 0.3 add_value
attribute @s minecraft:follow_range modifier add astral:elite 0.5 add_multiplied_base
data modify entity @s Health set value 1024.0f
# sin PersistenceRequired: los elites desaparecen como cualquier mob (si no, se acumulan)
data modify entity @s CustomName set value {text:"[III] Campeon",color:"#c070ff",bold:false}
effect give @s minecraft:fire_resistance infinite 0 true
particle minecraft:totem_of_undying ~ ~1 ~ 0.4 0.6 0.4 0.2 30
