tag @s add astral.elite
tag @s add astral.elite4
attribute @s minecraft:max_health modifier add astral:elite 2.6 add_multiplied_base
attribute @s minecraft:attack_damage modifier add astral:elite 0.75 add_multiplied_base
attribute @s minecraft:movement_speed modifier add astral:elite 0.15 add_multiplied_base
attribute @s minecraft:armor modifier add astral:elite 9 add_value
attribute @s minecraft:knockback_resistance modifier add astral:elite 0.5 add_value
attribute @s minecraft:follow_range modifier add astral:elite 0.5 add_multiplied_base
data modify entity @s Health set value 1024.0f
data modify entity @s PersistenceRequired set value 1b
data modify entity @s CustomName set value {text:"[IV] Pesadilla",color:"#ff4d4d",bold:true}
effect give @s minecraft:fire_resistance infinite 0 true
effect give @s minecraft:resistance infinite 0 true
particle minecraft:totem_of_undying ~ ~1 ~ 0.4 0.6 0.4 0.2 40
