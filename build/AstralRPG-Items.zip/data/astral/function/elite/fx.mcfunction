# elites viejos que quedaron persistentes: liberarlos una vez para que puedan desaparecer
execute as @e[tag=astral.elite,tag=!astral.libre] run data modify entity @s PersistenceRequired set value 0b
tag @e[tag=astral.elite,tag=!astral.libre] add astral.libre
execute as @e[tag=astral.elite4] at @s run particle minecraft:flame ~ ~1 ~ 0.3 0.5 0.3 0.01 3
execute as @e[tag=astral.elite5] at @s run particle minecraft:end_rod ~ ~1 ~ 0.3 0.5 0.3 0.02 4
