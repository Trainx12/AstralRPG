tag @s add astral.elite
tag @s add astral.elite1
attribute @s minecraft:max_health modifier add astral:elite 0.4 add_multiplied_base
attribute @s minecraft:attack_damage modifier add astral:elite 0.15 add_multiplied_base
attribute @s minecraft:movement_speed modifier add astral:elite 0.05 add_multiplied_base
attribute @s minecraft:armor modifier add astral:elite 2 add_value
attribute @s minecraft:knockback_resistance modifier add astral:elite 0.1 add_value
attribute @s minecraft:follow_range modifier add astral:elite 0.5 add_multiplied_base
data modify entity @s Health set value 1024.0f
# sin PersistenceRequired: los elites desaparecen como cualquier mob (si no, se acumulan)
data modify entity @s CustomName set value {text:"[I] Veterano",color:"#9fe870",bold:false}
particle minecraft:totem_of_undying ~ ~1 ~ 0.4 0.6 0.4 0.2 10
