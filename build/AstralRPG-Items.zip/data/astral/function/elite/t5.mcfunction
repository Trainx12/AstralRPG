tag @s add astral.elite
tag @s add astral.elite5
attribute @s minecraft:max_health modifier add astral:elite 4.0 add_multiplied_total
attribute @s minecraft:attack_damage modifier add astral:elite 1.1 add_multiplied_total
attribute @s minecraft:movement_speed modifier add astral:elite 0.18 add_multiplied_base
attribute @s minecraft:armor modifier add astral:elite 12 add_value
attribute @s minecraft:knockback_resistance modifier add astral:elite 0.7 add_value
attribute @s minecraft:follow_range modifier add astral:elite 0.5 add_multiplied_base
# sin PersistenceRequired: los elites desaparecen como cualquier mob (si no, se acumulan)
effect give @s minecraft:fire_resistance infinite 0 true
effect give @s minecraft:resistance infinite 0 true
effect give @s minecraft:regeneration infinite 0 true
particle minecraft:totem_of_undying ~ ~1 ~ 0.4 0.6 0.4 0.2 50
