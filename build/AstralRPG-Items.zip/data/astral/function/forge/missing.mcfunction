$tellraw @s [{"text": "Te falta: ", "color": "red", "italic": false}, {"text": "$(need)", "color": "gold", "italic": false}]
playsound minecraft:entity.villager.no player @s ~ ~ ~ 0.7 1
return 0
