tellraw @s [{"text": "Te falta: ", "color": "red", "italic": false}, {"nbt": "forge.missing[]", "storage": "astral:tmp", "separator": {"text": ", ", "color": "red", "italic": false}, "color": "gold", "italic": false}]
playsound minecraft:entity.villager.no player @s ~ ~ ~ 0.7 1
return 0
