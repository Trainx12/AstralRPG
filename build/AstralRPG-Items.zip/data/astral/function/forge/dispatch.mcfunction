$function astral:forge/r/$(id)
