execute store result storage astral:tmp forge.id int 1 run scoreboard players get @s astral.forja
scoreboard players reset @s astral.forja
execute unless function astral:forge/near run return run tellraw @s [{"text": "Tenes que estar al lado de una ", "color": "red", "italic": false}, {"text": "Mesa de Herreria", "color": "gold", "italic": false}, {"text": " para forjar.", "color": "red", "italic": false}]
function astral:forge/dispatch with storage astral:tmp forge
