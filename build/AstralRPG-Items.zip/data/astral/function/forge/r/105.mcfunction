data modify storage astral:tmp forge.missing set value []
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"cristal_refinado"}}] 0
execute if score #h astral.tmp matches ..1 run data modify storage astral:tmp forge.missing append value "2x Cristal Arcano Refinado"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"gema_luminica"}}] 0
execute if score #h astral.tmp matches ..0 run data modify storage astral:tmp forge.missing append value "1x Gema Luminica"
execute store result score #h astral.tmp run clear @s minecraft:ghast_tear[!minecraft:custom_data] 0
execute if score #h astral.tmp matches ..1 run data modify storage astral:tmp forge.missing append value "2x ghast tear"
execute if data storage astral:tmp forge.missing[0] run return run function astral:forge/missing
clear @s *[minecraft:custom_data~{astral:{id:"cristal_refinado"}}] 2
clear @s *[minecraft:custom_data~{astral:{id:"gema_luminica"}}] 1
clear @s minecraft:ghast_tear[!minecraft:custom_data] 2
loot give @s loot astral:item/varita_curacion
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Varita de Curaci\u00f3n", "color": "#7dff9a", "italic": false}]
return 1
