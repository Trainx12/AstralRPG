data modify storage astral:tmp forge.missing set value []
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"taladro_diamante"}}] 0
execute if score #h astral.tmp matches ..0 run data modify storage astral:tmp forge.missing append value "1x Taladro de Diamante"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"netherita_reforzada"}}] 0
execute if score #h astral.tmp matches ..1 run data modify storage astral:tmp forge.missing append value "2x Netherita Reforzada"
execute store result score #h astral.tmp run clear @s minecraft:prismarine_crystals[!minecraft:custom_data] 0
execute if score #h astral.tmp matches ..7 run data modify storage astral:tmp forge.missing append value "8x Cristales de prismarina"
execute store result score #h astral.tmp run clear @s minecraft:diamond_block[!minecraft:custom_data] 0
execute if score #h astral.tmp matches ..1 run data modify storage astral:tmp forge.missing append value "2x Bloque de diamante"
execute if data storage astral:tmp forge.missing[0] run return run function astral:forge/missing
clear @s *[minecraft:custom_data~{astral:{id:"taladro_diamante"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"netherita_reforzada"}}] 2
clear @s minecraft:prismarine_crystals[!minecraft:custom_data] 8
clear @s minecraft:diamond_block[!minecraft:custom_data] 2
loot give @s loot astral:item/taladro_mitril
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Taladro de Mitril", "color": "#3fe0c5", "italic": false}]
return 1
