data modify storage astral:tmp forge.missing set value []
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"taladro_topacio"}}] 0
execute if score #h astral.tmp matches ..0 run data modify storage astral:tmp forge.missing append value "1x Taladro de Topacio"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"cristal_refinado"}}] 0
execute if score #h astral.tmp matches ..1 run data modify storage astral:tmp forge.missing append value "2x Cristal Arcano Refinado"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"shadowsteel"}}] 0
execute if score #h astral.tmp matches ..3 run data modify storage astral:tmp forge.missing append value "4x Acero Sombrio"
execute store result score #h astral.tmp run clear @s minecraft:netherite_ingot[!minecraft:custom_data] 0
execute if score #h astral.tmp matches ..1 run data modify storage astral:tmp forge.missing append value "2x Lingote de netherita"
execute if data storage astral:tmp forge.missing[0] run return run function astral:forge/missing
clear @s *[minecraft:custom_data~{astral:{id:"taladro_topacio"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"cristal_refinado"}}] 2
clear @s *[minecraft:custom_data~{astral:{id:"shadowsteel"}}] 4
clear @s minecraft:netherite_ingot[!minecraft:custom_data] 2
loot give @s loot astral:item/taladro_titanio
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Taladro de Titanio", "color": "#a9b8d8", "italic": false}]
return 1
