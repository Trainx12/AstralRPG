data modify storage astral:tmp forge.missing set value []
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"gema_umbria_fragmentada"}}] 0
execute if score #h astral.tmp matches ..1 run data modify storage astral:tmp forge.missing append value "2x Gema Umbria Fragmentada"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"shadowsteel"}}] 0
execute if score #h astral.tmp matches ..0 run data modify storage astral:tmp forge.missing append value "1x Acero Sombrio"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"palo_reforzado"}}] 0
execute if score #h astral.tmp matches ..0 run data modify storage astral:tmp forge.missing append value "1x Palo Reforzado"
execute if data storage astral:tmp forge.missing[0] run return run function astral:forge/missing
clear @s *[minecraft:custom_data~{astral:{id:"gema_umbria_fragmentada"}}] 2
clear @s *[minecraft:custom_data~{astral:{id:"shadowsteel"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"palo_reforzado"}}] 1
loot give @s loot astral:item/guadana_1
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Guadana Umbria Menor", "color": "#b26bff", "italic": false}]
return 1
