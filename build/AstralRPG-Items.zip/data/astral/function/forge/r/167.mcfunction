data modify storage astral:tmp forge.missing set value []
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"cuero_tratado"}}] 0
execute if score #h astral.tmp matches ..2 run data modify storage astral:tmp forge.missing append value "3x Cuero Tratado"
execute store result score #h astral.tmp run clear @s minecraft:copper_ingot[!minecraft:custom_data] 0
execute if score #h astral.tmp matches ..3 run data modify storage astral:tmp forge.missing append value "4x copper ingot"
execute if data storage astral:tmp forge.missing[0] run return run function astral:forge/missing
clear @s *[minecraft:custom_data~{astral:{id:"cuero_tratado"}}] 3
clear @s minecraft:copper_ingot[!minecraft:custom_data] 4
loot give @s loot astral:item/minero_leggings
function astral:quest/event/forge1
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Pantalon de Minero", "color": "#e0a83a", "italic": false}]
return 1
