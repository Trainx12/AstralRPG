execute store result score #h astral.tmp run clear @s minecraft:leather_boots[!minecraft:custom_data] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Botas de cuero"}
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"cuero_tratado"}}] 0
execute if score #h astral.tmp matches ..2 run return run function astral:forge/missing {need:"3x Cuero Tratado"}
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"fragmento_cristal"}}] 0
execute if score #h astral.tmp matches ..1 run return run function astral:forge/missing {need:"2x Fragmento de Cristal Arcano"}
clear @s minecraft:leather_boots[!minecraft:custom_data] 1
clear @s *[minecraft:custom_data~{astral:{id:"cuero_tratado"}}] 3
clear @s *[minecraft:custom_data~{astral:{id:"fragmento_cristal"}}] 2
loot give @s loot astral:item/mago_1_boots
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Sandalias del Aprendiz", "color": "#b26bff", "italic": false}]
return 1
