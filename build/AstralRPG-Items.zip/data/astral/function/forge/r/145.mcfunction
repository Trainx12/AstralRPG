data modify storage astral:tmp forge.missing set value []
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"colmillo_carnivoro"}}] 0
execute if score #h astral.tmp matches ..7 run data modify storage astral:tmp forge.missing append value "8x Colmillo Carnivoro"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"shadowsteel"}}] 0
execute if score #h astral.tmp matches ..3 run data modify storage astral:tmp forge.missing append value "4x Acero Sombrio"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"netherita_reforzada"}}] 0
execute if score #h astral.tmp matches ..0 run data modify storage astral:tmp forge.missing append value "1x Netherita Reforzada"
execute if data storage astral:tmp forge.missing[0] run return run function astral:forge/missing
clear @s *[minecraft:custom_data~{astral:{id:"colmillo_carnivoro"}}] 8
clear @s *[minecraft:custom_data~{astral:{id:"shadowsteel"}}] 4
clear @s *[minecraft:custom_data~{astral:{id:"netherita_reforzada"}}] 1
loot give @s loot astral:item/carnivora_lanza
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Lanza Carnivora", "color": "#ffb347", "italic": false}]
return 1
