execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"cristal_arcano"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Cristal Arcano"}
clear @s *[minecraft:custom_data~{astral:{id:"cristal_arcano"}}] 1
loot give @s loot astral:item/fragmento_cristal
loot give @s loot astral:item/fragmento_cristal
loot give @s loot astral:item/fragmento_cristal
loot give @s loot astral:item/fragmento_cristal
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Fragmento de Cristal Arcano x4", "color": "#c9a6ff", "italic": false}]
return 1
