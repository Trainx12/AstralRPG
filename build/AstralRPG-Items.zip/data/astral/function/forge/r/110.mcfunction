data modify storage astral:tmp forge.missing set value []
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"taladro_titanio"}}] 0
execute if score #h astral.tmp matches ..0 run data modify storage astral:tmp forge.missing append value "1x Taladro de Titanio"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"gema_umbria"}}] 0
execute if score #h astral.tmp matches ..1 run data modify storage astral:tmp forge.missing append value "2x Gema Umbria"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"nucleo_furia_pura"}}] 0
execute if score #h astral.tmp matches ..0 run data modify storage astral:tmp forge.missing append value "1x Nucleo de Furia Pura"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"alma_corrupta"}}] 0
execute if score #h astral.tmp matches ..1 run data modify storage astral:tmp forge.missing append value "2x Alma Corrupta"
execute if data storage astral:tmp forge.missing[0] run return run function astral:forge/missing
clear @s *[minecraft:custom_data~{astral:{id:"taladro_titanio"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"gema_umbria"}}] 2
clear @s *[minecraft:custom_data~{astral:{id:"nucleo_furia_pura"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"alma_corrupta"}}] 2
loot give @s loot astral:item/taladro_jaspe
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Taladro de Jaspe", "color": "#ff5fa8", "italic": false}]
return 1
