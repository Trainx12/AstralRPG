data modify storage astral:tmp forge.missing set value []
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"hacha_4"}}] 0
execute if score #h astral.tmp matches ..0 run data modify storage astral:tmp forge.missing append value "1x Hacha del Coloso"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"netherita_reforzada"}}] 0
execute if score #h astral.tmp matches ..1 run data modify storage astral:tmp forge.missing append value "2x Netherita Reforzada"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"nucleo_furia_pura"}}] 0
execute if score #h astral.tmp matches ..0 run data modify storage astral:tmp forge.missing append value "1x Nucleo de Furia Pura"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"palo_reforzado"}}] 0
execute if score #h astral.tmp matches ..0 run data modify storage astral:tmp forge.missing append value "1x Palo Reforzado"
execute if data storage astral:tmp forge.missing[0] run return run function astral:forge/missing
clear @s *[minecraft:custom_data~{astral:{id:"hacha_4"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"netherita_reforzada"}}] 2
clear @s *[minecraft:custom_data~{astral:{id:"nucleo_furia_pura"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"palo_reforzado"}}] 1
loot give @s loot astral:item/hacha_5
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Hacha del Apocalipsis", "color": "#ff4d4d", "italic": false}]
return 1
