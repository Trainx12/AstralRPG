data modify storage astral:tmp forge.missing set value []
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"arco_7"}}] 0
execute if score #h astral.tmp matches ..0 run data modify storage astral:tmp forge.missing append value "1x Arco del Vendaval Dorado"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"nucleo_supernova"}}] 0
execute if score #h astral.tmp matches ..3 run data modify storage astral:tmp forge.missing append value "4x Nucleo de Supernova"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"esquirla_eclipse"}}] 0
execute if score #h astral.tmp matches ..1 run data modify storage astral:tmp forge.missing append value "2x Esquirla de Eclipse"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"gema_luminica_perfecta"}}] 0
execute if score #h astral.tmp matches ..1 run data modify storage astral:tmp forge.missing append value "2x Gema Luminica Perfecta"
execute if data storage astral:tmp forge.missing[0] run return run function astral:forge/missing
clear @s *[minecraft:custom_data~{astral:{id:"arco_7"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"nucleo_supernova"}}] 4
clear @s *[minecraft:custom_data~{astral:{id:"esquirla_eclipse"}}] 2
clear @s *[minecraft:custom_data~{astral:{id:"gema_luminica_perfecta"}}] 2
loot give @s loot astral:item/arco_8
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Arco Enredadera del Eco", "color": "#5ee08a", "italic": false}]
return 1
