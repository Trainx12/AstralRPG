execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"arco_2"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Arco del Explorador"}
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"cristal_refinado"}}] 0
execute if score #h astral.tmp matches ..2 run return run function astral:forge/missing {need:"3x Cristal Arcano Refinado"}
clear @s *[minecraft:custom_data~{astral:{id:"arco_2"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"cristal_refinado"}}] 3
loot give @s loot astral:item/arco_3
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Arco del Francotirador", "color": "#5ee08a", "italic": false}]
return 1
