execute store result score #h astral.tmp run clear @s minecraft:leather[!minecraft:custom_data] 0
execute if score #h astral.tmp matches ..7 run return run function astral:forge/missing {need:"8x Cuero"}
execute store result score #h astral.tmp run clear @s minecraft:potion[minecraft:potion_contents={potion:"minecraft:water"}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Botella de agua"}
clear @s minecraft:leather[!minecraft:custom_data] 8
clear @s minecraft:potion[minecraft:potion_contents={potion:"minecraft:water"}] 1
loot give @s loot astral:item/cuero_tratado
loot give @s loot astral:item/cuero_tratado
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Cuero Tratado x2", "color": "#c58b52", "italic": false}]
return 1
