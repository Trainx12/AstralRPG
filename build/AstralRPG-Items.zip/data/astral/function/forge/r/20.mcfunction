execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"berserker_1_helmet"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Yelmo del Saqueador"}
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"shadowsteel"}}] 0
execute if score #h astral.tmp matches ..2 run return run function astral:forge/missing {need:"3x Acero Sombrio"}
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"netherita_fundida"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Netherita Fundida"}
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"esencia_nether"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Esencia del Nether"}
clear @s *[minecraft:custom_data~{astral:{id:"berserker_1_helmet"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"shadowsteel"}}] 3
clear @s *[minecraft:custom_data~{astral:{id:"netherita_fundida"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"esencia_nether"}}] 1
loot give @s loot astral:item/berserker_2_helmet
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Yelmo del Carnicero", "color": "#ff4d4d", "italic": false}]
return 1
