data modify storage astral:tmp forge.missing set value []
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"shadowsteel"}}] 0
execute if score #h astral.tmp matches ..4 run data modify storage astral:tmp forge.missing append value "5x Acero Sombrio"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"gema_umbria"}}] 0
execute if score #h astral.tmp matches ..2 run data modify storage astral:tmp forge.missing append value "3x Gema Umbria"
execute store result score #h astral.tmp run clear @s minecraft:ender_pearl[!minecraft:custom_data] 0
execute if score #h astral.tmp matches ..7 run data modify storage astral:tmp forge.missing append value "8x ender pearl"
execute if data storage astral:tmp forge.missing[0] run return run function astral:forge/missing
clear @s *[minecraft:custom_data~{astral:{id:"shadowsteel"}}] 5
clear @s *[minecraft:custom_data~{astral:{id:"gema_umbria"}}] 3
clear @s minecraft:ender_pearl[!minecraft:custom_data] 8
loot give @s loot astral:item/espada_sombras
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Danza del Ender", "color": "#b174ff", "italic": false}]
return 1
