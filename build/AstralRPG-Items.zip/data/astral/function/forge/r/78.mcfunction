execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"espada_2"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Espada del Carnicero"}
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"shadowsteel"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Acero Sombrio"}
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"netherita_reforzada"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Netherita Reforzada"}
clear @s *[minecraft:custom_data~{astral:{id:"espada_2"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"shadowsteel"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"netherita_reforzada"}}] 1
loot give @s loot astral:item/espada_3
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Espada Ensangrentada", "color": "#ff4d4d", "italic": false}]
return 1
