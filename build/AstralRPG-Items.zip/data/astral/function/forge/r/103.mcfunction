execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"shadowsteel"}}] 0
execute if score #h astral.tmp matches ..3 run return run function astral:forge/missing {need:"4x Acero Sombrio"}
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"netherita_reforzada"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Netherita Reforzada"}
execute store result score #h astral.tmp run clear @s minecraft:redstone_block[!minecraft:custom_data] 0
execute if score #h astral.tmp matches ..1 run return run function astral:forge/missing {need:"2x Bloque de redstone"}
execute store result score #h astral.tmp run clear @s minecraft:blaze_rod[!minecraft:custom_data] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Vara de blaze"}
clear @s *[minecraft:custom_data~{astral:{id:"shadowsteel"}}] 4
clear @s *[minecraft:custom_data~{astral:{id:"netherita_reforzada"}}] 1
clear @s minecraft:redstone_block[!minecraft:custom_data] 2
clear @s minecraft:blaze_rod[!minecraft:custom_data] 1
loot give @s loot astral:item/taladro_infernal
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Taladro Infernal", "color": "#ff5a1f", "italic": false}]
return 1
