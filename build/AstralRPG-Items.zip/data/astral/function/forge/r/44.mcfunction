data modify storage astral:tmp forge.missing set value []
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"mago_2_helmet"}}] 0
execute if score #h astral.tmp matches ..0 run data modify storage astral:tmp forge.missing append value "1x Capucha del Hechicero"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"cristal_refinado"}}] 0
execute if score #h astral.tmp matches ..1 run data modify storage astral:tmp forge.missing append value "2x Cristal Arcano Refinado"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"madera_estelar"}}] 0
execute if score #h astral.tmp matches ..0 run data modify storage astral:tmp forge.missing append value "1x Madera Estelar"
execute if data storage astral:tmp forge.missing[0] run return run function astral:forge/missing
clear @s *[minecraft:custom_data~{astral:{id:"mago_2_helmet"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"cristal_refinado"}}] 2
clear @s *[minecraft:custom_data~{astral:{id:"madera_estelar"}}] 1
loot give @s loot astral:item/mago_3_helmet
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Capucha del Invocador", "color": "#b26bff", "italic": false}]
return 1
