data modify storage astral:tmp forge.missing set value []
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"taladro_mitril"}}] 0
execute if score #h astral.tmp matches ..0 run data modify storage astral:tmp forge.missing append value "1x Taladro de Mitril"
execute store result score #h astral.tmp run clear @s minecraft:amethyst_block[!minecraft:custom_data] 0
execute if score #h astral.tmp matches ..7 run data modify storage astral:tmp forge.missing append value "8x Bloque de amatista"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"fragmento_cristal"}}] 0
execute if score #h astral.tmp matches ..3 run data modify storage astral:tmp forge.missing append value "4x Fragmento de Cristal Arcano"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"netherita_reforzada"}}] 0
execute if score #h astral.tmp matches ..2 run data modify storage astral:tmp forge.missing append value "3x Netherita Reforzada"
execute if data storage astral:tmp forge.missing[0] run return run function astral:forge/missing
clear @s *[minecraft:custom_data~{astral:{id:"taladro_mitril"}}] 1
clear @s minecraft:amethyst_block[!minecraft:custom_data] 8
clear @s *[minecraft:custom_data~{astral:{id:"fragmento_cristal"}}] 4
clear @s *[minecraft:custom_data~{astral:{id:"netherita_reforzada"}}] 3
loot give @s loot astral:item/taladro_amatista
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Taladro de Amatista", "color": "#e070ff", "italic": false}]
return 1
