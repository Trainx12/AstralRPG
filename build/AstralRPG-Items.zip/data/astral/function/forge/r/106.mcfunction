data modify storage astral:tmp forge.missing set value []
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"palo_reforzado"}}] 0
execute if score #h astral.tmp matches ..0 run data modify storage astral:tmp forge.missing append value "1x Palo Reforzado"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"cristal_arcano"}}] 0
execute if score #h astral.tmp matches ..2 run data modify storage astral:tmp forge.missing append value "3x Cristal Arcano"
execute store result score #h astral.tmp run clear @s minecraft:blaze_powder[!minecraft:custom_data] 0
execute if score #h astral.tmp matches ..7 run data modify storage astral:tmp forge.missing append value "8x Polvo de blaze"
execute if data storage astral:tmp forge.missing[0] run return run function astral:forge/missing
clear @s *[minecraft:custom_data~{astral:{id:"palo_reforzado"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"cristal_arcano"}}] 3
clear @s minecraft:blaze_powder[!minecraft:custom_data] 8
loot give @s loot astral:item/varita_estallido
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Varita del Estallido", "color": "#ff8673", "italic": false}]
return 1
