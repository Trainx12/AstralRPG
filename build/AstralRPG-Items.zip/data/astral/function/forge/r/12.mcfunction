data modify storage astral:tmp forge.missing set value []
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"polvo_astral"}}] 0
execute if score #h astral.tmp matches ..3 run data modify storage astral:tmp forge.missing append value "4x Polvo Astral"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"cristal_refinado"}}] 0
execute if score #h astral.tmp matches ..3 run data modify storage astral:tmp forge.missing append value "4x Cristal Arcano Refinado"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"corazon_shulker"}}] 0
execute if score #h astral.tmp matches ..0 run data modify storage astral:tmp forge.missing append value "1x Corazon de Shulker"
execute if data storage astral:tmp forge.missing[0] run return run function astral:forge/missing
clear @s *[minecraft:custom_data~{astral:{id:"polvo_astral"}}] 4
clear @s *[minecraft:custom_data~{astral:{id:"cristal_refinado"}}] 4
clear @s *[minecraft:custom_data~{astral:{id:"corazon_shulker"}}] 1
loot give @s loot astral:item/nucleo_astral
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Nucleo Astral", "color": "#4fd1ff", "italic": false}]
return 1
