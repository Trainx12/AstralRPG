execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"lanza_2"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Lanza del Centinela"}
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"alma_corrupta"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Alma Corrupta"}
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"netherita_reforzada"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Netherita Reforzada"}
clear @s *[minecraft:custom_data~{astral:{id:"lanza_2"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"alma_corrupta"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"netherita_reforzada"}}] 1
loot give @s loot astral:item/lanza_3
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Lanza Carmesi", "color": "#ffb347", "italic": false}]
return 1
