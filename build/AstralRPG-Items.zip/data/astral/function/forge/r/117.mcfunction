execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"lanza_1"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Lanza del Recluta"}
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"esencia_elite"}}] 0
execute if score #h astral.tmp matches ..2 run return run function astral:forge/missing {need:"3x Esencia de Elite"}
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"shadowsteel"}}] 0
execute if score #h astral.tmp matches ..1 run return run function astral:forge/missing {need:"2x Acero Sombrio"}
clear @s *[minecraft:custom_data~{astral:{id:"lanza_1"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"esencia_elite"}}] 3
clear @s *[minecraft:custom_data~{astral:{id:"shadowsteel"}}] 2
loot give @s loot astral:item/lanza_2
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Lanza del Centinela", "color": "#ffb347", "italic": false}]
return 1
