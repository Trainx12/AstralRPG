data modify storage astral:tmp forge.missing set value []
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"espada_4"}}] 0
execute if score #h astral.tmp matches ..0 run data modify storage astral:tmp forge.missing append value "1x Espada del Coloso"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"netherita_reforzada"}}] 0
execute if score #h astral.tmp matches ..0 run data modify storage astral:tmp forge.missing append value "1x Netherita Reforzada"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"nucleo_furia_pura"}}] 0
execute if score #h astral.tmp matches ..0 run data modify storage astral:tmp forge.missing append value "1x Nucleo de Furia Pura"
execute if data storage astral:tmp forge.missing[0] run return run function astral:forge/missing
clear @s *[minecraft:custom_data~{astral:{id:"espada_4"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"netherita_reforzada"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"nucleo_furia_pura"}}] 1
loot give @s loot astral:item/espada_5
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Espada del Dios de la Guerra", "color": "#ff4d4d", "italic": false}]
return 1
