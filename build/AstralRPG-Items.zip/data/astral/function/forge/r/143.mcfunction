data modify storage astral:tmp forge.missing set value []
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"espada_7"}}] 0
execute if score #h astral.tmp matches ..0 run data modify storage astral:tmp forge.missing append value "1x Espada del Eclipse"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"nucleo_supernova"}}] 0
execute if score #h astral.tmp matches ..3 run data modify storage astral:tmp forge.missing append value "4x Nucleo de Supernova"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"esquirla_eclipse"}}] 0
execute if score #h astral.tmp matches ..1 run data modify storage astral:tmp forge.missing append value "2x Esquirla de Eclipse"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"nucleo_furia_pura"}}] 0
execute if score #h astral.tmp matches ..1 run data modify storage astral:tmp forge.missing append value "2x Nucleo de Furia Pura"
execute if data storage astral:tmp forge.missing[0] run return run function astral:forge/missing
clear @s *[minecraft:custom_data~{astral:{id:"espada_7"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"nucleo_supernova"}}] 4
clear @s *[minecraft:custom_data~{astral:{id:"esquirla_eclipse"}}] 2
clear @s *[minecraft:custom_data~{astral:{id:"nucleo_furia_pura"}}] 2
loot give @s loot astral:item/espada_8
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Espada Supernova", "color": "#ff4d4d", "italic": false}]
return 1
