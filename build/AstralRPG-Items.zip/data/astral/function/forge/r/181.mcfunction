data modify storage astral:tmp forge.missing set value []
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"arco_5"}}] 0
execute if score #h astral.tmp matches ..0 run data modify storage astral:tmp forge.missing append value "1x Arco Astral"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"fragmento_ocaso"}}] 0
execute if score #h astral.tmp matches ..3 run data modify storage astral:tmp forge.missing append value "4x Fragmento de Ocaso"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"gema_luminica_perfecta"}}] 0
execute if score #h astral.tmp matches ..0 run data modify storage astral:tmp forge.missing append value "1x Gema Luminica Perfecta"
execute if data storage astral:tmp forge.missing[0] run return run function astral:forge/missing
clear @s *[minecraft:custom_data~{astral:{id:"arco_5"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"fragmento_ocaso"}}] 4
clear @s *[minecraft:custom_data~{astral:{id:"gema_luminica_perfecta"}}] 1
loot give @s loot astral:item/arco_6
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Arco del Ocaso", "color": "#5ee08a", "italic": false}]
return 1
