data modify storage astral:tmp forge.missing set value []
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"esencia_elite"}}] 0
execute if score #h astral.tmp matches ..2 run data modify storage astral:tmp forge.missing append value "3x Esencia de Elite"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"gema_umbria_fragmentada"}}] 0
execute if score #h astral.tmp matches ..0 run data modify storage astral:tmp forge.missing append value "1x Gema Umbria Fragmentada"
execute store result score #h astral.tmp run clear @s minecraft:feather[!minecraft:custom_data] 0
execute if score #h astral.tmp matches ..3 run data modify storage astral:tmp forge.missing append value "4x Pluma"
execute if data storage astral:tmp forge.missing[0] run return run function astral:forge/missing
clear @s *[minecraft:custom_data~{astral:{id:"esencia_elite"}}] 3
clear @s *[minecraft:custom_data~{astral:{id:"gema_umbria_fragmentada"}}] 1
clear @s minecraft:feather[!minecraft:custom_data] 4
loot give @s loot astral:item/talisman_viento_1
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Talisman del Viento I", "color": "#bff5e6", "italic": false}]
return 1
