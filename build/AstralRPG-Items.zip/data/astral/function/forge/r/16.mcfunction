execute store result score #h astral.tmp run clear @s minecraft:leather_helmet[!minecraft:custom_data] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Casco de cuero"}
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"shadowsteel"}}] 0
execute if score #h astral.tmp matches ..1 run return run function astral:forge/missing {need:"2x Acero Sombrio"}
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"cuero_tratado"}}] 0
execute if score #h astral.tmp matches ..1 run return run function astral:forge/missing {need:"2x Cuero Tratado"}
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"gema_umbria_fragmentada"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Gema Umbria Fragmentada"}
clear @s minecraft:leather_helmet[!minecraft:custom_data] 1
clear @s *[minecraft:custom_data~{astral:{id:"shadowsteel"}}] 2
clear @s *[minecraft:custom_data~{astral:{id:"cuero_tratado"}}] 2
clear @s *[minecraft:custom_data~{astral:{id:"gema_umbria_fragmentada"}}] 1
loot give @s loot astral:item/berserker_1_helmet
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Yelmo del Saqueador", "color": "#ff4d4d", "italic": false}]
return 1
