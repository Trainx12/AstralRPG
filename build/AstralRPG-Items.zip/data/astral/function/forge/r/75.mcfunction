execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"arquero_4_boots"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Botas del Viento"}
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"nucleo_astral"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Nucleo Astral"}
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"gema_luminica_perfecta"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Gema Luminica Perfecta"}
clear @s *[minecraft:custom_data~{astral:{id:"arquero_4_boots"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"nucleo_astral"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"gema_luminica_perfecta"}}] 1
loot give @s loot astral:item/arquero_5_boots
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Botas del Halcon Astral", "color": "#5ee08a", "italic": false}]
return 1
