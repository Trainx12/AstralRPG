execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"mago_3_boots"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Sandalias del Invocador"}
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"cristal_refinado"}}] 0
execute if score #h astral.tmp matches ..2 run return run function astral:forge/missing {need:"3x Cristal Arcano Refinado"}
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"corazon_shulker"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Corazon de Shulker"}
clear @s *[minecraft:custom_data~{astral:{id:"mago_3_boots"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"cristal_refinado"}}] 3
clear @s *[minecraft:custom_data~{astral:{id:"corazon_shulker"}}] 1
loot give @s loot astral:item/mago_4_boots
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Sandalias del Archimago", "color": "#b26bff", "italic": false}]
return 1
