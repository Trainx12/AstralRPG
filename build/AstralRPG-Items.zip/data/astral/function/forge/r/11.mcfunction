execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"fragmento_astral"}}] 0
execute if score #h astral.tmp matches ..7 run return run function astral:forge/missing {need:"8x Fragmento Astral"}
clear @s *[minecraft:custom_data~{astral:{id:"fragmento_astral"}}] 8
loot give @s loot astral:item/polvo_astral
loot give @s loot astral:item/polvo_astral
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Polvo Astral x2", "color": "#a8dcff", "italic": false}]
return 1
