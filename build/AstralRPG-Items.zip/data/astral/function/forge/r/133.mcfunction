data modify storage astral:tmp forge.missing set value []
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"arquero_9_chestplate"}}] 0
execute if score #h astral.tmp matches ..0 run data modify storage astral:tmp forge.missing append value "1x Chaqueta del Ojo de Tormenta"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"corazon_fin"}}] 0
execute if score #h astral.tmp matches ..3 run data modify storage astral:tmp forge.missing append value "4x Corazon del Fin"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"esencia_vacio"}}] 0
execute if score #h astral.tmp matches ..1 run data modify storage astral:tmp forge.missing append value "2x Esencia del Vacio"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"nucleo_eolico"}}] 0
execute if score #h astral.tmp matches ..3 run data modify storage astral:tmp forge.missing append value "4x Nucleo Eolico"
execute if data storage astral:tmp forge.missing[0] run return run function astral:forge/missing
clear @s *[minecraft:custom_data~{astral:{id:"arquero_9_chestplate"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"corazon_fin"}}] 4
clear @s *[minecraft:custom_data~{astral:{id:"esencia_vacio"}}] 2
clear @s *[minecraft:custom_data~{astral:{id:"nucleo_eolico"}}] 4
loot give @s loot astral:item/arquero_10_chestplate
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Chaqueta del Manto Mortal", "color": "#5ee08a", "italic": false}]
return 1
