execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"guadana_4"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Guadana del Archimago"}
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"gema_umbria_perfecta"}}] 0
execute if score #h astral.tmp matches ..1 run return run function astral:forge/missing {need:"2x Gema Umbria Perfecta"}
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"nucleo_astral"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Nucleo Astral"}
clear @s *[minecraft:custom_data~{astral:{id:"guadana_4"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"gema_umbria_perfecta"}}] 2
clear @s *[minecraft:custom_data~{astral:{id:"nucleo_astral"}}] 1
loot give @s loot astral:item/guadana_5
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Guadana Astral", "color": "#b26bff", "italic": false}]
return 1
