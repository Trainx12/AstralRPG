execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"mago_1_leggings"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Faldones del Aprendiz"}
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"cristal_refinado"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Cristal Arcano Refinado"}
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"gema_luminica"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Gema Luminica"}
clear @s *[minecraft:custom_data~{astral:{id:"mago_1_leggings"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"cristal_refinado"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"gema_luminica"}}] 1
loot give @s loot astral:item/mago_2_leggings
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Faldones del Hechicero", "color": "#b26bff", "italic": false}]
return 1
