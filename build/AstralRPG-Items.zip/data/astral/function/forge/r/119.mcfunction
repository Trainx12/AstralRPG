data modify storage astral:tmp forge.missing set value []
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"talisman_vida_1"}}] 0
execute if score #h astral.tmp matches ..0 run data modify storage astral:tmp forge.missing append value "1x Talisman de Vida I"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"alma_corrupta"}}] 0
execute if score #h astral.tmp matches ..1 run data modify storage astral:tmp forge.missing append value "2x Alma Corrupta"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"gema_luminica"}}] 0
execute if score #h astral.tmp matches ..0 run data modify storage astral:tmp forge.missing append value "1x Gema Luminica"
execute if data storage astral:tmp forge.missing[0] run return run function astral:forge/missing
clear @s *[minecraft:custom_data~{astral:{id:"talisman_vida_1"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"alma_corrupta"}}] 2
clear @s *[minecraft:custom_data~{astral:{id:"gema_luminica"}}] 1
loot give @s loot astral:item/talisman_vida_2
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Talisman de Vida II", "color": "#ff6b6b", "italic": false}]
return 1
