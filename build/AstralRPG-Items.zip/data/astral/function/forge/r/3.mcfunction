data modify storage astral:tmp forge.missing set value []
execute store result score #h astral.tmp run clear @s minecraft:iron_ingot[!minecraft:custom_data] 0
execute if score #h astral.tmp matches ..0 run data modify storage astral:tmp forge.missing append value "1x Lingote de hierro"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"esencia_nether"}}] 0
execute if score #h astral.tmp matches ..0 run data modify storage astral:tmp forge.missing append value "1x Esencia del Nether"
execute if data storage astral:tmp forge.missing[0] run return run function astral:forge/missing
clear @s minecraft:iron_ingot[!minecraft:custom_data] 1
clear @s *[minecraft:custom_data~{astral:{id:"esencia_nether"}}] 1
loot give @s loot astral:item/shadowsteel
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Acero Sombrio", "color": "#5b4a6b", "italic": false}]
return 1
