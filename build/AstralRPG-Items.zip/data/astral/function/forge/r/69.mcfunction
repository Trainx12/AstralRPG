execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"arquero_3_chestplate"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Chaqueta del Francotirador"}
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"nucleo_eolico"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Nucleo Eolico"}
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"gema_luminica"}}] 0
execute if score #h astral.tmp matches ..1 run return run function astral:forge/missing {need:"2x Gema Luminica"}
clear @s *[minecraft:custom_data~{astral:{id:"arquero_3_chestplate"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"nucleo_eolico"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"gema_luminica"}}] 2
loot give @s loot astral:item/arquero_4_chestplate
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Chaqueta del Viento", "color": "#5ee08a", "italic": false}]
return 1
