data modify storage astral:tmp forge.missing set value []
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"netherita_fundida"}}] 0
execute if score #h astral.tmp matches ..0 run data modify storage astral:tmp forge.missing append value "1x Netherita Fundida"
execute store result score #h astral.tmp run clear @s minecraft:blaze_powder[!minecraft:custom_data] 0
execute if score #h astral.tmp matches ..3 run data modify storage astral:tmp forge.missing append value "4x Polvo de blaze"
execute if data storage astral:tmp forge.missing[0] run return run function astral:forge/missing
clear @s *[minecraft:custom_data~{astral:{id:"netherita_fundida"}}] 1
clear @s minecraft:blaze_powder[!minecraft:custom_data] 4
loot give @s loot astral:item/netherita_reforzada
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Netherita Reforzada", "color": "#ff7b3a", "italic": false}]
return 1
