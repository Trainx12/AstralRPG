execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"arquero_1_leggings"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Pantalones del Rastreador"}
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"madera_estelar"}}] 0
execute if score #h astral.tmp matches ..1 run return run function astral:forge/missing {need:"2x Madera Estelar"}
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"gema_luminica"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Gema Luminica"}
clear @s *[minecraft:custom_data~{astral:{id:"arquero_1_leggings"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"madera_estelar"}}] 2
clear @s *[minecraft:custom_data~{astral:{id:"gema_luminica"}}] 1
loot give @s loot astral:item/arquero_2_leggings
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Pantalones del Explorador", "color": "#5ee08a", "italic": false}]
return 1
