execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"berserker_2_chestplate"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Coraza del Carnicero"}
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"shadowsteel"}}] 0
execute if score #h astral.tmp matches ..3 run return run function astral:forge/missing {need:"4x Acero Sombrio"}
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"netherita_reforzada"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Netherita Reforzada"}
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"gema_umbria"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Gema Umbria"}
clear @s *[minecraft:custom_data~{astral:{id:"berserker_2_chestplate"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"shadowsteel"}}] 4
clear @s *[minecraft:custom_data~{astral:{id:"netherita_reforzada"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"gema_umbria"}}] 1
loot give @s loot astral:item/berserker_3_chestplate
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Coraza del Ensangrentado", "color": "#ff4d4d", "italic": false}]
return 1
