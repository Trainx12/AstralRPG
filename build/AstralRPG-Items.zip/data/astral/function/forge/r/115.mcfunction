execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"talisman_roca_2"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Talisman de Roca II"}
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"chispa_astral"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Chispa Astral"}
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"nucleo_astral"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Nucleo Astral"}
clear @s *[minecraft:custom_data~{astral:{id:"talisman_roca_2"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"chispa_astral"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"nucleo_astral"}}] 1
loot give @s loot astral:item/talisman_roca_3
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Talisman de Roca III", "color": "#a0a0b0", "italic": false}]
return 1
