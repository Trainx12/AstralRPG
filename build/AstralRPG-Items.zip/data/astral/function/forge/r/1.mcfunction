execute store result score #h astral.tmp run clear @s minecraft:fishing_rod[!minecraft:custom_data] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Cana de pescar"}
execute store result score #h astral.tmp run clear @s minecraft:iron_ingot[!minecraft:custom_data] 0
execute if score #h astral.tmp matches ..1 run return run function astral:forge/missing {need:"2x Lingote de hierro"}
execute store result score #h astral.tmp run clear @s minecraft:string[!minecraft:custom_data] 0
execute if score #h astral.tmp matches ..1 run return run function astral:forge/missing {need:"2x Hilo"}
clear @s minecraft:fishing_rod[!minecraft:custom_data] 1
clear @s minecraft:iron_ingot[!minecraft:custom_data] 2
clear @s minecraft:string[!minecraft:custom_data] 2
loot give @s loot astral:item/gancho
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Gancho de Escalada", "color": "#d0d0d0", "italic": false}]
return 1
