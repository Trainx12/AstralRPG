data modify storage astral:tmp forge.missing set value []
execute store result score #h astral.tmp run clear @s minecraft:iron_block[!minecraft:custom_data] 0
execute if score #h astral.tmp matches ..2 run data modify storage astral:tmp forge.missing append value "3x Bloque de hierro"
execute store result score #h astral.tmp run clear @s minecraft:diamond[!minecraft:custom_data] 0
execute if score #h astral.tmp matches ..3 run data modify storage astral:tmp forge.missing append value "4x Diamante"
execute store result score #h astral.tmp run clear @s minecraft:redstone_block[!minecraft:custom_data] 0
execute if score #h astral.tmp matches ..1 run data modify storage astral:tmp forge.missing append value "2x Bloque de redstone"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"netherita_fundida"}}] 0
execute if score #h astral.tmp matches ..0 run data modify storage astral:tmp forge.missing append value "1x Netherita Fundida"
execute if data storage astral:tmp forge.missing[0] run return run function astral:forge/missing
clear @s minecraft:iron_block[!minecraft:custom_data] 3
clear @s minecraft:diamond[!minecraft:custom_data] 4
clear @s minecraft:redstone_block[!minecraft:custom_data] 2
clear @s *[minecraft:custom_data~{astral:{id:"netherita_fundida"}}] 1
loot give @s loot astral:item/motosierra_basica
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Motosierra Basica", "color": "#c8c8c8", "italic": false}]
return 1
