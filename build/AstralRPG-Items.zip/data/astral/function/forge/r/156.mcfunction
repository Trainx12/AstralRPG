data modify storage astral:tmp forge.missing set value []
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"asura_moneda_emerald"}}] 0
execute if score #h astral.tmp matches ..31 run data modify storage astral:tmp forge.missing append value "32x Moneda Asura Esmeralda"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"asura_moneda_card"}}] 0
execute if score #h astral.tmp matches ..1 run data modify storage astral:tmp forge.missing append value "2x Moneda Asura Carta"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"asura_moneda_circle"}}] 0
execute if score #h astral.tmp matches ..1 run data modify storage astral:tmp forge.missing append value "2x Moneda Asura Circulo"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"asura_moneda_square"}}] 0
execute if score #h astral.tmp matches ..1 run data modify storage astral:tmp forge.missing append value "2x Moneda Asura Cuadrado"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"asura_moneda_triangle"}}] 0
execute if score #h astral.tmp matches ..1 run data modify storage astral:tmp forge.missing append value "2x Moneda Asura Triangulo"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"netherita_reforzada"}}] 0
execute if score #h astral.tmp matches ..2 run data modify storage astral:tmp forge.missing append value "3x Netherita Reforzada"
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"gema_umbria"}}] 0
execute if score #h astral.tmp matches ..1 run data modify storage astral:tmp forge.missing append value "2x Gema Umbria"
execute if data storage astral:tmp forge.missing[0] run return run function astral:forge/missing
clear @s *[minecraft:custom_data~{astral:{id:"asura_moneda_emerald"}}] 32
clear @s *[minecraft:custom_data~{astral:{id:"asura_moneda_card"}}] 2
clear @s *[minecraft:custom_data~{astral:{id:"asura_moneda_circle"}}] 2
clear @s *[minecraft:custom_data~{astral:{id:"asura_moneda_square"}}] 2
clear @s *[minecraft:custom_data~{astral:{id:"asura_moneda_triangle"}}] 2
clear @s *[minecraft:custom_data~{astral:{id:"netherita_reforzada"}}] 3
clear @s *[minecraft:custom_data~{astral:{id:"gema_umbria"}}] 2
loot give @s loot astral:item/asura_espada
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Espada Asura", "color": "#ff4d4d", "italic": false}]
return 1
