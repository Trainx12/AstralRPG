execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"arquero_2_helmet"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Capucha del Explorador"}
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"madera_estelar"}}] 0
execute if score #h astral.tmp matches ..2 run return run function astral:forge/missing {need:"3x Madera Estelar"}
execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"cristal_refinado"}}] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Cristal Arcano Refinado"}
clear @s *[minecraft:custom_data~{astral:{id:"arquero_2_helmet"}}] 1
clear @s *[minecraft:custom_data~{astral:{id:"madera_estelar"}}] 3
clear @s *[minecraft:custom_data~{astral:{id:"cristal_refinado"}}] 1
loot give @s loot astral:item/arquero_3_helmet
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Capucha del Francotirador", "color": "#5ee08a", "italic": false}]
return 1
