execute store result score #h astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"nucleo_furia"}}] 0
execute if score #h astral.tmp matches ..3 run return run function astral:forge/missing {need:"4x Nucleo de Furia"}
execute store result score #h astral.tmp run clear @s minecraft:blaze_powder[!minecraft:custom_data] 0
execute if score #h astral.tmp matches ..3 run return run function astral:forge/missing {need:"4x Polvo de blaze"}
execute store result score #h astral.tmp run clear @s minecraft:lava_bucket[!minecraft:custom_data] 0
execute if score #h astral.tmp matches ..0 run return run function astral:forge/missing {need:"1x Cubo de lava"}
clear @s *[minecraft:custom_data~{astral:{id:"nucleo_furia"}}] 4
clear @s minecraft:blaze_powder[!minecraft:custom_data] 4
clear @s minecraft:lava_bucket[!minecraft:custom_data] 1
give @s minecraft:bucket 1
loot give @s loot astral:item/nucleo_furia_pura
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 0.8 1.4
particle minecraft:enchant ~ ~1 ~ 0.5 0.5 0.5 1 40
tellraw @s [{"text": "Forjaste: ", "color": "gray", "italic": false}, {"text": "Nucleo de Furia Pura", "color": "#ff1a1a", "italic": false}]
return 1
