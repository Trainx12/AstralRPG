scoreboard players reset @s astral.guia2
tellraw @s [{"text": "Guia Astral: ", "color": "light_purple", "italic": false}, {"text": "[Abrir]", "color": "aqua", "underlined": true, "click_event": {"action": "run_command", "command": "/guiaastral"}}, {"text": " o desde /menu.", "color": "gray"}]
