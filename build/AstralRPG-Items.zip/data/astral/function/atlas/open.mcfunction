scoreboard players reset @s astral.guia2
dialog show @s astral:atlas/indice
