execute as @a[scores={astral.guia2=1..}] run function astral:atlas/open
scoreboard players enable @a astral.guia2
