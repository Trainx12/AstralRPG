scoreboard objectives add astral.guia2 trigger
