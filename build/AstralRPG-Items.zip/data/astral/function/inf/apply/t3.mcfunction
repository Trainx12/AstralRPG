tag @s add astral.seen
scoreboard players set #mt astral.tmp 3
function astral:mob/t3
scoreboard players set @s astral.mt 3
function astral:inf/plus
data modify entity @s Health set value 1.0E9f
function astral:mob/nombre
tag @s remove inf.nuevo
