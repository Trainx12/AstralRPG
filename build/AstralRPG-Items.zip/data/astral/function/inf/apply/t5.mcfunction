tag @s add astral.seen
function astral:mob/t5
scoreboard players set @s astral.mt 5
function astral:inf/plus
data modify entity @s Health set value 1.0E9f
function astral:mob/nombre
tag @s remove inf.nuevo
