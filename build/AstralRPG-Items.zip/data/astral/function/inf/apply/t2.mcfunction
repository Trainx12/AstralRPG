tag @s add astral.seen
scoreboard players set #mt astral.tmp 2
function astral:mob/t2
scoreboard players set @s astral.mt 2
function astral:inf/plus
data modify entity @s Health set value 1.0E9f
function astral:mob/nombre
tag @s remove inf.nuevo
