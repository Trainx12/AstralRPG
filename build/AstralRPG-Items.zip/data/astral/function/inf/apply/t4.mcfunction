tag @s add astral.seen
scoreboard players set #mt astral.tmp 4
function astral:mob/t4
scoreboard players set @s astral.mt 4
function astral:inf/plus
data modify entity @s Health set value 1.0E9f
function astral:mob/nombre
tag @s remove inf.nuevo
