attribute @s minecraft:max_health base set 6562500
data modify entity @s Health set value 1.0E30f
scoreboard players set @s astral.mt 5
tag @s add astral.mt5
tag @s add astral.seen
tag @s add ad.boss.scaled
