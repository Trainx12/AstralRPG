attribute @s minecraft:max_health base set 1375000
data modify entity @s Health set value 1.0E30f
scoreboard players set @s astral.mt 4
tag @s add astral.mt4
tag @s add astral.seen
tag @s add ad.boss.scaled
