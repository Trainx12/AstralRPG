scoreboard objectives add astral.tmp dummy
scoreboard objectives add astral.const dummy
scoreboard objectives add astral.hp dummy
scoreboard objectives add astral.cd dummy
scoreboard objectives add astral.grap dummy
scoreboard objectives add astral.bleed dummy
scoreboard objectives add astral.bleedd dummy
scoreboard objectives add astral.remd dummy
scoreboard objectives add astral.ht dummy
scoreboard objectives add astral.wt dummy
scoreboard objectives add astral.at dummy
scoreboard objectives add astral.mt dummy
scoreboard objectives add astral.rem dummy
scoreboard objectives add astral.lvl dummy
scoreboard objectives add astral.draw dummy
scoreboard objectives add astral.use minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add astral.m_es minecraft.mined:minecraft.end_stone
scoreboard objectives add astral.m_ch minecraft.mined:minecraft.chorus_plant
scoreboard objectives add astral.guia trigger
scoreboard objectives add astral.forja trigger
scoreboard objectives add astral.dr minecraft.used:minecraft.netherite_pickaxe
scoreboard objectives add astral.cs minecraft.used:minecraft.netherite_axe
scoreboard objectives add astral.tok dummy
scoreboard objectives add astral.tx dummy
scoreboard objectives add astral.ty dummy
scoreboard objectives add astral.tz dummy
scoreboard objectives add astral.m_oak_log minecraft.mined:minecraft.oak_log
scoreboard objectives add astral.m_stripped_oak_log minecraft.mined:minecraft.stripped_oak_log
scoreboard objectives add astral.m_oak_wood minecraft.mined:minecraft.oak_wood
scoreboard objectives add astral.m_stripped_oak_wood minecraft.mined:minecraft.stripped_oak_wood
scoreboard objectives add astral.m_spruce_log minecraft.mined:minecraft.spruce_log
scoreboard objectives add astral.m_stripped_spruce_log minecraft.mined:minecraft.stripped_spruce_log
scoreboard objectives add astral.m_spruce_wood minecraft.mined:minecraft.spruce_wood
scoreboard objectives add astral.m_stripped_spruce_wood minecraft.mined:minecraft.stripped_spruce_wood
scoreboard objectives add astral.m_birch_log minecraft.mined:minecraft.birch_log
scoreboard objectives add astral.m_stripped_birch_log minecraft.mined:minecraft.stripped_birch_log
scoreboard objectives add astral.m_birch_wood minecraft.mined:minecraft.birch_wood
scoreboard objectives add astral.m_stripped_birch_wood minecraft.mined:minecraft.stripped_birch_wood
scoreboard objectives add astral.m_jungle_log minecraft.mined:minecraft.jungle_log
scoreboard objectives add astral.m_stripped_jungle_log minecraft.mined:minecraft.stripped_jungle_log
scoreboard objectives add astral.m_jungle_wood minecraft.mined:minecraft.jungle_wood
scoreboard objectives add astral.m_stripped_jungle_wood minecraft.mined:minecraft.stripped_jungle_wood
scoreboard objectives add astral.m_acacia_log minecraft.mined:minecraft.acacia_log
scoreboard objectives add astral.m_stripped_acacia_log minecraft.mined:minecraft.stripped_acacia_log
scoreboard objectives add astral.m_acacia_wood minecraft.mined:minecraft.acacia_wood
scoreboard objectives add astral.m_stripped_acacia_wood minecraft.mined:minecraft.stripped_acacia_wood
scoreboard objectives add astral.m_dark_oak_log minecraft.mined:minecraft.dark_oak_log
scoreboard objectives add astral.m_stripped_dark_oak_log minecraft.mined:minecraft.stripped_dark_oak_log
scoreboard objectives add astral.m_dark_oak_wood minecraft.mined:minecraft.dark_oak_wood
scoreboard objectives add astral.m_stripped_dark_oak_wood minecraft.mined:minecraft.stripped_dark_oak_wood
scoreboard objectives add astral.m_mangrove_log minecraft.mined:minecraft.mangrove_log
scoreboard objectives add astral.m_stripped_mangrove_log minecraft.mined:minecraft.stripped_mangrove_log
scoreboard objectives add astral.m_mangrove_wood minecraft.mined:minecraft.mangrove_wood
scoreboard objectives add astral.m_stripped_mangrove_wood minecraft.mined:minecraft.stripped_mangrove_wood
scoreboard objectives add astral.m_cherry_log minecraft.mined:minecraft.cherry_log
scoreboard objectives add astral.m_stripped_cherry_log minecraft.mined:minecraft.stripped_cherry_log
scoreboard objectives add astral.m_cherry_wood minecraft.mined:minecraft.cherry_wood
scoreboard objectives add astral.m_stripped_cherry_wood minecraft.mined:minecraft.stripped_cherry_wood
scoreboard objectives add astral.m_pale_oak_log minecraft.mined:minecraft.pale_oak_log
scoreboard objectives add astral.m_stripped_pale_oak_log minecraft.mined:minecraft.stripped_pale_oak_log
scoreboard objectives add astral.m_pale_oak_wood minecraft.mined:minecraft.pale_oak_wood
scoreboard objectives add astral.m_stripped_pale_oak_wood minecraft.mined:minecraft.stripped_pale_oak_wood
scoreboard players set #2 astral.const 2
scoreboard players set #3 astral.const 3
scoreboard players set #5 astral.const 5
scoreboard players set #7 astral.const 7
scoreboard players set #10 astral.const 10
scoreboard players set #100 astral.const 100
scoreboard players set #10000 astral.const 10000
scoreboard players set #1000 astral.const 1000
schedule function astral:loop/t5 5t replace
schedule function astral:loop/t10 10t replace
schedule function astral:loop/t20 20t replace
scoreboard objectives add astral.set_ber dummy
scoreboard objectives add astral.set_mag dummy
scoreboard objectives add astral.set_arq dummy
scoreboard objectives add astral.ofi_min dummy
scoreboard objectives add astral.ofi_tal dummy
scoreboard objectives add astral.kills minecraft.custom:minecraft.mob_kills
scoreboard objectives add astralmejn dummy
scoreboard objectives add astralmejok dummy
scoreboard objectives add astraldef dummy
scoreboard objectives add astral.defp dummy
function astral:quest/load

scoreboard objectives add ad.party dummy
scoreboard objectives add ad.n dummy
scoreboard objectives add ad.i dummy
scoreboard objectives add ad.clock dummy
scoreboard objectives add ad.alive dummy
scoreboard objectives add ad.q dummy
scoreboard objectives add ad.qm dummy
scoreboard objectives add ad.w dummy

scoreboard objectives add ad.room dummy
scoreboard objectives add ad.wave dummy
scoreboard objectives add ad.total dummy
scoreboard objectives add ad.left dummy
scoreboard objectives add ad.max dummy
scoreboard objectives add ad.pending dummy
bossbar add astral:tanda2/mina/sala1 "Campamento Minero"
bossbar set astral:tanda2/mina/sala1 color purple
bossbar set astral:tanda2/mina/sala1 players
bossbar add astral:tanda2/mina/sala1_c2 "Campamento Minero"
bossbar set astral:tanda2/mina/sala1_c2 color purple
bossbar set astral:tanda2/mina/sala1_c2 players
bossbar add astral:tanda2/mina/sala1_c3 "Campamento Minero"
bossbar set astral:tanda2/mina/sala1_c3 color purple
bossbar set astral:tanda2/mina/sala1_c3 players
bossbar add astral:tanda2/mina/sala1_c4 "Campamento Minero"
bossbar set astral:tanda2/mina/sala1_c4 color purple
bossbar set astral:tanda2/mina/sala1_c4 players
bossbar add astral:tanda2/mina/sala1_c5 "Campamento Minero"
bossbar set astral:tanda2/mina/sala1_c5 color purple
bossbar set astral:tanda2/mina/sala1_c5 players
bossbar add astral:tanda2/mina/sala1_c6 "Campamento Minero"
bossbar set astral:tanda2/mina/sala1_c6 color purple
bossbar set astral:tanda2/mina/sala1_c6 players
bossbar add astral:tanda2/mina/sala2 "Lago Subterraneo"
bossbar set astral:tanda2/mina/sala2 color purple
bossbar set astral:tanda2/mina/sala2 players
bossbar add astral:tanda2/mina/sala2_c2 "Lago Subterraneo"
bossbar set astral:tanda2/mina/sala2_c2 color purple
bossbar set astral:tanda2/mina/sala2_c2 players
bossbar add astral:tanda2/mina/sala2_c3 "Lago Subterraneo"
bossbar set astral:tanda2/mina/sala2_c3 color purple
bossbar set astral:tanda2/mina/sala2_c3 players
bossbar add astral:tanda2/mina/sala2_c4 "Lago Subterraneo"
bossbar set astral:tanda2/mina/sala2_c4 color purple
bossbar set astral:tanda2/mina/sala2_c4 players
bossbar add astral:tanda2/mina/sala2_c5 "Lago Subterraneo"
bossbar set astral:tanda2/mina/sala2_c5 color purple
bossbar set astral:tanda2/mina/sala2_c5 players
bossbar add astral:tanda2/mina/sala2_c6 "Lago Subterraneo"
bossbar set astral:tanda2/mina/sala2_c6 color purple
bossbar set astral:tanda2/mina/sala2_c6 players
bossbar add astral:tanda2/mina/sala3 "Tuneles de Soporte"
bossbar set astral:tanda2/mina/sala3 color purple
bossbar set astral:tanda2/mina/sala3 players
bossbar add astral:tanda2/mina/sala3_c2 "Tuneles de Soporte"
bossbar set astral:tanda2/mina/sala3_c2 color purple
bossbar set astral:tanda2/mina/sala3_c2 players
bossbar add astral:tanda2/mina/sala3_c3 "Tuneles de Soporte"
bossbar set astral:tanda2/mina/sala3_c3 color purple
bossbar set astral:tanda2/mina/sala3_c3 players
bossbar add astral:tanda2/mina/sala3_c4 "Tuneles de Soporte"
bossbar set astral:tanda2/mina/sala3_c4 color purple
bossbar set astral:tanda2/mina/sala3_c4 players
bossbar add astral:tanda2/mina/sala3_c5 "Tuneles de Soporte"
bossbar set astral:tanda2/mina/sala3_c5 color purple
bossbar set astral:tanda2/mina/sala3_c5 players
bossbar add astral:tanda2/mina/sala3_c6 "Tuneles de Soporte"
bossbar set astral:tanda2/mina/sala3_c6 color purple
bossbar set astral:tanda2/mina/sala3_c6 players
bossbar add astral:tanda2/mina/sala4 "Salon del Guardian"
bossbar set astral:tanda2/mina/sala4 color purple
bossbar set astral:tanda2/mina/sala4 players
bossbar add astral:tanda2/mina/sala4_c2 "Salon del Guardian"
bossbar set astral:tanda2/mina/sala4_c2 color purple
bossbar set astral:tanda2/mina/sala4_c2 players
bossbar add astral:tanda2/mina/sala4_c3 "Salon del Guardian"
bossbar set astral:tanda2/mina/sala4_c3 color purple
bossbar set astral:tanda2/mina/sala4_c3 players
bossbar add astral:tanda2/mina/sala4_c4 "Salon del Guardian"
bossbar set astral:tanda2/mina/sala4_c4 color purple
bossbar set astral:tanda2/mina/sala4_c4 players
bossbar add astral:tanda2/mina/sala4_c5 "Salon del Guardian"
bossbar set astral:tanda2/mina/sala4_c5 color purple
bossbar set astral:tanda2/mina/sala4_c5 players
bossbar add astral:tanda2/mina/sala4_c6 "Salon del Guardian"
bossbar set astral:tanda2/mina/sala4_c6 color purple
bossbar set astral:tanda2/mina/sala4_c6 players
bossbar add astral:tanda2/bosque/sala1 "Claro de las raices"
bossbar set astral:tanda2/bosque/sala1 color purple
bossbar set astral:tanda2/bosque/sala1 players
bossbar add astral:tanda2/bosque/sala1_c2 "Claro de las raices"
bossbar set astral:tanda2/bosque/sala1_c2 color purple
bossbar set astral:tanda2/bosque/sala1_c2 players
bossbar add astral:tanda2/bosque/sala1_c3 "Claro de las raices"
bossbar set astral:tanda2/bosque/sala1_c3 color purple
bossbar set astral:tanda2/bosque/sala1_c3 players
bossbar add astral:tanda2/bosque/sala1_c4 "Claro de las raices"
bossbar set astral:tanda2/bosque/sala1_c4 color purple
bossbar set astral:tanda2/bosque/sala1_c4 players
bossbar add astral:tanda2/bosque/sala1_c5 "Claro de las raices"
bossbar set astral:tanda2/bosque/sala1_c5 color purple
bossbar set astral:tanda2/bosque/sala1_c5 players
bossbar add astral:tanda2/bosque/sala1_c6 "Claro de las raices"
bossbar set astral:tanda2/bosque/sala1_c6 color purple
bossbar set astral:tanda2/bosque/sala1_c6 players
bossbar add astral:tanda2/bosque/sala2 "Altar del Chaman"
bossbar set astral:tanda2/bosque/sala2 color purple
bossbar set astral:tanda2/bosque/sala2 players
bossbar add astral:tanda2/bosque/sala2_c2 "Altar del Chaman"
bossbar set astral:tanda2/bosque/sala2_c2 color purple
bossbar set astral:tanda2/bosque/sala2_c2 players
bossbar add astral:tanda2/bosque/sala2_c3 "Altar del Chaman"
bossbar set astral:tanda2/bosque/sala2_c3 color purple
bossbar set astral:tanda2/bosque/sala2_c3 players
bossbar add astral:tanda2/bosque/sala2_c4 "Altar del Chaman"
bossbar set astral:tanda2/bosque/sala2_c4 color purple
bossbar set astral:tanda2/bosque/sala2_c4 players
bossbar add astral:tanda2/bosque/sala2_c5 "Altar del Chaman"
bossbar set astral:tanda2/bosque/sala2_c5 color purple
bossbar set astral:tanda2/bosque/sala2_c5 players
bossbar add astral:tanda2/bosque/sala2_c6 "Altar del Chaman"
bossbar set astral:tanda2/bosque/sala2_c6 color purple
bossbar set astral:tanda2/bosque/sala2_c6 players
bossbar add astral:tanda2/tumba/sala1 "Patio de los olvidados"
bossbar set astral:tanda2/tumba/sala1 color purple
bossbar set astral:tanda2/tumba/sala1 players
bossbar add astral:tanda2/tumba/sala1_c2 "Patio de los olvidados"
bossbar set astral:tanda2/tumba/sala1_c2 color purple
bossbar set astral:tanda2/tumba/sala1_c2 players
bossbar add astral:tanda2/tumba/sala1_c3 "Patio de los olvidados"
bossbar set astral:tanda2/tumba/sala1_c3 color purple
bossbar set astral:tanda2/tumba/sala1_c3 players
bossbar add astral:tanda2/tumba/sala1_c4 "Patio de los olvidados"
bossbar set astral:tanda2/tumba/sala1_c4 color purple
bossbar set astral:tanda2/tumba/sala1_c4 players
bossbar add astral:tanda2/tumba/sala1_c5 "Patio de los olvidados"
bossbar set astral:tanda2/tumba/sala1_c5 color purple
bossbar set astral:tanda2/tumba/sala1_c5 players
bossbar add astral:tanda2/tumba/sala1_c6 "Patio de los olvidados"
bossbar set astral:tanda2/tumba/sala1_c6 color purple
bossbar set astral:tanda2/tumba/sala1_c6 players
bossbar add astral:tanda2/tumba/sala2 "Pasaje de los sellos"
bossbar set astral:tanda2/tumba/sala2 color purple
bossbar set astral:tanda2/tumba/sala2 players
bossbar add astral:tanda2/tumba/sala2_c2 "Pasaje de los sellos"
bossbar set astral:tanda2/tumba/sala2_c2 color purple
bossbar set astral:tanda2/tumba/sala2_c2 players
bossbar add astral:tanda2/tumba/sala2_c3 "Pasaje de los sellos"
bossbar set astral:tanda2/tumba/sala2_c3 color purple
bossbar set astral:tanda2/tumba/sala2_c3 players
bossbar add astral:tanda2/tumba/sala2_c4 "Pasaje de los sellos"
bossbar set astral:tanda2/tumba/sala2_c4 color purple
bossbar set astral:tanda2/tumba/sala2_c4 players
bossbar add astral:tanda2/tumba/sala2_c5 "Pasaje de los sellos"
bossbar set astral:tanda2/tumba/sala2_c5 color purple
bossbar set astral:tanda2/tumba/sala2_c5 players
bossbar add astral:tanda2/tumba/sala2_c6 "Pasaje de los sellos"
bossbar set astral:tanda2/tumba/sala2_c6 color purple
bossbar set astral:tanda2/tumba/sala2_c6 players
bossbar add astral:tanda2/tumba/sala3 "Trono del Rey de Arena"
bossbar set astral:tanda2/tumba/sala3 color purple
bossbar set astral:tanda2/tumba/sala3 players
bossbar add astral:tanda2/tumba/sala3_c2 "Trono del Rey de Arena"
bossbar set astral:tanda2/tumba/sala3_c2 color purple
bossbar set astral:tanda2/tumba/sala3_c2 players
bossbar add astral:tanda2/tumba/sala3_c3 "Trono del Rey de Arena"
bossbar set astral:tanda2/tumba/sala3_c3 color purple
bossbar set astral:tanda2/tumba/sala3_c3 players
bossbar add astral:tanda2/tumba/sala3_c4 "Trono del Rey de Arena"
bossbar set astral:tanda2/tumba/sala3_c4 color purple
bossbar set astral:tanda2/tumba/sala3_c4 players
bossbar add astral:tanda2/tumba/sala3_c5 "Trono del Rey de Arena"
bossbar set astral:tanda2/tumba/sala3_c5 color purple
bossbar set astral:tanda2/tumba/sala3_c5 players
bossbar add astral:tanda2/tumba/sala3_c6 "Trono del Rey de Arena"
bossbar set astral:tanda2/tumba/sala3_c6 color purple
bossbar set astral:tanda2/tumba/sala3_c6 players
bossbar add astral:tanda2/cumbre/sala1 "Plaza de la fuente"
bossbar set astral:tanda2/cumbre/sala1 color purple
bossbar set astral:tanda2/cumbre/sala1 players
bossbar add astral:tanda2/cumbre/sala1_c2 "Plaza de la fuente"
bossbar set astral:tanda2/cumbre/sala1_c2 color purple
bossbar set astral:tanda2/cumbre/sala1_c2 players
bossbar add astral:tanda2/cumbre/sala1_c3 "Plaza de la fuente"
bossbar set astral:tanda2/cumbre/sala1_c3 color purple
bossbar set astral:tanda2/cumbre/sala1_c3 players
bossbar add astral:tanda2/cumbre/sala1_c4 "Plaza de la fuente"
bossbar set astral:tanda2/cumbre/sala1_c4 color purple
bossbar set astral:tanda2/cumbre/sala1_c4 players
bossbar add astral:tanda2/cumbre/sala1_c5 "Plaza de la fuente"
bossbar set astral:tanda2/cumbre/sala1_c5 color purple
bossbar set astral:tanda2/cumbre/sala1_c5 players
bossbar add astral:tanda2/cumbre/sala1_c6 "Plaza de la fuente"
bossbar set astral:tanda2/cumbre/sala1_c6 color purple
bossbar set astral:tanda2/cumbre/sala1_c6 players
bossbar add astral:tanda2/cumbre/sala2 "Trono del Yeti"
bossbar set astral:tanda2/cumbre/sala2 color purple
bossbar set astral:tanda2/cumbre/sala2 players
bossbar add astral:tanda2/cumbre/sala2_c2 "Trono del Yeti"
bossbar set astral:tanda2/cumbre/sala2_c2 color purple
bossbar set astral:tanda2/cumbre/sala2_c2 players
bossbar add astral:tanda2/cumbre/sala2_c3 "Trono del Yeti"
bossbar set astral:tanda2/cumbre/sala2_c3 color purple
bossbar set astral:tanda2/cumbre/sala2_c3 players
bossbar add astral:tanda2/cumbre/sala2_c4 "Trono del Yeti"
bossbar set astral:tanda2/cumbre/sala2_c4 color purple
bossbar set astral:tanda2/cumbre/sala2_c4 players
bossbar add astral:tanda2/cumbre/sala2_c5 "Trono del Yeti"
bossbar set astral:tanda2/cumbre/sala2_c5 color purple
bossbar set astral:tanda2/cumbre/sala2_c5 players
bossbar add astral:tanda2/cumbre/sala2_c6 "Trono del Yeti"
bossbar set astral:tanda2/cumbre/sala2_c6 color purple
bossbar set astral:tanda2/cumbre/sala2_c6 players
bossbar add astral:tanda2/forja/sala1 "Forja - sala 1"
bossbar set astral:tanda2/forja/sala1 color purple
bossbar set astral:tanda2/forja/sala1 players
bossbar add astral:tanda2/forja/sala1_c2 "Forja - sala 1"
bossbar set astral:tanda2/forja/sala1_c2 color purple
bossbar set astral:tanda2/forja/sala1_c2 players
bossbar add astral:tanda2/forja/sala1_c3 "Forja - sala 1"
bossbar set astral:tanda2/forja/sala1_c3 color purple
bossbar set astral:tanda2/forja/sala1_c3 players
bossbar add astral:tanda2/forja/sala1_c4 "Forja - sala 1"
bossbar set astral:tanda2/forja/sala1_c4 color purple
bossbar set astral:tanda2/forja/sala1_c4 players
bossbar add astral:tanda2/forja/sala1_c5 "Forja - sala 1"
bossbar set astral:tanda2/forja/sala1_c5 color purple
bossbar set astral:tanda2/forja/sala1_c5 players
bossbar add astral:tanda2/forja/sala1_c6 "Forja - sala 1"
bossbar set astral:tanda2/forja/sala1_c6 color purple
bossbar set astral:tanda2/forja/sala1_c6 players
bossbar add astral:tanda2/forja/sala2 "Forja - sala 2"
bossbar set astral:tanda2/forja/sala2 color purple
bossbar set astral:tanda2/forja/sala2 players
bossbar add astral:tanda2/forja/sala2_c2 "Forja - sala 2"
bossbar set astral:tanda2/forja/sala2_c2 color purple
bossbar set astral:tanda2/forja/sala2_c2 players
bossbar add astral:tanda2/forja/sala2_c3 "Forja - sala 2"
bossbar set astral:tanda2/forja/sala2_c3 color purple
bossbar set astral:tanda2/forja/sala2_c3 players
bossbar add astral:tanda2/forja/sala2_c4 "Forja - sala 2"
bossbar set astral:tanda2/forja/sala2_c4 color purple
bossbar set astral:tanda2/forja/sala2_c4 players
bossbar add astral:tanda2/forja/sala2_c5 "Forja - sala 2"
bossbar set astral:tanda2/forja/sala2_c5 color purple
bossbar set astral:tanda2/forja/sala2_c5 players
bossbar add astral:tanda2/forja/sala2_c6 "Forja - sala 2"
bossbar set astral:tanda2/forja/sala2_c6 color purple
bossbar set astral:tanda2/forja/sala2_c6 players
bossbar add astral:tanda2/forja/sala3 "Nucleo de la Forja"
bossbar set astral:tanda2/forja/sala3 color purple
bossbar set astral:tanda2/forja/sala3 players
bossbar add astral:tanda2/forja/sala3_c2 "Nucleo de la Forja"
bossbar set astral:tanda2/forja/sala3_c2 color purple
bossbar set astral:tanda2/forja/sala3_c2 players
bossbar add astral:tanda2/forja/sala3_c3 "Nucleo de la Forja"
bossbar set astral:tanda2/forja/sala3_c3 color purple
bossbar set astral:tanda2/forja/sala3_c3 players
bossbar add astral:tanda2/forja/sala3_c4 "Nucleo de la Forja"
bossbar set astral:tanda2/forja/sala3_c4 color purple
bossbar set astral:tanda2/forja/sala3_c4 players
bossbar add astral:tanda2/forja/sala3_c5 "Nucleo de la Forja"
bossbar set astral:tanda2/forja/sala3_c5 color purple
bossbar set astral:tanda2/forja/sala3_c5 players
bossbar add astral:tanda2/forja/sala3_c6 "Nucleo de la Forja"
bossbar set astral:tanda2/forja/sala3_c6 color purple
bossbar set astral:tanda2/forja/sala3_c6 players
function astral:santuario/load
