scoreboard objectives add astral.tmp dummy
scoreboard objectives add astral.const dummy
scoreboard objectives add astral.hp dummy
scoreboard objectives add astral.cd dummy
scoreboard objectives add astral.grap dummy
scoreboard objectives add astral.bleed dummy
scoreboard objectives add astral.bleedd dummy
scoreboard objectives add astral.remd dummy
scoreboard objectives add astral.ht dummy
scoreboard objectives add astral.wt dummy
scoreboard objectives add astral.at dummy
scoreboard objectives add astral.mt dummy
scoreboard objectives add astral.rem dummy
scoreboard objectives add astral.lvl dummy
scoreboard objectives add astral.draw dummy
scoreboard objectives add astral.use minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add astral.m_es minecraft.mined:minecraft.end_stone
scoreboard objectives add astral.m_ch minecraft.mined:minecraft.chorus_plant
scoreboard objectives add astral.guia trigger
scoreboard objectives add astral.forja trigger
scoreboard objectives add astral.dr minecraft.used:minecraft.netherite_pickaxe
scoreboard objectives add astral.cs minecraft.used:minecraft.netherite_axe
scoreboard objectives add astral.tok dummy
scoreboard objectives add astral.tx dummy
scoreboard objectives add astral.ty dummy
scoreboard objectives add astral.tz dummy
scoreboard objectives add astral.m_oak_log minecraft.mined:minecraft.oak_log
scoreboard objectives add astral.m_stripped_oak_log minecraft.mined:minecraft.stripped_oak_log
scoreboard objectives add astral.m_oak_wood minecraft.mined:minecraft.oak_wood
scoreboard objectives add astral.m_stripped_oak_wood minecraft.mined:minecraft.stripped_oak_wood
scoreboard objectives add astral.m_spruce_log minecraft.mined:minecraft.spruce_log
scoreboard objectives add astral.m_stripped_spruce_log minecraft.mined:minecraft.stripped_spruce_log
scoreboard objectives add astral.m_spruce_wood minecraft.mined:minecraft.spruce_wood
scoreboard objectives add astral.m_stripped_spruce_wood minecraft.mined:minecraft.stripped_spruce_wood
scoreboard objectives add astral.m_birch_log minecraft.mined:minecraft.birch_log
scoreboard objectives add astral.m_stripped_birch_log minecraft.mined:minecraft.stripped_birch_log
scoreboard objectives add astral.m_birch_wood minecraft.mined:minecraft.birch_wood
scoreboard objectives add astral.m_stripped_birch_wood minecraft.mined:minecraft.stripped_birch_wood
scoreboard objectives add astral.m_jungle_log minecraft.mined:minecraft.jungle_log
scoreboard objectives add astral.m_stripped_jungle_log minecraft.mined:minecraft.stripped_jungle_log
scoreboard objectives add astral.m_jungle_wood minecraft.mined:minecraft.jungle_wood
scoreboard objectives add astral.m_stripped_jungle_wood minecraft.mined:minecraft.stripped_jungle_wood
scoreboard objectives add astral.m_acacia_log minecraft.mined:minecraft.acacia_log
scoreboard objectives add astral.m_stripped_acacia_log minecraft.mined:minecraft.stripped_acacia_log
scoreboard objectives add astral.m_acacia_wood minecraft.mined:minecraft.acacia_wood
scoreboard objectives add astral.m_stripped_acacia_wood minecraft.mined:minecraft.stripped_acacia_wood
scoreboard objectives add astral.m_dark_oak_log minecraft.mined:minecraft.dark_oak_log
scoreboard objectives add astral.m_stripped_dark_oak_log minecraft.mined:minecraft.stripped_dark_oak_log
scoreboard objectives add astral.m_dark_oak_wood minecraft.mined:minecraft.dark_oak_wood
scoreboard objectives add astral.m_stripped_dark_oak_wood minecraft.mined:minecraft.stripped_dark_oak_wood
scoreboard objectives add astral.m_mangrove_log minecraft.mined:minecraft.mangrove_log
scoreboard objectives add astral.m_stripped_mangrove_log minecraft.mined:minecraft.stripped_mangrove_log
scoreboard objectives add astral.m_mangrove_wood minecraft.mined:minecraft.mangrove_wood
scoreboard objectives add astral.m_stripped_mangrove_wood minecraft.mined:minecraft.stripped_mangrove_wood
scoreboard objectives add astral.m_cherry_log minecraft.mined:minecraft.cherry_log
scoreboard objectives add astral.m_stripped_cherry_log minecraft.mined:minecraft.stripped_cherry_log
scoreboard objectives add astral.m_cherry_wood minecraft.mined:minecraft.cherry_wood
scoreboard objectives add astral.m_stripped_cherry_wood minecraft.mined:minecraft.stripped_cherry_wood
scoreboard objectives add astral.m_pale_oak_log minecraft.mined:minecraft.pale_oak_log
scoreboard objectives add astral.m_stripped_pale_oak_log minecraft.mined:minecraft.stripped_pale_oak_log
scoreboard objectives add astral.m_pale_oak_wood minecraft.mined:minecraft.pale_oak_wood
scoreboard objectives add astral.m_stripped_pale_oak_wood minecraft.mined:minecraft.stripped_pale_oak_wood
scoreboard players set #2 astral.const 2
scoreboard players set #3 astral.const 3
scoreboard players set #5 astral.const 5
scoreboard players set #7 astral.const 7
scoreboard players set #10 astral.const 10
scoreboard players set #100 astral.const 100
scoreboard players set #10000 astral.const 10000
scoreboard players set #1000 astral.const 1000
schedule function astral:loop/t5 5t replace
schedule function astral:loop/t10 10t replace
schedule function astral:loop/t20 20t replace
scoreboard objectives add astral.set_ber dummy
scoreboard objectives add astral.set_mag dummy
scoreboard objectives add astral.set_arq dummy
scoreboard objectives add astral.kills minecraft.custom:minecraft.mob_kills
scoreboard objectives add astralmejn dummy
scoreboard objectives add astralmejok dummy
function astral:quest/load
