scoreboard players set @s astralmejn 0
scoreboard players set @s astralmejok 0
scoreboard players set #k astral.tmp 0
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{type:"weapon"}}] unless items entity @s weapon.mainhand minecraft:carrot_on_a_stick run scoreboard players set #k astral.tmp 1
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{type:"staff"}}] run scoreboard players set #k astral.tmp 1
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{type:"armor"}}] run scoreboard players set #k astral.tmp 2
execute if score #k astral.tmp matches 0 run return run tellraw @s [{"text": "Herrero: ", "color": "gold", "italic": false}, {"text": "agarra en la mano un arma o una pieza de armadura de AstralRPG. (Los bastones de Mago no se mejoran aca.)", "color": "gray", "italic": false}]
scoreboard players set #l astral.tmp 0
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_arma",levels:1}]] run scoreboard players set #l astral.tmp 1
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_armadura",levels:1}]] run scoreboard players set #l astral.tmp 1
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_arma",levels:2}]] run scoreboard players set #l astral.tmp 2
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_armadura",levels:2}]] run scoreboard players set #l astral.tmp 2
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_arma",levels:3}]] run scoreboard players set #l astral.tmp 3
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_armadura",levels:3}]] run scoreboard players set #l astral.tmp 3
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_arma",levels:4}]] run scoreboard players set #l astral.tmp 4
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_armadura",levels:4}]] run scoreboard players set #l astral.tmp 4
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_arma",levels:5}]] run scoreboard players set #l astral.tmp 5
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_armadura",levels:5}]] run scoreboard players set #l astral.tmp 5
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_arma",levels:6}]] run scoreboard players set #l astral.tmp 6
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_armadura",levels:6}]] run scoreboard players set #l astral.tmp 6
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_arma",levels:7}]] run scoreboard players set #l astral.tmp 7
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_armadura",levels:7}]] run scoreboard players set #l astral.tmp 7
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_arma",levels:8}]] run scoreboard players set #l astral.tmp 8
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_armadura",levels:8}]] run scoreboard players set #l astral.tmp 8
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_arma",levels:9}]] run scoreboard players set #l astral.tmp 9
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_armadura",levels:9}]] run scoreboard players set #l astral.tmp 9
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_arma",levels:10}]] run scoreboard players set #l astral.tmp 10
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_armadura",levels:10}]] run scoreboard players set #l astral.tmp 10
execute if score #l astral.tmp matches 10.. run return run tellraw @s [{"text": "Herrero: ", "color": "gold", "italic": false}, {"text": "este item ya esta en +10, no se puede mejorar mas.", "color": "gray", "italic": false}]
scoreboard players operation #n astral.tmp = #l astral.tmp
scoreboard players add #n astral.tmp 1
execute if score #n astral.tmp matches 1 run function astral:mejora/ver/1
execute if score #n astral.tmp matches 2 run function astral:mejora/ver/2
execute if score #n astral.tmp matches 3 run function astral:mejora/ver/3
execute if score #n astral.tmp matches 4 run function astral:mejora/ver/4
execute if score #n astral.tmp matches 5 run function astral:mejora/ver/5
execute if score #n astral.tmp matches 6 run function astral:mejora/ver/6
execute if score #n astral.tmp matches 7 run function astral:mejora/ver/7
execute if score #n astral.tmp matches 8 run function astral:mejora/ver/8
execute if score #n astral.tmp matches 9 run function astral:mejora/ver/9
execute if score #n astral.tmp matches 10 run function astral:mejora/ver/10
