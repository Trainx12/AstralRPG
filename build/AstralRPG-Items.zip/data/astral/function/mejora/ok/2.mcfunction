execute if score #k astral.tmp matches 1 run item modify entity @s weapon.mainhand {function:"minecraft:set_enchantments",enchantments:{"astral:mejora_arma":2},add:false}
execute if score #k astral.tmp matches 2 run item modify entity @s weapon.mainhand {function:"minecraft:set_enchantments",enchantments:{"astral:mejora_armadura":2},add:false}
scoreboard players set @s astralmejok 2
playsound minecraft:block.anvil.use player @s ~ ~ ~ 1 1.2
particle minecraft:totem_of_undying ~ ~1 ~ 0.4 0.6 0.4 0.3 40
tellraw @s [{"text": "Herrero: ", "color": "gold", "italic": false}, {"text": "listo, tu item ahora es +2!", "color": "green", "italic": false, "bold": true}]
