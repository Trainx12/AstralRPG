execute if score #k astral.tmp matches 1 run item modify entity @s weapon.mainhand {function:"minecraft:set_enchantments",enchantments:{"astral:mejora_arma":3},add:false}
execute if score #k astral.tmp matches 2 run item modify entity @s weapon.mainhand {function:"minecraft:set_enchantments",enchantments:{"astral:mejora_armadura":3},add:false}
scoreboard players set @s astralmejok 3
playsound minecraft:block.anvil.use player @s ~ ~ ~ 1 1.2
particle minecraft:totem_of_undying ~ ~1 ~ 0.4 0.6 0.4 0.3 40
tellraw @s [{"text": "Herrero: ", "color": "gold", "italic": false}, {"text": "listo, tu item ahora es +3!", "color": "green", "italic": false, "bold": true}]
data modify storage astral:tmp ficha.id set from entity @s SelectedItem.components."minecraft:custom_data".astral.id
function astral:ficha/apply/3 with storage astral:tmp ficha
