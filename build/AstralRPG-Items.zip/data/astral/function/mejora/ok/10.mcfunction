execute if score #k astral.tmp matches 1 run item modify entity @s weapon.mainhand {function:"minecraft:set_enchantments",enchantments:{"astral:mejora_arma":10},add:false}
execute if score #k astral.tmp matches 2 run item modify entity @s weapon.mainhand {function:"minecraft:set_enchantments",enchantments:{"astral:mejora_armadura":10},add:false}
scoreboard players set @s astralmejok 10
playsound minecraft:block.anvil.use player @s ~ ~ ~ 1 1.2
particle minecraft:totem_of_undying ~ ~1 ~ 0.4 0.6 0.4 0.3 40
tellraw @s [{"text": "Herrero: ", "color": "gold", "italic": false}, {"text": "listo, tu item ahora es +10!", "color": "green", "italic": false, "bold": true}]
tellraw @a ["",{"text":"(!) ","color":"gold","bold":true},{"selector":"@s","color":"yellow"},{"text": " mejoro un item a +10 con el Herrero!", "color": "gray"}]
data modify storage astral:tmp ficha.id set from entity @s SelectedItem.components."minecraft:custom_data".astral.id
function astral:ficha/apply/10 with storage astral:tmp ficha
