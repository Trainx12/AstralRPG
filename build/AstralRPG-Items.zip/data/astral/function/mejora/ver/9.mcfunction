scoreboard players set #falta astral.tmp 0
tellraw @s [{"text": "Herrero: ", "color": "gold", "italic": false}, {"text": "mejora a +9", "color": "yellow", "italic": false, "bold": true}, {"text": " cuesta 7500$ y 3x Chispa Astral, 1x Nucleo Astral. Exito: 50%. ", "color": "gray", "italic": false}, {"text": "Da +32% de dano (arma) o +2.5 de vida por pieza (armadura).", "color": "dark_gray", "italic": false}]
execute store result score #c astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"chispa_astral"}}] 0
execute if score #c astral.tmp matches ..2 run scoreboard players set #falta astral.tmp 1
execute store result score #c astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"nucleo_astral"}}] 0
execute if score #c astral.tmp matches ..0 run scoreboard players set #falta astral.tmp 1
execute if score #falta astral.tmp matches 1 run return run tellraw @s {"text": "Te faltan materiales para esta mejora.", "color": "red", "italic": false}
scoreboard players set @s astralmejn 9
