scoreboard players set #falta astral.tmp 0
tellraw @s [{"text": "Herrero: ", "color": "gold", "italic": false}, {"text": "mejora a +1", "color": "yellow", "italic": false, "bold": true}, {"text": " cuesta 300$ y 1x Esencia de Elite. Exito: 100%. ", "color": "gray", "italic": false}, {"text": "Da +3% de dano (arma) o +0.5% de vida por pieza (armadura).", "color": "dark_gray", "italic": false}]
execute store result score #c astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"esencia_elite"}}] 0
execute if score #c astral.tmp matches ..0 run scoreboard players set #falta astral.tmp 1
execute if score #falta astral.tmp matches 1 run return run tellraw @s {"text": "Te faltan materiales para esta mejora.", "color": "red", "italic": false}
scoreboard players set @s astralmejn 1
