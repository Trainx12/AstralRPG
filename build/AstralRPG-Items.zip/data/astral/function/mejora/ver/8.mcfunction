scoreboard players set #falta astral.tmp 0
tellraw @s [{"text": "Herrero: ", "color": "gold", "italic": false}, {"text": "mejora a +8", "color": "yellow", "italic": false, "bold": true}, {"text": " cuesta 5000$ y 3x Chispa Astral, 3x Alma Corrupta. Exito: 60%. ", "color": "gray", "italic": false}, {"text": "Da +27% de dano (arma) o +4% de vida por pieza (armadura).", "color": "dark_gray", "italic": false}]
execute store result score #c astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"chispa_astral"}}] 0
execute if score #c astral.tmp matches ..2 run scoreboard players set #falta astral.tmp 1
execute store result score #c astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"alma_corrupta"}}] 0
execute if score #c astral.tmp matches ..2 run scoreboard players set #falta astral.tmp 1
execute if score #falta astral.tmp matches 1 run return run tellraw @s {"text": "Te faltan materiales para esta mejora.", "color": "red", "italic": false}
scoreboard players set @s astralmejn 8
