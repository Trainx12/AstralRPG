scoreboard players set #falta astral.tmp 0
tellraw @s [{"text": "Herrero: ", "color": "gold", "italic": false}, {"text": "mejora a +3", "color": "yellow", "italic": false, "bold": true}, {"text": " cuesta 1000$ y 3x Esencia de Elite, 1x Fragmento Astral. Exito: 100%. ", "color": "gray", "italic": false}, {"text": "Da +9% de dano (arma) o +1.5% de vida por pieza (armadura).", "color": "dark_gray", "italic": false}]
execute store result score #c astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"esencia_elite"}}] 0
execute if score #c astral.tmp matches ..2 run scoreboard players set #falta astral.tmp 1
execute store result score #c astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"fragmento_astral"}}] 0
execute if score #c astral.tmp matches ..0 run scoreboard players set #falta astral.tmp 1
execute if score #falta astral.tmp matches 1 run return run tellraw @s {"text": "Te faltan materiales para esta mejora.", "color": "red", "italic": false}
scoreboard players set @s astralmejn 3
