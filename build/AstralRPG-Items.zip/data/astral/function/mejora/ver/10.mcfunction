scoreboard players set #falta astral.tmp 0
tellraw @s [{"text": "Herrero: ", "color": "gold", "italic": false}, {"text": "mejora a +10", "color": "yellow", "italic": false, "bold": true}, {"text": " cuesta 10000$ y 5x Chispa Astral, 1x Nucleo Astral. Exito: 40%. ", "color": "gray", "italic": false}, {"text": "Da +40% de dano (arma) o +5% de vida por pieza (armadura).", "color": "dark_gray", "italic": false}]
execute store result score #c astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"chispa_astral"}}] 0
execute if score #c astral.tmp matches ..4 run scoreboard players set #falta astral.tmp 1
execute store result score #c astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"nucleo_astral"}}] 0
execute if score #c astral.tmp matches ..0 run scoreboard players set #falta astral.tmp 1
execute if score #falta astral.tmp matches 1 run return run tellraw @s {"text": "Te faltan materiales para esta mejora.", "color": "red", "italic": false}
scoreboard players set @s astralmejn 10
