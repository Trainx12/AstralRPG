tag @s add asgui.next8
scoreboard players set @s astralmejn 8
scoreboard players set #falta astral.tmp 0
execute store result score #c astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"chispa_astral"}}] 0
execute if score #c astral.tmp matches 3.. run tag @s add asgui.mat.chispa_astral
execute unless score #c astral.tmp matches 3.. run scoreboard players set #falta astral.tmp 1
execute store result score #c astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"alma_corrupta"}}] 0
execute if score #c astral.tmp matches 3.. run tag @s add asgui.mat.alma_corrupta
execute unless score #c astral.tmp matches 3.. run scoreboard players set #falta astral.tmp 1
execute if score #falta astral.tmp matches 0 run tag @s add asgui.ready
