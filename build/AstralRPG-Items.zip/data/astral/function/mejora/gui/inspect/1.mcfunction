tag @s add asgui.next1
scoreboard players set @s astralmejn 1
scoreboard players set #falta astral.tmp 0
execute store result score #c astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"esencia_elite"}}] 0
execute if score #c astral.tmp matches 1.. run tag @s add asgui.mat.esencia_elite
execute unless score #c astral.tmp matches 1.. run scoreboard players set #falta astral.tmp 1
execute if score #falta astral.tmp matches 0 run tag @s add asgui.ready
