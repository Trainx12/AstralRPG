tag @s add asgui.next10
scoreboard players set @s astralmejn 10
scoreboard players set #falta astral.tmp 0
execute store result score #c astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"chispa_astral"}}] 0
execute if score #c astral.tmp matches 5.. run tag @s add asgui.mat.chispa_astral
execute unless score #c astral.tmp matches 5.. run scoreboard players set #falta astral.tmp 1
execute store result score #c astral.tmp run clear @s *[minecraft:custom_data~{astral:{id:"nucleo_astral"}}] 0
execute if score #c astral.tmp matches 1.. run tag @s add asgui.mat.nucleo_astral
execute unless score #c astral.tmp matches 1.. run scoreboard players set #falta astral.tmp 1
execute if score #falta astral.tmp matches 0 run tag @s add asgui.ready
