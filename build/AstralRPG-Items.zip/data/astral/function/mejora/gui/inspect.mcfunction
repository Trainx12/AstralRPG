tag @s remove asgui.valid
tag @s remove asgui.max
tag @s remove asgui.ready
tag @s remove asgui.attempted
tag @s remove asgui.success
scoreboard players set @s astralmejok 0
scoreboard players set @s astralmejn 0
tag @s remove asgui.next1
tag @s remove asgui.next2
tag @s remove asgui.next3
tag @s remove asgui.next4
tag @s remove asgui.next5
tag @s remove asgui.next6
tag @s remove asgui.next7
tag @s remove asgui.next8
tag @s remove asgui.next9
tag @s remove asgui.next10
tag @s remove asgui.mat.alma_corrupta
tag @s remove asgui.mat.chispa_astral
tag @s remove asgui.mat.esencia_elite
tag @s remove asgui.mat.fragmento_astral
tag @s remove asgui.mat.nucleo_astral
scoreboard players set #k astral.tmp 0
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{type:"weapon"}}] unless items entity @s weapon.mainhand minecraft:carrot_on_a_stick run scoreboard players set #k astral.tmp 1
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{type:"armor"}}] run scoreboard players set #k astral.tmp 2
execute if score #k astral.tmp matches 0 run return 0
tag @s add asgui.valid
scoreboard players set #l astral.tmp 0
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_arma",levels:1}]] run scoreboard players set #l astral.tmp 1
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_armadura",levels:1}]] run scoreboard players set #l astral.tmp 1
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_arma",levels:2}]] run scoreboard players set #l astral.tmp 2
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_armadura",levels:2}]] run scoreboard players set #l astral.tmp 2
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_arma",levels:3}]] run scoreboard players set #l astral.tmp 3
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_armadura",levels:3}]] run scoreboard players set #l astral.tmp 3
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_arma",levels:4}]] run scoreboard players set #l astral.tmp 4
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_armadura",levels:4}]] run scoreboard players set #l astral.tmp 4
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_arma",levels:5}]] run scoreboard players set #l astral.tmp 5
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_armadura",levels:5}]] run scoreboard players set #l astral.tmp 5
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_arma",levels:6}]] run scoreboard players set #l astral.tmp 6
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_armadura",levels:6}]] run scoreboard players set #l astral.tmp 6
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_arma",levels:7}]] run scoreboard players set #l astral.tmp 7
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_armadura",levels:7}]] run scoreboard players set #l astral.tmp 7
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_arma",levels:8}]] run scoreboard players set #l astral.tmp 8
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_armadura",levels:8}]] run scoreboard players set #l astral.tmp 8
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_arma",levels:9}]] run scoreboard players set #l astral.tmp 9
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_armadura",levels:9}]] run scoreboard players set #l astral.tmp 9
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_arma",levels:10}]] run scoreboard players set #l astral.tmp 10
execute if items entity @s weapon.mainhand *[minecraft:enchantments~[{enchantments:"astral:mejora_armadura",levels:10}]] run scoreboard players set #l astral.tmp 10
execute if score #l astral.tmp matches 10.. run return run tag @s add asgui.max
scoreboard players operation #n astral.tmp = #l astral.tmp
scoreboard players add #n astral.tmp 1
execute if score #n astral.tmp matches 1 run function astral:mejora/gui/inspect/1
execute if score #n astral.tmp matches 2 run function astral:mejora/gui/inspect/2
execute if score #n astral.tmp matches 3 run function astral:mejora/gui/inspect/3
execute if score #n astral.tmp matches 4 run function astral:mejora/gui/inspect/4
execute if score #n astral.tmp matches 5 run function astral:mejora/gui/inspect/5
execute if score #n astral.tmp matches 6 run function astral:mejora/gui/inspect/6
execute if score #n astral.tmp matches 7 run function astral:mejora/gui/inspect/7
execute if score #n astral.tmp matches 8 run function astral:mejora/gui/inspect/8
execute if score #n astral.tmp matches 9 run function astral:mejora/gui/inspect/9
execute if score #n astral.tmp matches 10 run function astral:mejora/gui/inspect/10
