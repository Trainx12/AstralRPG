function astral:mejora/gui/inspect
execute unless entity @s[tag=asgui.ready] run return 0
tag @s add asgui.attempted
execute if entity @s[tag=asgui.next1] run function astral:mejora/n/1
execute if entity @s[tag=asgui.next2] run function astral:mejora/n/2
execute if entity @s[tag=asgui.next3] run function astral:mejora/n/3
execute if entity @s[tag=asgui.next4] run function astral:mejora/n/4
execute if entity @s[tag=asgui.next5] run function astral:mejora/n/5
execute if entity @s[tag=asgui.next6] run function astral:mejora/n/6
execute if entity @s[tag=asgui.next7] run function astral:mejora/n/7
execute if entity @s[tag=asgui.next8] run function astral:mejora/n/8
execute if entity @s[tag=asgui.next9] run function astral:mejora/n/9
execute if entity @s[tag=asgui.next10] run function astral:mejora/n/10
execute if score @s astralmejok matches 1.. run tag @s add asgui.success
