clear @s *[minecraft:custom_data~{astral:{id:"alma_corrupta"}}] 2
clear @s *[minecraft:custom_data~{astral:{id:"esencia_elite"}}] 3
function astral:quest/event/upgrade
execute store success score #ok astral.tmp if predicate astral:chance/900
execute if score #ok astral.tmp matches 1 run return run function astral:mejora/ok/5
playsound minecraft:block.anvil.destroy player @s ~ ~ ~ 1 1
tellraw @s [{"text": "Herrero: ", "color": "gold", "italic": false}, {"text": "la mejora a +5 fallo. ", "color": "red", "italic": false}, {"text": "Perdiste los materiales, pero tu item quedo igual y no se cobro la plata.", "color": "gray", "italic": false}]
