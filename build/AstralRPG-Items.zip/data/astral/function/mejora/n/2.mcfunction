clear @s *[minecraft:custom_data~{astral:{id:"esencia_elite"}}] 2
function astral:mejora/ok/2
