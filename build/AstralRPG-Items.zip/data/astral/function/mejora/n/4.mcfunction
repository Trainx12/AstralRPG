clear @s *[minecraft:custom_data~{astral:{id:"esencia_elite"}}] 3
clear @s *[minecraft:custom_data~{astral:{id:"alma_corrupta"}}] 1
function astral:mejora/ok/4
