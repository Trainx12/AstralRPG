clear @s *[minecraft:custom_data~{astral:{id:"esencia_elite"}}] 3
clear @s *[minecraft:custom_data~{astral:{id:"fragmento_astral"}}] 1
function astral:mejora/ok/3
