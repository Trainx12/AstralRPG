clear @s *[minecraft:custom_data~{astral:{id:"chispa_astral"}}] 5
clear @s *[minecraft:custom_data~{astral:{id:"nucleo_astral"}}] 1
execute store success score #ok astral.tmp if predicate astral:chance/400
execute if score #ok astral.tmp matches 1 run return run function astral:mejora/ok/10
playsound minecraft:block.anvil.destroy player @s ~ ~ ~ 1 1
tellraw @s [{"text": "Herrero: ", "color": "gold", "italic": false}, {"text": "la mejora a +10 fallo. ", "color": "red", "italic": false}, {"text": "Perdiste los materiales, pero tu item quedo igual y no se cobro la plata.", "color": "gray", "italic": false}]
