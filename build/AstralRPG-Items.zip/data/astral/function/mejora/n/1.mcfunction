clear @s *[minecraft:custom_data~{astral:{id:"esencia_elite"}}] 1
function astral:mejora/ok/1
