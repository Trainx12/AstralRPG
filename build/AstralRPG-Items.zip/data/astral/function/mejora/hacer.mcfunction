scoreboard players set #k astral.tmp 0
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{type:"weapon"}}] unless items entity @s weapon.mainhand minecraft:carrot_on_a_stick run scoreboard players set #k astral.tmp 1
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{type:"staff"}}] run scoreboard players set #k astral.tmp 1
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral:{type:"armor"}}] run scoreboard players set #k astral.tmp 2
execute if score #k astral.tmp matches 0 run return 0
execute if score @s astralmejn matches 1 run function astral:mejora/n/1
execute if score @s astralmejn matches 2 run function astral:mejora/n/2
execute if score @s astralmejn matches 3 run function astral:mejora/n/3
execute if score @s astralmejn matches 4 run function astral:mejora/n/4
execute if score @s astralmejn matches 5 run function astral:mejora/n/5
execute if score @s astralmejn matches 6 run function astral:mejora/n/6
execute if score @s astralmejn matches 7 run function astral:mejora/n/7
execute if score @s astralmejn matches 8 run function astral:mejora/n/8
execute if score @s astralmejn matches 9 run function astral:mejora/n/9
execute if score @s astralmejn matches 10 run function astral:mejora/n/10
