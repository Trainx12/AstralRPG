execute if items entity @s hotbar.8 *[minecraft:custom_data~{astral_menu:1b}] run return run function astral:menu_star/cleanup
clear @s *[minecraft:custom_data~{astral_menu:1b}]
execute if items entity @s hotbar.8 * unless items entity @s container.0 * run return run function astral:menu_star/move {slot:"container.0"}
execute if items entity @s hotbar.8 * unless items entity @s container.1 * run return run function astral:menu_star/move {slot:"container.1"}
execute if items entity @s hotbar.8 * unless items entity @s container.2 * run return run function astral:menu_star/move {slot:"container.2"}
execute if items entity @s hotbar.8 * unless items entity @s container.3 * run return run function astral:menu_star/move {slot:"container.3"}
execute if items entity @s hotbar.8 * unless items entity @s container.4 * run return run function astral:menu_star/move {slot:"container.4"}
execute if items entity @s hotbar.8 * unless items entity @s container.5 * run return run function astral:menu_star/move {slot:"container.5"}
execute if items entity @s hotbar.8 * unless items entity @s container.6 * run return run function astral:menu_star/move {slot:"container.6"}
execute if items entity @s hotbar.8 * unless items entity @s container.7 * run return run function astral:menu_star/move {slot:"container.7"}
execute if items entity @s hotbar.8 * unless items entity @s container.9 * run return run function astral:menu_star/move {slot:"container.9"}
execute if items entity @s hotbar.8 * unless items entity @s container.10 * run return run function astral:menu_star/move {slot:"container.10"}
execute if items entity @s hotbar.8 * unless items entity @s container.11 * run return run function astral:menu_star/move {slot:"container.11"}
execute if items entity @s hotbar.8 * unless items entity @s container.12 * run return run function astral:menu_star/move {slot:"container.12"}
execute if items entity @s hotbar.8 * unless items entity @s container.13 * run return run function astral:menu_star/move {slot:"container.13"}
execute if items entity @s hotbar.8 * unless items entity @s container.14 * run return run function astral:menu_star/move {slot:"container.14"}
execute if items entity @s hotbar.8 * unless items entity @s container.15 * run return run function astral:menu_star/move {slot:"container.15"}
execute if items entity @s hotbar.8 * unless items entity @s container.16 * run return run function astral:menu_star/move {slot:"container.16"}
execute if items entity @s hotbar.8 * unless items entity @s container.17 * run return run function astral:menu_star/move {slot:"container.17"}
execute if items entity @s hotbar.8 * unless items entity @s container.18 * run return run function astral:menu_star/move {slot:"container.18"}
execute if items entity @s hotbar.8 * unless items entity @s container.19 * run return run function astral:menu_star/move {slot:"container.19"}
execute if items entity @s hotbar.8 * unless items entity @s container.20 * run return run function astral:menu_star/move {slot:"container.20"}
execute if items entity @s hotbar.8 * unless items entity @s container.21 * run return run function astral:menu_star/move {slot:"container.21"}
execute if items entity @s hotbar.8 * unless items entity @s container.22 * run return run function astral:menu_star/move {slot:"container.22"}
execute if items entity @s hotbar.8 * unless items entity @s container.23 * run return run function astral:menu_star/move {slot:"container.23"}
execute if items entity @s hotbar.8 * unless items entity @s container.24 * run return run function astral:menu_star/move {slot:"container.24"}
execute if items entity @s hotbar.8 * unless items entity @s container.25 * run return run function astral:menu_star/move {slot:"container.25"}
execute if items entity @s hotbar.8 * unless items entity @s container.26 * run return run function astral:menu_star/move {slot:"container.26"}
execute if items entity @s hotbar.8 * unless items entity @s container.27 * run return run function astral:menu_star/move {slot:"container.27"}
execute if items entity @s hotbar.8 * unless items entity @s container.28 * run return run function astral:menu_star/move {slot:"container.28"}
execute if items entity @s hotbar.8 * unless items entity @s container.29 * run return run function astral:menu_star/move {slot:"container.29"}
execute if items entity @s hotbar.8 * unless items entity @s container.30 * run return run function astral:menu_star/move {slot:"container.30"}
execute if items entity @s hotbar.8 * unless items entity @s container.31 * run return run function astral:menu_star/move {slot:"container.31"}
execute if items entity @s hotbar.8 * unless items entity @s container.32 * run return run function astral:menu_star/move {slot:"container.32"}
execute if items entity @s hotbar.8 * unless items entity @s container.33 * run return run function astral:menu_star/move {slot:"container.33"}
execute if items entity @s hotbar.8 * unless items entity @s container.34 * run return run function astral:menu_star/move {slot:"container.34"}
execute if items entity @s hotbar.8 * unless items entity @s container.35 * run return run function astral:menu_star/move {slot:"container.35"}
data remove storage astral:menu_star displaced
data modify storage astral:menu_star displaced set from entity @s Inventory[{Slot:8b}]
data remove storage astral:menu_star displaced.Slot
item replace entity @s hotbar.8 with minecraft:nether_star[minecraft:custom_data={astral_menu:1b},minecraft:custom_name={text:"Menu Astral",color:"aqua",bold:true,italic:false},minecraft:lore=[{text:"Clic derecho para abrir el menu.",color:"gray",italic:false},{text:"No se puede tirar ni vender.",color:"dark_gray",italic:false}],minecraft:enchantment_glint_override=true] 1
execute if data storage astral:menu_star displaced.id run function astral:menu_star/restore with storage astral:menu_star
data remove storage astral:menu_star displaced
