tag @s remove astral.menu.held
tag @s remove astral.menu.slot
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{astral_menu:1b}] run tag @s add astral.menu.held
execute if items entity @s hotbar.8 *[minecraft:custom_data~{astral_menu:1b}] run tag @s add astral.menu.slot
