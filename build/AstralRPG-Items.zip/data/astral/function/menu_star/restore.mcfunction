$summon minecraft:item ~ ~ ~ {Item:$(displaced),PickupDelay:0s}
