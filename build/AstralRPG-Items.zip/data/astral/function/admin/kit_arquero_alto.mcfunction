loot give @s loot astral:kit/arquero_alto
