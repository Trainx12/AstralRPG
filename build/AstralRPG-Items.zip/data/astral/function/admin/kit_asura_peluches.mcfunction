loot give @s loot astral:kit/asura_peluches
