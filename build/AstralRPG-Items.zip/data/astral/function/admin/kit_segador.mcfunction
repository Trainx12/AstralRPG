loot give @s loot astral:kit/segador
