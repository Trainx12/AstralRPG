loot give @s loot astral:kit/mago_alto
