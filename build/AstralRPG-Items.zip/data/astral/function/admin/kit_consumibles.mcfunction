loot give @s loot astral:kit/consumibles
