loot give @s loot astral:kit/cavernas
