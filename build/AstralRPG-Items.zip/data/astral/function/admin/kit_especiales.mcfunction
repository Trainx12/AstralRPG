loot give @s loot astral:kit/especiales
