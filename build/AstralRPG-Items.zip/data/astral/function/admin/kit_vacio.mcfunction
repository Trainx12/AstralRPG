loot give @s loot astral:kit/vacio
