loot give @s loot astral:kit/historia
