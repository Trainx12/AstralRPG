loot give @s loot astral:kit/carnivora
