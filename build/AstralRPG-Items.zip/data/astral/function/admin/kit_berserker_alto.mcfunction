loot give @s loot astral:kit/berserker_alto
