loot give @s loot astral:kit/armas_especiales
