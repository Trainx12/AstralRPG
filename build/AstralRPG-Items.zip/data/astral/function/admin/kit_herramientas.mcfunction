loot give @s loot astral:kit/herramientas
