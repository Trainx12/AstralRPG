loot give @s loot astral:kit/gemas
