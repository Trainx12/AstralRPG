loot give @s loot astral:kit/libros
