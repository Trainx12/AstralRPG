loot give @s loot astral:kit/asesino_bajo
