loot give @s loot astral:kit/agua
