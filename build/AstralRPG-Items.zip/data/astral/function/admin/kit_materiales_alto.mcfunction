loot give @s loot astral:kit/materiales_alto
