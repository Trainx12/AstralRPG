loot give @s loot astral:kit/oficios
