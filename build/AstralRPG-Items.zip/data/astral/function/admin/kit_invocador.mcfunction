loot give @s loot astral:kit/invocador
