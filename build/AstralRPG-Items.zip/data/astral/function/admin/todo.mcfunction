loot give @s loot astral:kit/materiales
loot give @s loot astral:kit/berserker
loot give @s loot astral:kit/mago
loot give @s loot astral:kit/arquero
loot give @s loot astral:kit/armas
loot give @s loot astral:kit/especiales
loot give @s loot astral:kit/herramientas
tellraw @s {"text": "Te dimos 7 cajas de shulker con todos los items de AstralRPG.", "color": "gray", "italic": false}
