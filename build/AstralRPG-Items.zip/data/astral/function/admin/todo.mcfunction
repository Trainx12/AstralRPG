loot give @s loot astral:kit/materiales
loot give @s loot astral:kit/berserker
loot give @s loot astral:kit/mago
loot give @s loot astral:kit/arquero
loot give @s loot astral:kit/armas
loot give @s loot astral:kit/especiales
tellraw @s {"text": "Te dimos 6 cajas de shulker con todos los items de AstralRPG.", "color": "gray", "italic": false}
