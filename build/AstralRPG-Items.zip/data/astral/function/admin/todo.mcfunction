loot give @s loot astral:kit/historia
loot give @s loot astral:kit/materiales
loot give @s loot astral:kit/agua
loot give @s loot astral:kit/carnivora
loot give @s loot astral:kit/asura_peluches
loot give @s loot astral:kit/berserker
loot give @s loot astral:kit/mago
loot give @s loot astral:kit/arquero
loot give @s loot astral:kit/armas
loot give @s loot astral:kit/berserker_alto
loot give @s loot astral:kit/mago_alto
loot give @s loot astral:kit/arquero_alto
loot give @s loot astral:kit/armas_alto
loot give @s loot astral:kit/materiales_alto
loot give @s loot astral:kit/especiales
loot give @s loot astral:kit/herramientas
loot give @s loot astral:kit/oficios
tellraw @s {"text": "Te dimos 17 cajas de shulker con todos los items de AstralRPG.", "color": "gray", "italic": false}
