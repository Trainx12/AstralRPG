execute if score @s astral.mt matches 1 run attribute @s minecraft:max_health base set 12500
execute if score @s astral.mt matches 2 run attribute @s minecraft:max_health base set 60000
execute if score @s astral.mt matches 3 run attribute @s minecraft:max_health base set 287500
execute if score @s astral.mt matches 4 run attribute @s minecraft:max_health base set 1375000
execute if score @s astral.mt matches 5 run attribute @s minecraft:max_health base set 6562500
execute if score @s astral.mt matches 6 run attribute @s minecraft:max_health base set 31250000
execute if score @s astral.mt matches 7 run attribute @s minecraft:max_health base set 148437500
execute if score @s astral.mt matches 8 run attribute @s minecraft:max_health base set 703125000
execute if score @s astral.mt matches 9 run attribute @s minecraft:max_health base set 3320312500
execute if score @s astral.mt matches 10 run attribute @s minecraft:max_health base set 15625000000
data modify entity @s Health set value 1.0E30f
