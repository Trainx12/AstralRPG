execute if entity @s[tag=ad.boss.scaled] run return 0
execute if predicate astral:in_sanctuary run return 0
scoreboard players set #mt astral.tmp 1
execute as @p[distance=..128,gamemode=!spectator] run function astral:player/lvl
execute if entity @a[distance=..128,gamemode=!spectator] run scoreboard players operation #mt astral.tmp = @p[distance=..128,gamemode=!spectator] astral.wt
execute as @a[tag=astral.ancestral.target,limit=1] run function astral:player/lvl
execute if entity @a[tag=astral.ancestral.target,limit=1] run scoreboard players operation #mt astral.tmp = @a[tag=astral.ancestral.target,limit=1] astral.wt
execute if score #mt astral.tmp matches ..0 run scoreboard players set #mt astral.tmp 1
scoreboard players operation @s astral.mt = #mt astral.tmp
function astral:mob/jefe_vida
execute if score #mt astral.tmp matches 1 run tag @s add astral.jm1
execute if score #mt astral.tmp matches 2 run tag @s add astral.jm2
execute if score #mt astral.tmp matches 3 run tag @s add astral.jm3
execute if score #mt astral.tmp matches 4 run tag @s add astral.jm4
execute if score #mt astral.tmp matches 5 run tag @s add astral.jm5
execute if score #mt astral.tmp matches 6 run tag @s add astral.jm6
execute if score #mt astral.tmp matches 7 run tag @s add astral.jm7
execute if score #mt astral.tmp matches 8 run tag @s add astral.jm8
execute if score #mt astral.tmp matches 9 run tag @s add astral.jm9
execute if score #mt astral.tmp matches 10 run tag @s add astral.jm10
tag @s add ad.boss.scaled
