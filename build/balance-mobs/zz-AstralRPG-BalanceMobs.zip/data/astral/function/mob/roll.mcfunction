execute if dimension minecraft:the_nether unless entity @s[tag=in.checked] run return 0
tag @s add astral.seen
execute if entity @s[type=minecraft:vex,tag=in.spirit] run return 0
# mini juegos: sus criaturas son del mapa (oleadas, niveles): sin tier ni elite
execute if dimension minecraft:parkour_spiral run return 0
execute if dimension minecraft:parkour_spiral2 run return 0
execute if dimension minecraft:parkour_paradise3 run return 0
execute if dimension minecraft:colorescape run return 0
execute if dimension minecraft:magmarun run return 0
execute if dimension minecraft:battleship run return 0
execute if dimension minecraft:dropper_facil run return 0
execute if dimension minecraft:dropper_h4rs run return 0
# mascotas, vendedores y cofres son invulnerables: no se tocan
execute if data entity @s {Invulnerable:1b} run return 0
# golems de aldea (sin nombre de MythicMobs): no se tocan
execute if entity @s[type=minecraft:iron_golem] unless data entity @s CustomName run return 0
scoreboard players set #mt astral.tmp 0
scoreboard players set #dg astral.tmp 0
execute if dimension minecraft:bosque run scoreboard players set #mt astral.tmp 1
execute if dimension minecraft:bosque run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:bosque_2 run scoreboard players set #mt astral.tmp 1
execute if dimension minecraft:bosque_2 run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:bosque_3 run scoreboard players set #mt astral.tmp 1
execute if dimension minecraft:bosque_3 run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:bosque_4 run scoreboard players set #mt astral.tmp 1
execute if dimension minecraft:bosque_4 run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:bosque_5 run scoreboard players set #mt astral.tmp 1
execute if dimension minecraft:bosque_5 run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:bosque_6 run scoreboard players set #mt astral.tmp 1
execute if dimension minecraft:bosque_6 run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:mina run scoreboard players set #mt astral.tmp 2
execute if dimension minecraft:mina run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:mina_2 run scoreboard players set #mt astral.tmp 2
execute if dimension minecraft:mina_2 run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:mina_3 run scoreboard players set #mt astral.tmp 2
execute if dimension minecraft:mina_3 run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:mina_4 run scoreboard players set #mt astral.tmp 2
execute if dimension minecraft:mina_4 run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:mina_5 run scoreboard players set #mt astral.tmp 2
execute if dimension minecraft:mina_5 run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:mina_6 run scoreboard players set #mt astral.tmp 2
execute if dimension minecraft:mina_6 run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:tumba run scoreboard players set #mt astral.tmp 3
execute if dimension minecraft:tumba run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:tumba_2 run scoreboard players set #mt astral.tmp 3
execute if dimension minecraft:tumba_2 run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:tumba_3 run scoreboard players set #mt astral.tmp 3
execute if dimension minecraft:tumba_3 run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:tumba_4 run scoreboard players set #mt astral.tmp 3
execute if dimension minecraft:tumba_4 run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:tumba_5 run scoreboard players set #mt astral.tmp 3
execute if dimension minecraft:tumba_5 run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:tumba_6 run scoreboard players set #mt astral.tmp 3
execute if dimension minecraft:tumba_6 run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:cumbre run scoreboard players set #mt astral.tmp 4
execute if dimension minecraft:cumbre run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:forja run scoreboard players set #mt astral.tmp 5
execute if dimension minecraft:forja run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:santuario run scoreboard players set #mt astral.tmp 5
execute if dimension minecraft:santuario run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:cumbre_hielo run scoreboard players set #mt astral.tmp 4
execute if dimension minecraft:cumbre_hielo run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:cumbre_hielo_2 run scoreboard players set #mt astral.tmp 4
execute if dimension minecraft:cumbre_hielo_2 run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:cumbre_hielo_3 run scoreboard players set #mt astral.tmp 4
execute if dimension minecraft:cumbre_hielo_3 run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:cumbre_hielo_4 run scoreboard players set #mt astral.tmp 4
execute if dimension minecraft:cumbre_hielo_4 run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:cumbre_hielo_5 run scoreboard players set #mt astral.tmp 4
execute if dimension minecraft:cumbre_hielo_5 run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:cumbre_hielo_6 run scoreboard players set #mt astral.tmp 4
execute if dimension minecraft:cumbre_hielo_6 run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:forja_volcano run scoreboard players set #mt astral.tmp 5
execute if dimension minecraft:forja_volcano run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:forja_volcano_2 run scoreboard players set #mt astral.tmp 5
execute if dimension minecraft:forja_volcano_2 run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:forja_volcano_3 run scoreboard players set #mt astral.tmp 5
execute if dimension minecraft:forja_volcano_3 run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:forja_volcano_4 run scoreboard players set #mt astral.tmp 5
execute if dimension minecraft:forja_volcano_4 run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:forja_volcano_5 run scoreboard players set #mt astral.tmp 5
execute if dimension minecraft:forja_volcano_5 run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:forja_volcano_6 run scoreboard players set #mt astral.tmp 5
execute if dimension minecraft:forja_volcano_6 run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:santuario_interstellar run scoreboard players set #mt astral.tmp 5
execute if dimension minecraft:santuario_interstellar run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:santuario_azeroth run scoreboard players set #mt astral.tmp 5
execute if dimension minecraft:santuario_azeroth run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:santuario_azeroth_2 run scoreboard players set #mt astral.tmp 5
execute if dimension minecraft:santuario_azeroth_2 run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:santuario_azeroth_3 run scoreboard players set #mt astral.tmp 5
execute if dimension minecraft:santuario_azeroth_3 run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:santuario_azeroth_4 run scoreboard players set #mt astral.tmp 5
execute if dimension minecraft:santuario_azeroth_4 run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:santuario_azeroth_5 run scoreboard players set #mt astral.tmp 5
execute if dimension minecraft:santuario_azeroth_5 run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:santuario_azeroth_6 run scoreboard players set #mt astral.tmp 5
execute if dimension minecraft:santuario_azeroth_6 run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:nave run scoreboard players set #mt astral.tmp 5
execute if dimension minecraft:nave run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:nave_2 run scoreboard players set #mt astral.tmp 5
execute if dimension minecraft:nave_2 run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:nave_3 run scoreboard players set #mt astral.tmp 5
execute if dimension minecraft:nave_3 run scoreboard players set #dg astral.tmp 1
execute if dimension minecraft:oceano run scoreboard players set #mt astral.tmp 2
execute if dimension minecraft:oceano run scoreboard players set #dg astral.tmp 2
execute if dimension minecraft:fosa run scoreboard players set #mt astral.tmp 3
execute if dimension minecraft:fosa run scoreboard players set #dg astral.tmp 2
execute if dimension minecraft:fosa_2 run scoreboard players set #mt astral.tmp 3
execute if dimension minecraft:fosa_2 run scoreboard players set #dg astral.tmp 2
execute if dimension minecraft:fosa_3 run scoreboard players set #mt astral.tmp 3
execute if dimension minecraft:fosa_3 run scoreboard players set #dg astral.tmp 2
execute if dimension minecraft:cavernas_cristal run scoreboard players set #mt astral.tmp 4
execute if dimension minecraft:cavernas_cristal run scoreboard players set #dg astral.tmp 2
execute if dimension minecraft:vacio_estelar run scoreboard players set #mt astral.tmp 6
execute if dimension minecraft:vacio_estelar run scoreboard players set #dg astral.tmp 2
execute if dimension minecraft:cavernas_cristal if entity @s[x=-150,z=-150,y=-64,dx=300,dz=300,dy=200] run scoreboard players set #mt astral.tmp 5
execute if dimension minecraft:vacio_estelar unless entity @s[x=-200,z=-200,y=-64,dx=400,dz=400,dy=400] run scoreboard players set #mt astral.tmp 7
execute if dimension minecraft:vacio_estelar unless entity @s[x=-400,z=-400,y=-64,dx=800,dz=800,dy=400] run scoreboard players set #mt astral.tmp 8
execute if entity @s[type=minecraft:slime] if data entity @s {Size:1} run attribute @s minecraft:max_health base set 8
execute if entity @s[type=minecraft:slime] if data entity @s {Size:0} run attribute @s minecraft:max_health base set 4
execute if entity @s[type=minecraft:magma_cube] if data entity @s {Size:1} run attribute @s minecraft:max_health base set 8
execute if entity @s[type=minecraft:magma_cube] if data entity @s {Size:0} run attribute @s minecraft:max_health base set 4
execute if entity @s[tag=ad.vanilla] run function astral:mob/tier_mazmorra
execute if score #dg astral.tmp matches 0 if entity @a[distance=..128,gamemode=!spectator] run function astral:mob/tier_mundo
execute if score #mt astral.tmp matches ..0 run scoreboard players set #mt astral.tmp 1
execute if score #mt astral.tmp matches 1 run function astral:mob/t1
execute if score #mt astral.tmp matches 2 run function astral:mob/t2
execute if score #mt astral.tmp matches 3 run function astral:mob/t3
execute if score #mt astral.tmp matches 4 run function astral:mob/t4
execute if score #mt astral.tmp matches 5 run function astral:mob/t5
execute if score #mt astral.tmp matches 6 run function astral:mob/t6
execute if score #mt astral.tmp matches 7 run function astral:mob/t7
execute if score #mt astral.tmp matches 8 run function astral:mob/t8
execute if score #mt astral.tmp matches 9 run function astral:mob/t9
execute if score #mt astral.tmp matches 10 run function astral:mob/t10
execute if score #dg astral.tmp matches 1 run function astral:mob/extra_mazmorra
execute if score #dg astral.tmp matches 1 run tag @s add astral.maz
scoreboard players operation @s astral.mt = #mt astral.tmp
function astral:mob/elite_chance
data modify entity @s Health set value 1.0E30f
function astral:mob/nombre
