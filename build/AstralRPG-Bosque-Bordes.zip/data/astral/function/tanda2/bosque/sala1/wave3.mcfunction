scoreboard players set @s ad.wave 3
tag @s add bosque.espera
tag @s add bosque.sala1.busy
scoreboard players set @s ad.w 3
scoreboard players set @s ad.q 0
execute store result score @s ad.party run execute if entity @a[distance=..108,gamemode=!spectator]
scoreboard players remove @s ad.party 2
scoreboard players set @s ad.n 0
execute if score @s ad.party matches 1.. run scoreboard players operation @s ad.n = @s ad.party
scoreboard players set #factor ad.n 560
scoreboard players operation @s ad.n *= #factor ad.n
scoreboard players add @s ad.n 99
scoreboard players set #hundred ad.n 100
scoreboard players operation @s ad.n /= #hundred ad.n
scoreboard players set @s ad.qm 14
scoreboard players operation @s ad.qm += @s ad.n
scoreboard players set @s ad.clock 0
function astral:tanda2/bosque/sala1/pop
function astral:tanda2/bosque/sala1/pop
function astral:tanda2/bosque/sala1/pop
function astral:tanda2/bosque/sala1/pop
function astral:tanda2/bosque/sala1/pop
function astral:tanda2/bosque/sala1/pop
function astral:tanda2/bosque/sala1/ui_start
