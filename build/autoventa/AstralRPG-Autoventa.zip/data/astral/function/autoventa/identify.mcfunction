tag @s remove astral.autoventa
execute if items entity @s hotbar.* *[minecraft:custom_data~{astral:{id:"autoventa"}}] run tag @s add astral.autoventa
execute if items entity @s inventory.* *[minecraft:custom_data~{astral:{id:"autoventa"}}] run tag @s add astral.autoventa
execute if items entity @s weapon.offhand *[minecraft:custom_data~{astral:{id:"autoventa"}}] run tag @s add astral.autoventa
