execute in minecraft:astral_minas run forceload remove 3659 76 3698 110
