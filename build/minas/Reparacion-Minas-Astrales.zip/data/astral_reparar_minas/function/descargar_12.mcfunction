execute in minecraft:astral_minas run forceload remove 5707 76 5746 110
