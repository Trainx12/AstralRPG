execute in minecraft:astral_minas run forceload remove 587 76 626 110
