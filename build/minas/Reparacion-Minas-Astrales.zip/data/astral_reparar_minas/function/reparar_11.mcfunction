execute in minecraft:astral_minas run place template astral_reparar_minas:pozo 5195 73 76
execute in minecraft:astral_minas if block 5217 92 77 bedrock
