execute in minecraft:astral_minas run forceload add 6219 76 6258 110
