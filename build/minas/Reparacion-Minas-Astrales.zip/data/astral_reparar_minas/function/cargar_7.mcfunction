execute in minecraft:astral_minas run forceload add 3147 76 3186 110
