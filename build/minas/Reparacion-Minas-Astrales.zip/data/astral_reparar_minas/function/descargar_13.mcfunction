execute in minecraft:astral_minas run forceload remove 6219 76 6258 110
