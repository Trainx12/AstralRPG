execute in minecraft:astral_minas run forceload remove 75 76 114 110
