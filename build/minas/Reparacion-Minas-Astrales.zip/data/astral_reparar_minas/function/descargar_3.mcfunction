execute in minecraft:astral_minas run forceload remove 1099 76 1138 110
