execute in minecraft:astral_minas run forceload remove 8267 76 8306 110
