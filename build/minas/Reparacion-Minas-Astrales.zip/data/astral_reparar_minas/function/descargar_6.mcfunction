execute in minecraft:astral_minas run forceload remove 2635 76 2674 110
