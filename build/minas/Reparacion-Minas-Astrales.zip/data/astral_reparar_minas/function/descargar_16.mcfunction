execute in minecraft:astral_minas run forceload remove 7755 76 7794 110
