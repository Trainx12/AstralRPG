execute in minecraft:astral_minas run forceload add 7755 76 7794 110
