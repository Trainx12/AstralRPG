execute in minecraft:astral_minas run forceload add 9803 76 9842 110
