execute in minecraft:astral_minas run forceload remove 7243 76 7282 110
