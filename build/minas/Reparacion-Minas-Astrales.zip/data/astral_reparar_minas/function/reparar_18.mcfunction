execute in minecraft:astral_minas run place template astral_reparar_minas:pozo 8779 73 76
execute in minecraft:astral_minas if block 8801 92 77 bedrock
