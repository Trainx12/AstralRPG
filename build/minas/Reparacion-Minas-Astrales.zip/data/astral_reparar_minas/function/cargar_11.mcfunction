execute in minecraft:astral_minas run forceload add 5195 76 5234 110
