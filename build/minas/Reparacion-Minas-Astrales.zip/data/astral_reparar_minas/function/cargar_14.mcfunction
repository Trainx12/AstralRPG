execute in minecraft:astral_minas run forceload add 6731 76 6770 110
