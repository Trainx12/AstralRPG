execute in minecraft:astral_minas run forceload add 3659 76 3698 110
