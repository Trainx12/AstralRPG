execute in minecraft:astral_minas run place template astral_reparar_minas:pozo 2635 73 76
execute in minecraft:astral_minas if block 2657 92 77 bedrock
