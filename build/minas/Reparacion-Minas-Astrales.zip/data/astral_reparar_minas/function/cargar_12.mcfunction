execute in minecraft:astral_minas run forceload add 5707 76 5746 110
