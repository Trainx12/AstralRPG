execute in minecraft:astral_minas run forceload add 4683 76 4722 110
