execute in minecraft:astral_minas run place template astral_reparar_minas:pozo 5707 73 76
execute in minecraft:astral_minas if block 5729 92 77 bedrock
