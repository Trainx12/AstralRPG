execute in minecraft:astral_minas run forceload add 9291 76 9330 110
