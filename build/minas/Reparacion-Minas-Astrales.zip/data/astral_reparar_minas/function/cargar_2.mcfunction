execute in minecraft:astral_minas run forceload add 587 76 626 110
