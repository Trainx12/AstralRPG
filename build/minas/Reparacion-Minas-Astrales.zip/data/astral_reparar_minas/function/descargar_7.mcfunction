execute in minecraft:astral_minas run forceload remove 3147 76 3186 110
