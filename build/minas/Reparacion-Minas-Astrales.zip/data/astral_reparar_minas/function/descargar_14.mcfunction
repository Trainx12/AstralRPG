execute in minecraft:astral_minas run forceload remove 6731 76 6770 110
