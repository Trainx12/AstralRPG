execute in minecraft:astral_minas run place template astral_reparar_minas:pozo 1099 73 76
execute in minecraft:astral_minas if block 1121 92 77 bedrock
