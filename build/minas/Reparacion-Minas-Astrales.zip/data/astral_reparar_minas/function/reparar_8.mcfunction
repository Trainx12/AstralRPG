execute in minecraft:astral_minas run place template astral_reparar_minas:pozo 3659 73 76
execute in minecraft:astral_minas if block 3681 92 77 bedrock
