execute in minecraft:astral_minas run place template astral_reparar_minas:pozo 75 73 76
execute in minecraft:astral_minas if block 97 92 77 bedrock
