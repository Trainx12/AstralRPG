execute in minecraft:astral_minas run forceload add 1611 76 1650 110
