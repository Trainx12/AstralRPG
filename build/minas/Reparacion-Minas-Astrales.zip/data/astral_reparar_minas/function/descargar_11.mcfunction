execute in minecraft:astral_minas run forceload remove 5195 76 5234 110
