execute in minecraft:astral_minas run forceload add 1099 76 1138 110
