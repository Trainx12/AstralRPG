execute in minecraft:astral_minas run forceload remove 9803 76 9842 110
