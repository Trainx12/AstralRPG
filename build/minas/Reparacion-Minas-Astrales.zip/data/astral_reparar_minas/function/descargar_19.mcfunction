execute in minecraft:astral_minas run forceload remove 9291 76 9330 110
