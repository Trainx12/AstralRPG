execute in minecraft:astral_minas run place template astral_reparar_minas:pozo 2123 73 76
execute in minecraft:astral_minas if block 2145 92 77 bedrock
