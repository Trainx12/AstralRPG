execute in minecraft:astral_minas run forceload remove 4171 76 4210 110
