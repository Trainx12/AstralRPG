execute in minecraft:astral_minas run place template astral_reparar_minas:pozo 6731 73 76
execute in minecraft:astral_minas if block 6753 92 77 bedrock
