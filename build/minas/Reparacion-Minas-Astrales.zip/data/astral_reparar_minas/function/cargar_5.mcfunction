execute in minecraft:astral_minas run forceload add 2123 76 2162 110
