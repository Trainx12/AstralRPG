execute in minecraft:astral_minas run forceload remove 2123 76 2162 110
