execute in minecraft:astral_minas run forceload remove 4683 76 4722 110
