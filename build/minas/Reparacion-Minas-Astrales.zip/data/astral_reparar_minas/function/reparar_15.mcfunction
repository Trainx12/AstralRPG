execute in minecraft:astral_minas run place template astral_reparar_minas:pozo 7243 73 76
execute in minecraft:astral_minas if block 7265 92 77 bedrock
