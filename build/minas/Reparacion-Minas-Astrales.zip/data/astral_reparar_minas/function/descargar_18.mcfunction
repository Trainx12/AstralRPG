execute in minecraft:astral_minas run forceload remove 8779 76 8818 110
