execute in minecraft:astral_minas run forceload add 4171 76 4210 110
