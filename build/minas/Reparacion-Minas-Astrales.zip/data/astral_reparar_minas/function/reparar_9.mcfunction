execute in minecraft:astral_minas run place template astral_reparar_minas:pozo 4171 73 76
execute in minecraft:astral_minas if block 4193 92 77 bedrock
