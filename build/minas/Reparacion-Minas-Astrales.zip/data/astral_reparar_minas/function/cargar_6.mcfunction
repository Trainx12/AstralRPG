execute in minecraft:astral_minas run forceload add 2635 76 2674 110
