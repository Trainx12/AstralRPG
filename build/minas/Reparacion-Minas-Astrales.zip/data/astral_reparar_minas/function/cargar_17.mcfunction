execute in minecraft:astral_minas run forceload add 8267 76 8306 110
