execute in minecraft:astral_minas run place template astral_reparar_minas:pozo 9291 73 76
execute in minecraft:astral_minas if block 9313 92 77 bedrock
