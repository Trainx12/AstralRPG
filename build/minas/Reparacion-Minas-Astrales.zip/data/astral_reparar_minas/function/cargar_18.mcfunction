execute in minecraft:astral_minas run forceload add 8779 76 8818 110
