execute in minecraft:astral_minas run forceload add 7243 76 7282 110
