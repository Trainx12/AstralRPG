execute in minecraft:astral_minas run forceload add 75 76 114 110
