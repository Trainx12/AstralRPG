execute in minecraft:astral_minas run place template astral_reparar_minas:pozo 9803 73 76
execute in minecraft:astral_minas if block 9825 92 77 bedrock
