execute in minecraft:astral_minas run place template astral_reparar_minas:pozo 3147 73 76
execute in minecraft:astral_minas if block 3169 92 77 bedrock
